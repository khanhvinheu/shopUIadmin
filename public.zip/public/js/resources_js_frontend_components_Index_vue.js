"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_frontend_components_Index_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _layouts_Header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./layouts/Header */ "./resources/js/frontend/components/layouts/Header.vue");
/* harmony import */ var _layouts_Footer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./layouts/Footer */ "./resources/js/frontend/components/layouts/Footer.vue");
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'Index',
  components: {
    AppHeader: _layouts_Header__WEBPACK_IMPORTED_MODULE_0__["default"],
    AppFooter: _layouts_Footer__WEBPACK_IMPORTED_MODULE_1__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Footer.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Footer.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'AppFooter',
  data: function data() {
    return {};
  },
  methods: {}
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'AppHeader',
  data: function data() {
    return {
      showMenuMobile: true
    };
  },
  methods: {}
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_css_home_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! -!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!../../../css/home.css */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./resources/css/home.css");
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_css_home_css__WEBPACK_IMPORTED_MODULE_1__["default"]);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "   \n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".header-actions__menu[data-v-31cefecd] {\n  position: absolute;\n  top: 100%;\n  right: 0;\n  padding-top: 5px;\n  opacity: 0;\n  pointer-events: none;\n  visibility: hidden;\n  transition: all .3s;\n}\n.header-actions__inner[data-v-31cefecd] {\n  background-color: #fff;\n  border-radius: 16px;\n  box-shadow: 0 0 10px 0 rgb(0 0 0 / 7%);\n  border: 1px solid #d9d9d9;\n}\n.mini-cart[data-v-31cefecd] {\n  padding: 1rem;\n  width: 400px;\n}\n.mini-cart__header[data-v-31cefecd]{\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 1rem;\n}\n.mini-cart__item[data-v-31cefecd]{\n  display: flex;\n  align-items: center;\n  flex-wrap: wrap;\n  cursor: pointer;\n  font-size: .8rem;\n}\n.mini-cart__item-thumbnail[data-v-31cefecd]{\n  margin-right: 1rem;\n}\n.mini-cart__item-content[data-v-31cefecd]{\n  flex: 1;\n  height: 100%;\n  position: relative;\n  padding-right: 20px;\n}\n.mini-cart__remove[data-v-31cefecd]{\n  position: absolute;\n  top: 0;\n  right: 0;\n}\n.mini-cart__item-title[data-v-31cefecd]{\n  font-weight: bold;\n  transition: .2s all;\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./resources/css/home.css":
/*!**********************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./resources/css/home.css ***!
  \**********************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/*!normalize.css v8.0.0 | MIT License | github.com/necolas/normalize.css*/\r\nhtml {\r\n    line-height: 1.15;\r\n    -webkit-text-size-adjust: 100%\r\n}\r\n\r\nhr {\r\n    box-sizing: content-box;\r\n    height: 0;\r\n    overflow: visible\r\n}\r\n\r\npre {\r\n    font-family: monospace, monospace;\r\n    font-size: 1em\r\n}\r\n\r\na {\r\n    background-color: transparent;\r\n    text-decoration: none;\r\n    color: inherit;\r\n    transition: all .2s\r\n}\r\n\r\nabbr[title] {\r\n    border-bottom: none;\r\n    text-decoration: underline;\r\n    -webkit-text-decoration: underline dotted;\r\n    text-decoration: underline dotted\r\n}\r\n\r\n*,\r\n:after,\r\n:before {\r\n    box-sizing: border-box\r\n}\r\n\r\nb,\r\nstrong {\r\n    font-weight: bolder\r\n}\r\n\r\ncode,\r\nkbd,\r\nsamp {\r\n    font-family: monospace, monospace;\r\n    font-size: 1em\r\n}\r\n\r\nsmall {\r\n    font-size: 80%\r\n}\r\n\r\nsub,\r\nsup {\r\n    font-size: 75%;\r\n    line-height: 0;\r\n    position: relative;\r\n    vertical-align: baseline\r\n}\r\n\r\nsub {\r\n    bottom: -.25em\r\n}\r\n\r\nsup {\r\n    top: -.5em\r\n}\r\n\r\nimg {\r\n    border-style: none;\r\n    vertical-align: middle;\r\n    max-width: 100%;\r\n    height: auto\r\n}\r\n\r\npicture {\r\n    display: inline-block\r\n}\r\n\r\nbutton,\r\ninput,\r\noptgroup,\r\nselect,\r\ntextarea {\r\n    font-family: inherit;\r\n    font-size: 100%;\r\n    line-height: 1.15;\r\n    margin: 0;\r\n    -webkit-box-shadow: inset 0 0 0 9999px transparent;\r\n    -webkit-appearance: none;\r\n    -moz-appearance: none;\r\n    appearance: none;\r\n    box-shadow: none;\r\n    border-radius: 0\r\n}\r\n\r\nbutton:focus,\r\ninput:focus,\r\noptgroup:focus,\r\nselect:focus,\r\ntextarea:focus {\r\n    outline: none\r\n}\r\n\r\nbutton,\r\ninput {\r\n    overflow: visible\r\n}\r\n\r\nbutton,\r\nselect {\r\n    text-transform: none\r\n}\r\n\r\n[type=button],\r\n[type=reset],\r\n[type=submit],\r\nbutton {\r\n    -webkit-appearance: button\r\n}\r\n\r\n[type=button]::-moz-focus-inner,\r\n[type=reset]::-moz-focus-inner,\r\n[type=submit]::-moz-focus-inner,\r\nbutton::-moz-focus-inner {\r\n    border-style: none;\r\n    padding: 0\r\n}\r\n\r\n[type=button]:-moz-focusring,\r\n[type=reset]:-moz-focusring,\r\n[type=submit]:-moz-focusring,\r\nbutton:-moz-focusring {\r\n    outline: 1px dotted ButtonText\r\n}\r\n\r\nfieldset {\r\n    padding: .35em .75em .625em\r\n}\r\n\r\nlegend {\r\n    box-sizing: border-box;\r\n    color: inherit;\r\n    display: table;\r\n    max-width: 100%;\r\n    padding: 0;\r\n    white-space: normal\r\n}\r\n\r\nprogress {\r\n    vertical-align: baseline\r\n}\r\n\r\ntextarea {\r\n    overflow: auto\r\n}\r\n\r\n[type=checkbox],\r\n[type=radio] {\r\n    box-sizing: border-box;\r\n    padding: 0\r\n}\r\n\r\n[type=number]::-webkit-inner-spin-button,\r\n[type=number]::-webkit-outer-spin-button {\r\n    height: auto\r\n}\r\n\r\n[type=search] {\r\n    -webkit-appearance: textfield;\r\n    outline-offset: -2px\r\n}\r\n\r\n[type=search]::-webkit-search-decoration {\r\n    -webkit-appearance: none\r\n}\r\n\r\n::-webkit-file-upload-button {\r\n    -webkit-appearance: button;\r\n    font: inherit\r\n}\r\n\r\ndetails {\r\n    display: block\r\n}\r\n\r\nsummary {\r\n    display: list-item\r\n}\r\n\r\n[hidden],\r\ntemplate {\r\n    display: none\r\n}\r\n\r\niframe,\r\ntable {\r\n    max-width: 100%\r\n}\r\n\r\nh1,\r\nh2,\r\nh3,\r\nh4,\r\nh5,\r\nh6 {\r\n    margin-top: 0;\r\n    margin-bottom: .5rem;\r\n    color: #231f20;\r\n    font-weight: 400\r\n}\r\n\r\n.h1,\r\nh1 {\r\n    font-size: 35px\r\n}\r\n\r\n.h2,\r\nh2 {\r\n    font-size: 24px\r\n}\r\n\r\n.h3,\r\nh3 {\r\n    font-size: 20.5px\r\n}\r\n\r\n.h4,\r\nh4 {\r\n    font-size: 17px\r\n}\r\n\r\n.h5,\r\nh5 {\r\n    font-size: 13.5px\r\n}\r\n\r\n.h6,\r\nh6 {\r\n    font-size: 14px\r\n}\r\n\r\n.container {\r\n    max-width: 100%;\r\n    padding-left: 16px;\r\n    padding-right: 16px;\r\n    max-width: 1920px;\r\n    width: 100%;\r\n    margin: 0 auto\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .container {\r\n        padding-left: 9px;\r\n        padding-right: 9px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .container {\r\n        padding-left: 9px;\r\n        padding-right: 9px\r\n    }\r\n}\r\n\r\n@media(max-width:768px) {\r\n    .container {\r\n        max-width: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:1440px) {\r\n    .container {\r\n        padding-left: 64px;\r\n        padding-right: 64px\r\n    }\r\n}\r\n\r\n.container--full {\r\n    max-width: 100%\r\n}\r\n\r\n.container--medium {\r\n    max-width: 1280px\r\n}\r\n\r\n@media(min-width:1440px) {\r\n    .container--medium {\r\n        padding-left: 0;\r\n        padding-right: 0\r\n    }\r\n}\r\n\r\n.container--detail {\r\n    max-width: 750px\r\n}\r\n\r\n@media(min-width:1440px) {\r\n    .container--detail {\r\n        padding-left: 0;\r\n        padding-right: 0\r\n    }\r\n}\r\n\r\nhtml {\r\n    overflow-x: hidden;\r\n    margin: 0;\r\n    padding: 0\r\n}\r\n\r\nimg {\r\n    text-indent: -9999px;\r\n    color: transparent\r\n}\r\n\r\nimg:not(.home-banner) {\r\n    image-rendering: -moz-crisp-edges;\r\n    image-rendering: -o-crisp-edges;\r\n    image-rendering: -webkit-optimize-contrast;\r\n    image-rendering: crisp-edges;\r\n    -ms-interpolation-mode: nearest-neighbor\r\n}\r\n\r\nimg:not([src]) {\r\n    visibility: hidden\r\n}\r\n\r\nbody {\r\n    margin: 0;\r\n    font-family: Pangea, sans-serif;\r\n    font-size: 14px;\r\n    font-weight: 400;\r\n    line-height: 1.5;\r\n    color: #231f20;\r\n    text-align: left;\r\n    background-color: #fff\r\n}\r\n\r\n@media(max-width:991px) {\r\n    body {\r\n        overflow: hidden\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile body {\r\n        overflow: hidden\r\n    }\r\n}\r\n\r\n@-webkit-keyframes loading {\r\n    0% {\r\n        transform: rotate(0deg)\r\n    }\r\n\r\n    to {\r\n        transform: rotate(1turn)\r\n    }\r\n}\r\n\r\n@keyframes loading {\r\n    0% {\r\n        transform: rotate(0deg)\r\n    }\r\n\r\n    to {\r\n        transform: rotate(1turn)\r\n    }\r\n}\r\n\r\n.flex {\r\n    display: flex\r\n}\r\n\r\n.flex--space {\r\n    flex: 1\r\n}\r\n\r\n.flex--column {\r\n    flex-flow: column\r\n}\r\n\r\n.flex--row {\r\n    flex-flow: row\r\n}\r\n\r\n.flex--wrap {\r\n    flex-wrap: wrap\r\n}\r\n\r\n.justify--center {\r\n    justify-content: center\r\n}\r\n\r\n.justify--around {\r\n    justify-content: space-around\r\n}\r\n\r\n.justify--between {\r\n    justify-content: space-between\r\n}\r\n\r\n.justify--start {\r\n    justify-content: flex-start\r\n}\r\n\r\n.justify--end {\r\n    justify-content: flex-end\r\n}\r\n\r\n.align--center {\r\n    align-items: center\r\n}\r\n\r\n.align--start {\r\n    align-items: flex-start\r\n}\r\n\r\n.align--end {\r\n    align-items: flex-end\r\n}\r\n\r\n.text--black {\r\n    font-weight: 900\r\n}\r\n\r\n.text--bold {\r\n    font-weight: 700\r\n}\r\n\r\n.text--simi {\r\n    font-weight: 600\r\n}\r\n\r\n.text--medium {\r\n    font-weight: 500\r\n}\r\n\r\n.text--normal {\r\n    font-weight: 400\r\n}\r\n\r\n.text--light {\r\n    font-weight: 300\r\n}\r\n\r\n.text--extra-light {\r\n    font-weight: 200\r\n}\r\n\r\n.text--italic {\r\n    font-family: Pangea, sans-serif\r\n}\r\n\r\n.text--upper {\r\n    text-transform: uppercase\r\n}\r\n\r\n.text--lower {\r\n    text-transform: lowercase\r\n}\r\n\r\n.text--title {\r\n    text-transform: capitalize\r\n}\r\n\r\n.text--nowrap {\r\n    white-space: nowrap\r\n}\r\n\r\n.text--strikethrough {\r\n    text-decoration: line-through\r\n}\r\n\r\n.text--white {\r\n    color: #fff\r\n}\r\n\r\n.text--dark {\r\n    color: #231f20\r\n}\r\n\r\n.text--primary {\r\n    color: #2f5acf\r\n}\r\n\r\n.text--secondary {\r\n    color: #838388\r\n}\r\n\r\n.text--green {\r\n    color: #239a1a\r\n}\r\n\r\n.text--red {\r\n    color: red\r\n}\r\n\r\n.text--right {\r\n    text-align: right\r\n}\r\n\r\n.text--left {\r\n    text-align: left\r\n}\r\n\r\n.text--center {\r\n    text-align: center\r\n}\r\n\r\n.no-style {\r\n    margin: 0;\r\n    padding: 0\r\n}\r\n\r\n.no-style li {\r\n    list-style: none\r\n}\r\n\r\n.two-columns {\r\n    display: flex;\r\n    flex-flow: row wrap;\r\n    margin: 0 -15px\r\n}\r\n\r\n.two-columns li {\r\n    width: 50%;\r\n    padding: 0 15px\r\n}\r\n\r\n.mgt--10 {\r\n    margin-top: 10px\r\n}\r\n\r\n.mgt--20 {\r\n    margin-top: 20px\r\n}\r\n\r\n.mgt--30 {\r\n    margin-top: 30px\r\n}\r\n\r\n.mgt--40 {\r\n    margin-top: 40px\r\n}\r\n\r\n.mgt--50 {\r\n    margin-top: 50px\r\n}\r\n\r\n.mgt--60 {\r\n    margin-top: 60px\r\n}\r\n\r\n.mgt--70 {\r\n    margin-top: 70px\r\n}\r\n\r\n.mgt--80 {\r\n    margin-top: 80px\r\n}\r\n\r\n.mgt--90 {\r\n    margin-top: 90px\r\n}\r\n\r\n.mgt--100 {\r\n    margin-top: 100px\r\n}\r\n\r\n.mgb--10 {\r\n    margin-bottom: 10px\r\n}\r\n\r\n.mgb--20 {\r\n    margin-bottom: 20px\r\n}\r\n\r\n.mgb--30 {\r\n    margin-bottom: 30px\r\n}\r\n\r\n.mgb--40 {\r\n    margin-bottom: 40px\r\n}\r\n\r\n.mgb--50 {\r\n    margin-bottom: 50px\r\n}\r\n\r\n.mgb--60 {\r\n    margin-bottom: 60px\r\n}\r\n\r\n.mgb--70 {\r\n    margin-bottom: 70px\r\n}\r\n\r\n.mgb--80 {\r\n    margin-bottom: 80px\r\n}\r\n\r\n.mgb--90 {\r\n    margin-bottom: 90px\r\n}\r\n\r\n.mgb--100 {\r\n    margin-bottom: 100px\r\n}\r\n\r\n.pdt--10 {\r\n    padding-top: 10px\r\n}\r\n\r\n.pdt--20 {\r\n    padding-top: 20px\r\n}\r\n\r\n.pdt--30 {\r\n    padding-top: 30px\r\n}\r\n\r\n.pdt--40 {\r\n    padding-top: 40px\r\n}\r\n\r\n.pdt--50 {\r\n    padding-top: 50px\r\n}\r\n\r\n.pdt--60 {\r\n    padding-top: 60px\r\n}\r\n\r\n.pdt--70 {\r\n    padding-top: 70px\r\n}\r\n\r\n.pdt--80 {\r\n    padding-top: 80px\r\n}\r\n\r\n.pdt--90 {\r\n    padding-top: 90px\r\n}\r\n\r\n.pdt--100 {\r\n    padding-top: 100px\r\n}\r\n\r\n.pdb--10 {\r\n    padding-bottom: 10px\r\n}\r\n\r\n.pdb--20 {\r\n    padding-bottom: 20px\r\n}\r\n\r\n.pdb--30 {\r\n    padding-bottom: 30px\r\n}\r\n\r\n.pdb--40 {\r\n    padding-bottom: 40px\r\n}\r\n\r\n.pdb--50 {\r\n    padding-bottom: 50px\r\n}\r\n\r\n.pdb--60 {\r\n    padding-bottom: 60px\r\n}\r\n\r\n.pdb--70 {\r\n    padding-bottom: 70px\r\n}\r\n\r\n.pdb--80 {\r\n    padding-bottom: 80px\r\n}\r\n\r\n.pdb--90 {\r\n    padding-bottom: 90px\r\n}\r\n\r\n.pdb--100 {\r\n    padding-bottom: 100px\r\n}\r\n\r\n.pd--10 {\r\n    padding: 10px\r\n}\r\n\r\n.pd--20 {\r\n    padding: 20px\r\n}\r\n\r\n.pd--30 {\r\n    padding: 30px\r\n}\r\n\r\n.pd--40 {\r\n    padding: 40px\r\n}\r\n\r\n.pd--50 {\r\n    padding: 50px\r\n}\r\n\r\n.pd--60 {\r\n    padding: 60px\r\n}\r\n\r\n.pd--70 {\r\n    padding: 70px\r\n}\r\n\r\n.pd--80 {\r\n    padding: 80px\r\n}\r\n\r\n.pd--90 {\r\n    padding: 90px\r\n}\r\n\r\n.pd--100 {\r\n    padding: 100px\r\n}\r\n\r\n.grid__column.clear {\r\n    clear: both\r\n}\r\n\r\n.grid {\r\n    display: flex;\r\n    display: -webkit-flex;\r\n    -moz-flex-direction: row;\r\n    flex-direction: row;\r\n    flex-wrap: wrap;\r\n    margin-left: -9px;\r\n    margin-right: -9px;\r\n    padding: 0;\r\n    position: relative;\r\n    float: none\r\n}\r\n\r\n.grid:after {\r\n    content: \"\";\r\n    display: table;\r\n    clear: both\r\n}\r\n\r\n.grid__column {\r\n    position: relative;\r\n    box-sizing: border-box;\r\n    min-height: 1px;\r\n    vertical-align: top;\r\n    margin-left: 0 !important;\r\n    margin-right: 0 !important;\r\n    padding: 9px;\r\n    width: 100%\r\n}\r\n\r\n@media(max-width:768px) {\r\n    .grid--stackable>.grid__column {\r\n        width: 100% !important;\r\n        flex: 1 0 auto !important\r\n    }\r\n}\r\n\r\n.grid--rev {\r\n    display: flex;\r\n    display: -webkit-flex;\r\n    flex-wrap: wrap;\r\n    flex-direction: row-reverse\r\n}\r\n\r\n.grid--full {\r\n    margin-left: 0;\r\n    margin-right: 0\r\n}\r\n\r\n.grid--full>.grid__column {\r\n    padding: 0 9px\r\n}\r\n\r\n.grid--nospace {\r\n    margin: 0\r\n}\r\n\r\n.grid--nospace .grid__column {\r\n    padding: 0\r\n}\r\n\r\n.grid--automatic {\r\n    display: flex;\r\n    display: -webkit-flex;\r\n    flex-wrap: wrap\r\n}\r\n\r\n.grid--automatic>.grid__column {\r\n    flex-grow: 1\r\n}\r\n\r\n.grid--automatic>.grid__column[class*=-twelfths] {\r\n    flex-grow: 0\r\n}\r\n\r\n.grid--automatic>.grid__column:not([class*=-twelfths]) {\r\n    flex: 1 1 0%;\r\n    -webkit-flex: 1 1 0%\r\n}\r\n\r\n.grid--equal-height>.grid__column>div {\r\n    width: 100%\r\n}\r\n\r\n.grid--equal-height>.grid__column {\r\n    display: flex;\r\n    display: -webkit-flex\r\n}\r\n\r\n.grid--aligned-topcenter {\r\n    justify-content: center\r\n}\r\n\r\n.grid--aligned-topcenter,\r\n.grid--aligned-topright {\r\n    -moz-align-items: flex-start;\r\n    align-items: flex-start\r\n}\r\n\r\n.grid--aligned-topright {\r\n    justify-content: flex-end\r\n}\r\n\r\n.grid--aligned-middleleft {\r\n    justify-content: flex-start;\r\n    -moz-align-items: center;\r\n    align-items: center\r\n}\r\n\r\n.grid--aligned-center {\r\n    justify-content: center;\r\n    -moz-align-items: center;\r\n    align-items: center\r\n}\r\n\r\n.grid--aligned-middleright {\r\n    justify-content: flex-end;\r\n    -moz-align-items: center;\r\n    align-items: center\r\n}\r\n\r\n.grid--aligned-bottomleft {\r\n    justify-content: flex-start;\r\n    -moz-align-items: flex-end;\r\n    align-items: flex-end\r\n}\r\n\r\n.grid--aligned-bottomcenter {\r\n    justify-content: center;\r\n    -moz-align-items: flex-end;\r\n    align-items: flex-end\r\n}\r\n\r\n.grid--aligned-bottomright {\r\n    justify-content: flex-end;\r\n    -moz-align-items: flex-end;\r\n    align-items: flex-end\r\n}\r\n\r\n.grid--one-column>.grid__column {\r\n    width: 100%\r\n}\r\n\r\n.grid--two-columns>.grid__column {\r\n    width: 50%\r\n}\r\n\r\n.grid--three-columns>.grid__column {\r\n    width: 33.33333333%\r\n}\r\n\r\n.grid--four-columns>.grid__column {\r\n    width: 25%\r\n}\r\n\r\n.grid--five-columns>.grid__column {\r\n    width: 20%\r\n}\r\n\r\n.grid--six-columns>.grid__column {\r\n    width: 16.66666667%\r\n}\r\n\r\n.grid--seven-columns>.grid__column {\r\n    width: 14.28571429%\r\n}\r\n\r\n.grid--eight-columns>.grid__column {\r\n    width: 12.5%\r\n}\r\n\r\n.grid--nine-columns>.grid__column {\r\n    width: 11.11111111%\r\n}\r\n\r\n.grid--ten-columns>.grid__column {\r\n    width: 10%\r\n}\r\n\r\n.grid--eleven-columns>.grid__column {\r\n    width: 9.09090909%\r\n}\r\n\r\n.grid--twelfth-columns>.grid__column {\r\n    width: 8.33333333%\r\n}\r\n\r\n@media only screen and (max-width:1440px) {\r\n    .large-grid--one-column>.grid__column {\r\n        width: 100%\r\n    }\r\n\r\n    .large-grid--two-columns>.grid__column {\r\n        width: 50%\r\n    }\r\n\r\n    .large-grid--three-columns>.grid__column {\r\n        width: 33.33333333%\r\n    }\r\n\r\n    .large-grid--four-columns>.grid__column {\r\n        width: 25%\r\n    }\r\n\r\n    .large-grid--five-columns>.grid__column {\r\n        width: 20%\r\n    }\r\n\r\n    .large-grid--six-columns>.grid__column {\r\n        width: 16.66666667%\r\n    }\r\n\r\n    .large-grid--seven-columns>.grid__column {\r\n        width: 14.28571429%\r\n    }\r\n\r\n    .large-grid--eight-columns>.grid__column {\r\n        width: 12.5%\r\n    }\r\n\r\n    .large-grid--nine-columns>.grid__column {\r\n        width: 11.11111111%\r\n    }\r\n\r\n    .large-grid--ten-columns>.grid__column {\r\n        width: 10%\r\n    }\r\n\r\n    .large-grid--eleven-columns>.grid__column {\r\n        width: 9.09090909%\r\n    }\r\n\r\n    .large-grid--twelfth-columns>.grid__column {\r\n        width: 8.33333333%\r\n    }\r\n}\r\n\r\n@media only screen and (max-width:991px) {\r\n    .tablet-grid--one-column>.grid__column {\r\n        width: 100%\r\n    }\r\n\r\n    .tablet-grid--two-columns>.grid__column {\r\n        width: 50%\r\n    }\r\n\r\n    .tablet-grid--three-columns>.grid__column {\r\n        width: 33.33333333%\r\n    }\r\n\r\n    .tablet-grid--four-columns>.grid__column {\r\n        width: 25%\r\n    }\r\n\r\n    .tablet-grid--five-columns>.grid__column {\r\n        width: 20%\r\n    }\r\n\r\n    .tablet-grid--six-columns>.grid__column {\r\n        width: 16.66666667%\r\n    }\r\n\r\n    .tablet-grid--seven-columns>.grid__column {\r\n        width: 14.28571429%\r\n    }\r\n\r\n    .tablet-grid--eight-columns>.grid__column {\r\n        width: 12.5%\r\n    }\r\n\r\n    .tablet-grid--nine-columns>.grid__column {\r\n        width: 11.11111111%\r\n    }\r\n\r\n    .tablet-grid--ten-columns>.grid__column {\r\n        width: 10%\r\n    }\r\n\r\n    .tablet-grid--eleven-columns>.grid__column {\r\n        width: 9.09090909%\r\n    }\r\n\r\n    .tablet-grid--twelfth-columns>.grid__column {\r\n        width: 8.33333333%\r\n    }\r\n}\r\n\r\n@media only screen and (max-width:768px) {\r\n    .mobile-grid--one-column>.grid__column {\r\n        width: 100%\r\n    }\r\n\r\n    .mobile-grid--two-columns>.grid__column {\r\n        width: 50%\r\n    }\r\n\r\n    .mobile-grid--three-columns>.grid__column {\r\n        width: 33.33333333%\r\n    }\r\n\r\n    .mobile-grid--four-columns>.grid__column {\r\n        width: 25%\r\n    }\r\n\r\n    .mobile-grid--five-columns>.grid__column {\r\n        width: 20%\r\n    }\r\n\r\n    .mobile-grid--six-columns>.grid__column {\r\n        width: 16.66666667%\r\n    }\r\n\r\n    .mobile-grid--seven-columns>.grid__column {\r\n        width: 14.28571429%\r\n    }\r\n\r\n    .mobile-grid--eight-columns>.grid__column {\r\n        width: 12.5%\r\n    }\r\n\r\n    .mobile-grid--nine-columns>.grid__column {\r\n        width: 11.11111111%\r\n    }\r\n\r\n    .mobile-grid--ten-columns>.grid__column {\r\n        width: 10%\r\n    }\r\n\r\n    .mobile-grid--eleven-columns>.grid__column {\r\n        width: 9.09090909%\r\n    }\r\n\r\n    .mobile-grid--twelfth-columns>.grid__column {\r\n        width: 8.33333333%\r\n    }\r\n}\r\n\r\n.one-whole {\r\n    width: 100%\r\n}\r\n\r\n.one-half {\r\n    width: 50%\r\n}\r\n\r\n.one-twelfth {\r\n    width: 8.333%\r\n}\r\n\r\n.two-twelfths {\r\n    width: 16.666%\r\n}\r\n\r\n.three-twelfths {\r\n    width: 25%\r\n}\r\n\r\n.four-twelfths {\r\n    width: 33.333%\r\n}\r\n\r\n.five-twelfths {\r\n    width: 41.666%\r\n}\r\n\r\n.six-twelfths {\r\n    width: 50%\r\n}\r\n\r\n.seven-twelfths {\r\n    width: 58.333%\r\n}\r\n\r\n.eight-twelfths {\r\n    width: 66.666%\r\n}\r\n\r\n.nine-twelfths {\r\n    width: 75%\r\n}\r\n\r\n.ten-twelfths {\r\n    width: 83.333%\r\n}\r\n\r\n.eleven-twelfths {\r\n    width: 91.666%\r\n}\r\n\r\n.visible {\r\n    display: block !important\r\n}\r\n\r\n.hidden {\r\n    display: none !important\r\n}\r\n\r\n@media(max-width:768px) {\r\n    .mobile--one-whole {\r\n        width: 100%\r\n    }\r\n\r\n    .mobile--one-half {\r\n        width: 50%\r\n    }\r\n\r\n    .mobile--one-twelfth {\r\n        width: 8.333%\r\n    }\r\n\r\n    .mobile--two-twelfths {\r\n        width: 16.666%\r\n    }\r\n\r\n    .mobile--three-twelfths {\r\n        width: 25%\r\n    }\r\n\r\n    .mobile--four-twelfths {\r\n        width: 33.333%\r\n    }\r\n\r\n    .mobile--five-twelfths {\r\n        width: 41.666%\r\n    }\r\n\r\n    .mobile--six-twelfths {\r\n        width: 50%\r\n    }\r\n\r\n    .mobile--seven-twelfths {\r\n        width: 58.333%\r\n    }\r\n\r\n    .mobile--eight-twelfths {\r\n        width: 66.666%\r\n    }\r\n\r\n    .mobile--nine-twelfths {\r\n        width: 75%\r\n    }\r\n\r\n    .mobile--ten-twelfths {\r\n        width: 83.333%\r\n    }\r\n\r\n    .mobile--eleven-twelfths {\r\n        width: 91.666%\r\n    }\r\n\r\n    .mobile--visible {\r\n        display: block !important\r\n    }\r\n\r\n    .mobile--hidden {\r\n        display: none !important\r\n    }\r\n}\r\n\r\n@media(min-width:769px) and (max-width:991px) {\r\n    .tablet--one-whole {\r\n        width: 100%\r\n    }\r\n\r\n    .tablet--one-half {\r\n        width: 50%\r\n    }\r\n\r\n    .tablet--one-twelfth {\r\n        width: 8.333%\r\n    }\r\n\r\n    .tablet--two-twelfths {\r\n        width: 16.666%\r\n    }\r\n\r\n    .tablet--three-twelfths {\r\n        width: 25%\r\n    }\r\n\r\n    .tablet--four-twelfths {\r\n        width: 33.333%\r\n    }\r\n\r\n    .tablet--five-twelfths {\r\n        width: 41.666%\r\n    }\r\n\r\n    .tablet--six-twelfths {\r\n        width: 50%\r\n    }\r\n\r\n    .tablet--seven-twelfths {\r\n        width: 58.333%\r\n    }\r\n\r\n    .tablet--eight-twelfths {\r\n        width: 66.666%\r\n    }\r\n\r\n    .tablet--nine-twelfths {\r\n        width: 75%\r\n    }\r\n\r\n    .tablet--ten-twelfths {\r\n        width: 83.333%\r\n    }\r\n\r\n    .tablet--eleven-twelfths {\r\n        width: 91.666%\r\n    }\r\n\r\n    .tablet--visible {\r\n        display: block !important\r\n    }\r\n\r\n    .tablet--hidden {\r\n        display: none !important\r\n    }\r\n}\r\n\r\n@media(min-width:1200px) and (max-width:1439px) {\r\n    .desk--one-whole {\r\n        width: 100%\r\n    }\r\n\r\n    .desk--one-half {\r\n        width: 50%\r\n    }\r\n\r\n    .desk--one-twelfth {\r\n        width: 8.333%\r\n    }\r\n\r\n    .desk--two-twelfths {\r\n        width: 16.666%\r\n    }\r\n\r\n    .desk--three-twelfths {\r\n        width: 25%\r\n    }\r\n\r\n    .desk--four-twelfths {\r\n        width: 33.333%\r\n    }\r\n\r\n    .desk--five-twelfths {\r\n        width: 41.666%\r\n    }\r\n\r\n    .desk--six-twelfths {\r\n        width: 50%\r\n    }\r\n\r\n    .desk--seven-twelfths {\r\n        width: 58.333%\r\n    }\r\n\r\n    .desk--eight-twelfths {\r\n        width: 66.666%\r\n    }\r\n\r\n    .desk--nine-twelfths {\r\n        width: 75%\r\n    }\r\n\r\n    .desk--ten-twelfths {\r\n        width: 83.333%\r\n    }\r\n\r\n    .desk--eleven-twelfths {\r\n        width: 91.666%\r\n    }\r\n\r\n    .desk--visible {\r\n        display: block !important\r\n    }\r\n\r\n    .desk--hidden {\r\n        display: none !important\r\n    }\r\n}\r\n\r\n@media(min-width:769px) and (max-width:991px) {\r\n    .grid--doubling.grid--two-columns>.grid__column {\r\n        width: 100%\r\n    }\r\n\r\n    .grid--doubling.grid--four-columns>.grid__column,\r\n    .grid--doubling.grid--three-columns>.grid__column {\r\n        width: 50%\r\n    }\r\n\r\n    .grid--doubling.grid--five-columns>.grid__column,\r\n    .grid--doubling.grid--seven-columns>.grid__column,\r\n    .grid--doubling.grid--six-columns>.grid__column {\r\n        width: 33.33333333%\r\n    }\r\n\r\n    .grid--doubling.grid--eight-columns>.grid__column {\r\n        width: 25%\r\n    }\r\n\r\n    .grid--doubling.grid--eleven-columns>.grid__column,\r\n    .grid--doubling.grid--nine-columns>.grid__column,\r\n    .grid--doubling.grid--ten-columns>.grid__column {\r\n        width: 20%\r\n    }\r\n\r\n    .grid--doubling.grid--twelfth-columns>.grid__column {\r\n        width: 16.66666667%\r\n    }\r\n}\r\n\r\n@media(max-width:768px) {\r\n\r\n    .grid--doubling.grid--five-columns>.grid__column,\r\n    .grid--doubling.grid--four-columns>.grid__column,\r\n    .grid--doubling.grid--three-columns>.grid__column,\r\n    .grid--doubling.grid--two-columns>.grid__column {\r\n        width: 100%\r\n    }\r\n\r\n    .grid--doubling.grid--eight-columns>.grid__column,\r\n    .grid--doubling.grid--nine-columns>.grid__column,\r\n    .grid--doubling.grid--seven-columns>.grid__column,\r\n    .grid--doubling.grid--six-columns>.grid__column {\r\n        width: 50%\r\n    }\r\n\r\n    .grid--doubling.grid--elevent-columns>.grid__column,\r\n    .grid--doubling.grid--ten-columns>.grid__column,\r\n    .grid--doubling.grid--twelfth-columns>.grid__column {\r\n        width: 33.3333%\r\n    }\r\n}\r\n\r\n@media(min-width:1440px) {\r\n    .large--visible {\r\n        display: block !important\r\n    }\r\n\r\n    .large--hidden {\r\n        display: none !important\r\n    }\r\n}\r\n\r\n.notify {\r\n    position: fixed;\r\n    top: 20px;\r\n    right: -300px;\r\n    width: 300px;\r\n    transition: all .2s;\r\n    box-sizing: border-box;\r\n    z-index: 99999;\r\n    background: #fff;\r\n    border: 1px solid #d9d9d9;\r\n    box-shadow: 0 0 8px rgba(0, 0, 0, .15);\r\n    border-radius: 16px;\r\n    padding: 18px;\r\n    touch-action: pan-y\r\n}\r\n\r\n.notify.error {\r\n    border: 2px solid #ff3102;\r\n    box-shadow: none\r\n}\r\n\r\n.notify.is-active {\r\n    right: 20px\r\n}\r\n\r\n.notify__close {\r\n    display: none\r\n}\r\n\r\n.notify__message {\r\n    font-weight: 500;\r\n    font-size: 14px;\r\n    line-height: 18px;\r\n    letter-spacing: .03em;\r\n    color: #000;\r\n    margin-bottom: 0\r\n}\r\n\r\n.notify.error .notify__message {\r\n    color: #ff3102\r\n}\r\n\r\n.notify .btn {\r\n    margin-top: 10px;\r\n    font-size: 16px;\r\n    width: 100%\r\n}\r\n\r\n.notify-product {\r\n    display: flex;\r\n    padding-top: 15px;\r\n    border-top: 1px solid #d9d9d9;\r\n    margin-top: 15px;\r\n    padding-bottom: 5px\r\n}\r\n\r\n.notify-product__thumbnail {\r\n    width: 25%;\r\n    overflow: hidden;\r\n    border-radius: 10px;\r\n    position: relative\r\n}\r\n\r\n.notify-product__thumbnail:before {\r\n    content: \"\";\r\n    display: block;\r\n    padding-top: 147.26507714%;\r\n    height: 0;\r\n    width: 100%\r\n}\r\n\r\n.notify-product__thumbnail img {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: cover;\r\n    object-fit: cover\r\n}\r\n\r\n.notify-product__content {\r\n    display: flex;\r\n    flex-flow: column;\r\n    width: 75%;\r\n    padding-left: 10px\r\n}\r\n\r\n.notify-product__title {\r\n    flex: 1;\r\n    font-weight: 500;\r\n    font-size: 14px;\r\n    line-height: 115%;\r\n    letter-spacing: .03em;\r\n    color: #000\r\n}\r\n\r\n.notify-product__options,\r\n.notify-product__prices {\r\n    font-size: 14px;\r\n    line-height: 150%;\r\n    letter-spacing: .03em;\r\n    color: #000\r\n}\r\n\r\n.notify-product__prices {\r\n    display: flex;\r\n    flex-flow: row-reverse;\r\n    align-items: flex-end;\r\n    justify-content: flex-end\r\n}\r\n\r\n.notify-product__prices ins {\r\n    text-decoration: none\r\n}\r\n\r\n.notify-product__prices del {\r\n    color: #c4c4c4\r\n}\r\n\r\n.notify-product__prices del+ins {\r\n    color: #ff3102;\r\n    margin-right: 10px\r\n}\r\n\r\n.fade-enter-active,\r\n.fade-leave-active {\r\n    transition: opacity .2s\r\n}\r\n\r\n.fade-enter,\r\n.fade-leave-to {\r\n    opacity: 0\r\n}\r\n\r\n.slide-enter-active,\r\n.slide-leave-active {\r\n    transition: all .5s;\r\n    overflow: hidden\r\n}\r\n\r\n.slide-enter-to,\r\n.slide-leave {\r\n    max-height: 100vh\r\n}\r\n\r\n.slide-enter,\r\n.slide-leave-to {\r\n    max-height: 0\r\n}\r\n\r\n@-webkit-keyframes fade-pulse {\r\n    0% {\r\n        background-color: #eee\r\n    }\r\n\r\n    50% {\r\n        background-color: #dfdfdf\r\n    }\r\n\r\n    to {\r\n        background-color: #eee\r\n    }\r\n}\r\n\r\n@keyframes fade-pulse {\r\n    0% {\r\n        background-color: #eee\r\n    }\r\n\r\n    50% {\r\n        background-color: #dfdfdf\r\n    }\r\n\r\n    to {\r\n        background-color: #eee\r\n    }\r\n}\r\n\r\n.is-vloading {\r\n    position: relative;\r\n    overflow: hidden !important\r\n}\r\n\r\n.is-vloading :not(.loading) {\r\n    opacity: 0;\r\n    visibility: hidden\r\n}\r\n\r\n.is-vloading.vloading-expand {\r\n    min-height: 100px\r\n}\r\n\r\n.is-vloading .loading {\r\n    content: \"\";\r\n    width: 100%;\r\n    height: 100%;\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0\r\n}\r\n\r\n.is-vloading .loading.blank {\r\n    min-height: 100px\r\n}\r\n\r\n.is-vloading .loading.fade-pulse {\r\n    background-color: #eee;\r\n    border-radius: 16px;\r\n    -webkit-animation: fade-pulse 1s infinite;\r\n    animation: fade-pulse 1s infinite\r\n}\r\n\r\n.is-vloading .loading.classic {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center\r\n}\r\n\r\n.is-vloading .loading.classic img {\r\n    opacity: 1;\r\n    visibility: unset;\r\n    height: 50%;\r\n    max-height: 100px\r\n}\r\n\r\n.btn {\r\n    display: inline-flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    height: 40px;\r\n    border-radius: 16px;\r\n    border: 2px solid #000;\r\n    background-color: #000;\r\n    color: #fff;\r\n    padding: 0 30px;\r\n    transition: all .2s;\r\n    cursor: pointer\r\n}\r\n\r\n.btn:hover {\r\n    color: #000;\r\n    background-color: #d9d9d9;\r\n    border: 2px solid #d9d9d9\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .btn {\r\n        font-size: 12px;\r\n        padding: 0 16px;\r\n        height: 30px;\r\n        border-radius: 12px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .btn {\r\n        font-size: 12px;\r\n        padding: 0 16px;\r\n        height: 30px;\r\n        border-radius: 12px\r\n    }\r\n}\r\n\r\n.btn.btn-primary {\r\n    background-color: #2f5acf;\r\n    border: none\r\n}\r\n\r\n.btn.btn-primary:hover {\r\n    background-color: #000;\r\n    color: #fff\r\n}\r\n\r\n.btn.btn-secondary {\r\n    background-color: #d9d9d9;\r\n    border: none;\r\n    color: #000\r\n}\r\n\r\n.btn.btn-secondary:hover {\r\n    background-color: #000;\r\n    color: #fff\r\n}\r\n\r\n.btn.btn-block {\r\n    display: block;\r\n    width: 100%\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .btn.btn-block-sm {\r\n        display: block;\r\n        width: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .btn.btn-block-sm {\r\n        display: block;\r\n        width: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:769px) and (max-width:991px) {\r\n    .btn.btn-block-lg {\r\n        display: block;\r\n        width: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:992px) and (max-width:1200px) {\r\n    .btn.btn-block-lg {\r\n        display: block;\r\n        width: 100%\r\n    }\r\n}\r\n\r\n.btn.btn-sm {\r\n    height: 31px;\r\n    font-size: 12px\r\n}\r\n\r\n.btn.btn-lg {\r\n    height: 43px\r\n}\r\n\r\n.btn:disabled {\r\n    background-color: #d9d9d9;\r\n    color: #fff;\r\n    cursor: not-allowed;\r\n    border: 1px solid #d9d9d9\r\n}\r\n\r\n.btn--white {\r\n    background-color: #fff;\r\n    color: #000;\r\n    border: 2px solid #fff\r\n}\r\n\r\n.btn--white:hover {\r\n    background-color: #d9d9d9;\r\n    border: 2px solid #d9d9d9;\r\n    color: #000\r\n}\r\n\r\n.btn--outline {\r\n    background-color: transparent;\r\n    color: #000\r\n}\r\n\r\n.btn--outline:hover {\r\n    background-color: #000;\r\n    color: #fff;\r\n    border: solid #000\r\n}\r\n\r\n.btn--primary {\r\n    background-color: #f9f86c;\r\n    color: #000;\r\n    border: 2px solid #f9f86c\r\n}\r\n\r\n.badge {\r\n    display: inline-block;\r\n    background-color: #000;\r\n    color: #fff;\r\n    font-size: 10px;\r\n    height: 17px;\r\n    line-height: 17px;\r\n    padding: 0 10px;\r\n    font-weight: 500;\r\n    border-radius: 8px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .badge {\r\n        font-size: 8px;\r\n        height: 14px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .badge {\r\n        font-size: 8px;\r\n        height: 14px\r\n    }\r\n}\r\n\r\n.badge-sm {\r\n    font-size: 8px;\r\n    height: 14px\r\n}\r\n\r\n.badge-yellow {\r\n    color: #000;\r\n    background-color: #f9f86c\r\n}\r\n\r\n.badge-red {\r\n    background-color: #ff2459\r\n}\r\n\r\n.badge-blue {\r\n    background-color: #2f5acf\r\n}\r\n\r\n.custom-checkbox,\r\n.custom-radio {\r\n    display: block;\r\n    position: relative;\r\n    flex: 0 0 20px;\r\n    width: 20px;\r\n    height: 20px;\r\n    border: 1px solid #d9d9d9;\r\n    border-radius: 20px;\r\n    transition: all .2s\r\n}\r\n\r\n.custom-checkbox-label,\r\n.custom-radio-label {\r\n    display: flex;\r\n    cursor: pointer\r\n}\r\n\r\n.active.custom-checkbox,\r\n.custom-radio.active {\r\n    border: 1px solid #2f5acf\r\n}\r\n\r\n.custom-checkbox input,\r\n.custom-radio input {\r\n    display: none\r\n}\r\n\r\n.custom-checkbox input:checked~.checkmark,\r\n.custom-radio input:checked~.checkmark {\r\n    display: block\r\n}\r\n\r\n.custom-checkbox .checkmark,\r\n.custom-radio .checkmark {\r\n    display: none;\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    transform: translate(-50%, -50%);\r\n    width: 10px;\r\n    height: 10px;\r\n    border-radius: 20px;\r\n    background-color: #2f5acf\r\n}\r\n\r\n.custom-checkbox~.label,\r\n.custom-radio~.label {\r\n    display: block;\r\n    margin-left: 10px;\r\n    font-weight: 600\r\n}\r\n\r\n.custom-checkbox {\r\n    border-radius: 5px\r\n}\r\n\r\n.custom-checkbox .checkmark {\r\n    transform: translate(-50%, -63%) rotate(45deg);\r\n    border-bottom: 3px solid #2f5acf;\r\n    border-right: 3px solid #2f5acf;\r\n    width: 7px;\r\n    height: 10px;\r\n    border-radius: 0;\r\n    background-color: transparent;\r\n    cursor: pointer\r\n}\r\n\r\n.form-group:not(:last-child) {\r\n    margin-bottom: 1rem\r\n}\r\n\r\n.form-control,\r\n.vue-select .vs__dropdown-toggle {\r\n    background: #fff;\r\n    border: 1px solid #d9d9d9;\r\n    box-sizing: border-box;\r\n    border-radius: 16px;\r\n    height: 40px;\r\n    width: 100%;\r\n    padding: 5px 20px;\r\n    transition: all .2s\r\n}\r\n\r\n.form-control:active,\r\n.form-control:focus,\r\n.vue-select .vs__dropdown-toggle:active,\r\n.vue-select .vs__dropdown-toggle:focus {\r\n    border: 1px solid #2f5acf\r\n}\r\n\r\n.form-control.has-error,\r\n.vue-select .has-error.vs__dropdown-toggle {\r\n    border: 1px solid #ff2459;\r\n    position: relative\r\n}\r\n\r\n.form-control.has-error:after,\r\n.vue-select .has-error.vs__dropdown-toggle:after {\r\n    content: \"\";\r\n    display: block;\r\n    position: absolute;\r\n    width: 8px;\r\n    height: 8px;\r\n    background: #ff2459;\r\n    top: 50%;\r\n    right: 5px;\r\n    transform: translateY(-50%)\r\n}\r\n\r\n.form-control~.error-text,\r\n.vue-select .vs__dropdown-toggle~.error-text {\r\n    color: #ff2459;\r\n    display: block;\r\n    padding: 0 1rem\r\n}\r\n\r\n.vue-select textarea.vs__dropdown-toggle,\r\ntextarea.form-control {\r\n    height: auto;\r\n    resize: none;\r\n    padding: 10px 20px\r\n}\r\n\r\n.vue-select .vs__dropdown-toggle {\r\n    padding: 5px 10px 5px 20px\r\n}\r\n\r\n.vue-select .vs__dropdown-toggle[aria-expanded=true] {\r\n    z-index: 1001;\r\n    position: relative;\r\n    background: #d9d9d9\r\n}\r\n\r\n.vue-select .vs__selected,\r\n.vue-select .vs__selected-options {\r\n    padding: 0;\r\n    margin: 0;\r\n    align-items: center\r\n}\r\n\r\n.vue-select .vs__search {\r\n    margin: 0;\r\n    padding: 0\r\n}\r\n\r\n.vue-select .vs__search:disabled {\r\n    background-color: transparent\r\n}\r\n\r\n.vue-select .vs__dropdown-menu {\r\n    top: calc(100% - 16px);\r\n    padding-top: 21px;\r\n    box-shadow: none;\r\n    border-radius: 0 0 16px 16px\r\n}\r\n\r\n.vue-select .vs__open-indicator {\r\n    transform: scale(.8)\r\n}\r\n\r\n.vue-select.vs--open .vs__open-indicator {\r\n    transform: scale(.8) rotate(180deg) !important\r\n}\r\n\r\n.vue-select .vs__dropdown-option--highlight {\r\n    background-color: #d9d9d9;\r\n    color: #000\r\n}\r\n\r\n.vue-select.has-error .vs__dropdown-toggle {\r\n    border: 1px solid #ff2459;\r\n    position: relative\r\n}\r\n\r\n.vue-select~.error-text {\r\n    color: #ff2459;\r\n    display: block;\r\n    padding: 0 1rem\r\n}\r\n\r\n.popup {\r\n    width: 100%;\r\n    height: 100%;\r\n    position: fixed;\r\n    top: 0;\r\n    left: 0;\r\n    z-index: 11\r\n}\r\n\r\n.popup .backdrop {\r\n    width: 100%;\r\n    height: 100%;\r\n    background-color: rgba(0, 0, 0, .7)\r\n}\r\n\r\n.popup .popup-body {\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    width: 50vw;\r\n    max-width: 600px;\r\n    transform: translate(-50%, -50%);\r\n    background-color: #fff;\r\n    padding: 2rem;\r\n    border-radius: 16px;\r\n    max-height: 95vh;\r\n    overflow-y: auto;\r\n    overflow-x: hidden;\r\n    -webkit-overflow-scrolling: touch\r\n}\r\n\r\n.popup .popup-body::-webkit-scrollbar {\r\n    height: 5px\r\n}\r\n\r\n.popup .popup-body::-webkit-scrollbar-track {\r\n    background: #fff\r\n}\r\n\r\n.popup .popup-body::-webkit-scrollbar-thumb {\r\n    background: #fff;\r\n    border-radius: 10px\r\n}\r\n\r\n.popup .popup-body:hover::-webkit-scrollbar-thumb {\r\n    background: #a9a9a9\r\n}\r\n\r\n.popup .popup-body:hover::-webkit-scrollbar-track {\r\n    background: #d9d9d9\r\n}\r\n\r\n.popup .popup-body::-webkit-scrollbar-thumb:hover {\r\n    background: #555\r\n}\r\n\r\n.popup .popup-body .close-popup {\r\n    cursor: pointer;\r\n    position: absolute;\r\n    top: 10px;\r\n    right: 15px\r\n}\r\n\r\n.popup .popup-body .close-popup:active,\r\n.popup .popup-body .close-popup:hover {\r\n    transform: scale(1.1)\r\n}\r\n\r\n.popup .popup-body.popup-lg {\r\n    width: 70vw;\r\n    max-width: 1080px;\r\n    min-height: 70vh\r\n}\r\n\r\n.popup .popup-body.popup-xl {\r\n    width: 90vw;\r\n    max-width: 1920px;\r\n    min-height: 90vh\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .popup .popup-body.popup-xl {\r\n        padding-top: 40px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .popup .popup-body.popup-xl {\r\n        padding-top: 40px\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .popup .popup-body.popup-lg,\r\n    .popup .popup-body.popup-xl {\r\n        width: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .popup .popup-body.popup-lg,\r\n    .on-mobile .popup .popup-body.popup-xl {\r\n        width: 100%\r\n    }\r\n}\r\n\r\n.popup .popup-footer {\r\n    margin-top: 1rem;\r\n    display: flex;\r\n    justify-content: space-around\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .popup {\r\n        z-index: 1001\r\n    }\r\n\r\n    .popup .popup-body {\r\n        width: 100%;\r\n        padding: 1rem 1.5rem 2rem;\r\n        top: auto;\r\n        left: 0;\r\n        bottom: 0;\r\n        border: 1px solid #d9d9d9;\r\n        transform: none\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .popup {\r\n        z-index: 1001\r\n    }\r\n\r\n    .on-mobile .popup .popup-body {\r\n        width: 100%;\r\n        padding: 1rem 1.5rem 2rem;\r\n        top: auto;\r\n        left: 0;\r\n        bottom: 0;\r\n        border: 1px solid #d9d9d9;\r\n        transform: none\r\n    }\r\n}\r\n\r\n.popup--slide .popup-body {\r\n    height: 100%;\r\n    max-width: 250px;\r\n    left: auto;\r\n    right: 0;\r\n    border-top-right-radius: 0;\r\n    border-bottom-right-radius: 0\r\n}\r\n\r\n.popup-enter .backdrop,\r\n.popup-leave-to .backdrop {\r\n    opacity: 0\r\n}\r\n\r\n.popup-enter .popup-body,\r\n.popup-leave-to .popup-body {\r\n    transform: translate(-50%, 100vh) !important\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .popup-enter .popup-body,\r\n    .popup-leave-to .popup-body {\r\n        transform: translateY(100vh) !important\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .popup-enter .popup-body,\r\n    .popup-leave-to .popup-body {\r\n        transform: translateY(100vh) !important\r\n    }\r\n}\r\n\r\n.popup-enter.popup--slide .popup-body,\r\n.popup-leave-to.popup--slide .popup-body {\r\n    transform: translateX(100vw) !important\r\n}\r\n\r\n.popup-enter-active,\r\n.popup-enter-active .backdrop,\r\n.popup-enter-active .popup-body,\r\n.popup-leave-active,\r\n.popup-leave-active .backdrop,\r\n.popup-leave-active .popup-body {\r\n    transition: all .3s ease\r\n}\r\n\r\n.popup-leave-to {\r\n    pointer-events: none !important\r\n}\r\n\r\n.table {\r\n    width: 100%;\r\n    border-spacing: 0;\r\n    background: #d9d9d9;\r\n    border-radius: 16px\r\n}\r\n\r\n.table td,\r\n.table th {\r\n    padding: 10px 20px\r\n}\r\n\r\n.table thead>tr th {\r\n    color: #fff;\r\n    background-color: #2f5acf;\r\n    font-weight: 500\r\n}\r\n\r\n.table thead>tr th:first-child {\r\n    border-radius: 16px 0 0 16px\r\n}\r\n\r\n.table thead>tr th:last-child {\r\n    border-radius: 0 16px 16px 0\r\n}\r\n\r\n.table tbody tr:nth-child(2n) td {\r\n    background-color: #eee\r\n}\r\n\r\n.table tbody tr:not(:nth-child(2n)) td {\r\n    background-color: #d9d9d9\r\n}\r\n\r\n.table tbody tr:last-child td:first-child {\r\n    border-radius: 0 0 0 16px\r\n}\r\n\r\n.table tbody tr:last-child td:last-child {\r\n    border-radius: 0 0 16px 0\r\n}\r\n\r\n.site-table {\r\n    border-collapse: separate;\r\n    border-spacing: 0;\r\n    font-weight: 500;\r\n    font-size: 12px;\r\n    line-height: 15px;\r\n    letter-spacing: .03em;\r\n    border: 1px solid #d9d9d9;\r\n    border-radius: 16px\r\n}\r\n\r\n.site-table .site-table__title {\r\n    white-space: nowrap\r\n}\r\n\r\n.site-table .sub-text {\r\n    display: block\r\n}\r\n\r\n.site-table td {\r\n    padding: 14px 18px\r\n}\r\n\r\n.site-table thead {\r\n    position: relative;\r\n    color: #fff;\r\n    border-radius: 16px;\r\n    z-index: 2\r\n}\r\n\r\n.site-table thead td {\r\n    position: relative;\r\n    z-index: 1;\r\n    background-color: #2f5acf\r\n}\r\n\r\n.site-table thead td:first-of-type {\r\n    border-top-left-radius: 16px;\r\n    border-bottom-left-radius: 16px\r\n}\r\n\r\n.site-table thead td:last-of-type {\r\n    border-top-right-radius: 16px;\r\n    border-bottom-right-radius: 16px\r\n}\r\n\r\n.site-table tbody {\r\n    z-index: 1\r\n}\r\n\r\n.site-table tbody tr {\r\n    position: relative\r\n}\r\n\r\n.site-table tbody tr td {\r\n    position: relative;\r\n    border-bottom: 1px solid #d9d9d9\r\n}\r\n\r\n.site-table tbody tr td:first-of-type {\r\n    border-bottom-left-radius: 16px\r\n}\r\n\r\n.site-table tbody tr td:last-of-type {\r\n    border-bottom-right-radius: 16px\r\n}\r\n\r\n.site-table tbody tr:last-of-type td {\r\n    border-bottom: 0\r\n}\r\n\r\n.size-table table td {\r\n    padding: 5px 0;\r\n    height: 42px;\r\n    font-size: 11px\r\n}\r\n\r\n.size-table table td:first-of-type {\r\n    padding-left: 18px\r\n}\r\n\r\n.size-table__description {\r\n    margin-top: 27px;\r\n    font-weight: 400;\r\n    font-size: 10px;\r\n    line-height: 13px;\r\n    letter-spacing: .03em;\r\n    color: #000\r\n}\r\n\r\n.product-loading .product-grid__thumbnail {\r\n    background-image: linear-gradient(90deg, #ececec, #f4f4f4 40px, #ececec 80px);\r\n    -webkit-animation: shine-loading-image 2s ease-out infinite;\r\n    animation: shine-loading-image 2s ease-out infinite\r\n}\r\n\r\n.product-loading .product-grid__content {\r\n    background: #f7f7f7;\r\n    padding: 15px\r\n}\r\n\r\n.product-loading .product-grid__title {\r\n    height: 10px;\r\n    margin-bottom: 10px;\r\n    border-radius: 10px\r\n}\r\n\r\n.product-loading .product-grid__prices,\r\n.product-loading .product-grid__title {\r\n    background: #ececec;\r\n    background-image: linear-gradient(90deg, #ececec, #ddd 40px, #ececec 80px);\r\n    -webkit-animation: shine-loading-container-items 2s ease-out infinite;\r\n    animation: shine-loading-container-items 2s ease-out infinite\r\n}\r\n\r\n.product-loading .product-grid__prices {\r\n    width: 60px;\r\n    height: 25px;\r\n    border-radius: 3px\r\n}\r\n\r\n@-webkit-keyframes shine-loading-image {\r\n    0% {\r\n        background-position: -32px\r\n    }\r\n\r\n    40%,\r\n    to {\r\n        background-position: 208px\r\n    }\r\n}\r\n\r\n@keyframes shine-loading-image {\r\n    0% {\r\n        background-position: -32px\r\n    }\r\n\r\n    40%,\r\n    to {\r\n        background-position: 208px\r\n    }\r\n}\r\n\r\n@-webkit-keyframes shine-loading-container-items {\r\n    0% {\r\n        background-position: -100px\r\n    }\r\n\r\n    40%,\r\n    to {\r\n        background-position: 140px\r\n    }\r\n}\r\n\r\n@keyframes shine-loading-container-items {\r\n    0% {\r\n        background-position: -100px\r\n    }\r\n\r\n    40%,\r\n    to {\r\n        background-position: 140px\r\n    }\r\n}\r\n\r\nbody:before {\r\n    content: \"\";\r\n    position: fixed;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    background: rgba(77, 77, 77, .69);\r\n    z-index: 9;\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: hidden;\r\n    transition: all .3s\r\n}\r\n\r\nbody.backdrop:before {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible\r\n}\r\n\r\nbody .site-content {\r\n    min-height: 300px\r\n}\r\n\r\n.site-wrapper {\r\n    padding-top: 80px\r\n}\r\n\r\n@media only screen and (max-width:1200px) {\r\n    .site-wrapper {\r\n        overflow: hidden\r\n    }\r\n}\r\n\r\n.title {\r\n    font-size: 30px;\r\n    font-weight: 700;\r\n    margin: 2rem 0 1rem\r\n}\r\n\r\n.title-with-actions {\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: center;\r\n    margin: 2rem 0 1rem\r\n}\r\n\r\n.title-with-actions .title {\r\n    margin: 0\r\n}\r\n\r\n.title-with-actions .action a {\r\n    color: #2f5acf\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .title-with-actions {\r\n        flex-flow: column\r\n    }\r\n\r\n    .title-with-actions .action,\r\n    .title-with-actions .title {\r\n        width: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .title-with-actions {\r\n        flex-flow: column\r\n    }\r\n\r\n    .on-mobile .title-with-actions .action,\r\n    .on-mobile .title-with-actions .title {\r\n        width: 100%\r\n    }\r\n}\r\n\r\ndel {\r\n    color: #ccc\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .grid {\r\n        margin-left: -4px;\r\n        margin-right: -4px\r\n    }\r\n\r\n    .grid__column {\r\n        padding: 4px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .grid {\r\n        margin-left: -4px;\r\n        margin-right: -4px\r\n    }\r\n\r\n    .on-mobile .grid__column {\r\n        padding: 4px\r\n    }\r\n}\r\n\r\n.breadcrumb {\r\n    padding-bottom: 25px\r\n}\r\n\r\n.breadcrumb .page-breadcrumb {\r\n    display: flex;\r\n    padding: 0;\r\n    margin: 0\r\n}\r\n\r\n.breadcrumb .page-breadcrumb li {\r\n    list-style: none\r\n}\r\n\r\n.breadcrumb .page-breadcrumb li a {\r\n    color: grey\r\n}\r\n\r\n.breadcrumb .page-breadcrumb li a:hover {\r\n    color: #2f5acf\r\n}\r\n\r\n.breadcrumb .page-breadcrumb li+li:before {\r\n    content: \"/\";\r\n    display: inline-block;\r\n    margin: 0 5px\r\n}\r\n\r\n.breadcrumb .page-breadcrumb li:last-of-type a {\r\n    color: #000\r\n}\r\n\r\n.breadcrumb .page-breadcrumb li:last-of-type a:hover {\r\n    color: #2f5acf\r\n}\r\n\r\n.order-time__wrapper {\r\n    padding: 50px;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center\r\n}\r\n\r\n.order-time__item {\r\n    position: relative;\r\n    width: 15px;\r\n    height: 15px;\r\n    margin-right: 50px\r\n}\r\n\r\n.order-time__item,\r\n.order-time__item:before {\r\n    border-radius: 100px;\r\n    background-color: #2f5acf\r\n}\r\n\r\n.order-time__item:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: 50%;\r\n    width: 40px;\r\n    height: 3px;\r\n    left: 100%;\r\n    margin-left: 5px;\r\n    margin-right: 5px;\r\n    transform: translateY(-50%)\r\n}\r\n\r\n.order-time__item span {\r\n    position: absolute;\r\n    bottom: 100%;\r\n    left: 50%;\r\n    transform: translateX(-50%);\r\n    margin-bottom: 10px;\r\n    background-color: #2f5acf;\r\n    border: 2px solid #2f5acf;\r\n    padding: 5px 10px;\r\n    border-radius: 3px;\r\n    color: #fff\r\n}\r\n\r\n.order-time__item span:before {\r\n    content: \"\";\r\n    width: 8px;\r\n    height: 8px;\r\n    position: absolute;\r\n    bottom: -6px;\r\n    left: 50%;\r\n    background-color: #2f5acf;\r\n    transform: translateX(-50%) rotate(-45deg);\r\n    border-bottom: 2px solid #2f5acf;\r\n    border-left: 2px solid #2f5acf\r\n}\r\n\r\n.order-time__item:nth-child(2n) span {\r\n    top: 100%;\r\n    bottom: auto;\r\n    margin-bottom: 0;\r\n    margin-top: 10px\r\n}\r\n\r\n.order-time__item:nth-child(2n) span:before {\r\n    top: -6px;\r\n    bottom: auto;\r\n    transform: translateX(-50%) rotate(135deg)\r\n}\r\n\r\n.order-time__item:last-child {\r\n    margin-right: 0\r\n}\r\n\r\n.order-time__item:last-child:before {\r\n    display: none\r\n}\r\n\r\n.order-time__item--none:after {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: 4px;\r\n    left: 4px;\r\n    width: 7px;\r\n    height: 7px;\r\n    border-radius: 100px;\r\n    background-color: #fff\r\n}\r\n\r\n.order-time__item--none span {\r\n    background-color: #fff;\r\n    color: #2f5acf\r\n}\r\n\r\n.order-time__item--none span:before {\r\n    background-color: #fff\r\n}\r\n\r\n@media screen and (max-width:768px) {\r\n    .order-time {\r\n        display: flex;\r\n        justify-content: center;\r\n        overflow-y: hidden;\r\n        overflow-x: auto;\r\n        -webkit-overflow-scrolling: touch;\r\n        max-width: 100vw\r\n    }\r\n\r\n    .order-time__item {\r\n        font-size: 12px;\r\n        margin-right: 35px\r\n    }\r\n\r\n    .order-time__item:before {\r\n        width: 25px\r\n    }\r\n\r\n    .order-time__wrapper {\r\n        padding: 45px 35px\r\n    }\r\n}\r\n\r\n.hide {\r\n    display: none !important\r\n}\r\n\r\n.is-new-user {\r\n    position: fixed;\r\n    right: 0;\r\n    top: 60%;\r\n    z-index: 9;\r\n    display: flex;\r\n    justify-content: flex-end;\r\n    align-items: center\r\n}\r\n\r\n.is-new-user__content {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    flex-flow: column;\r\n    background-color: #f6f6f6;\r\n    border-top-left-radius: 1rem;\r\n    border-bottom-left-radius: 1rem;\r\n    padding: 1rem;\r\n    max-width: 400px;\r\n    overflow: hidden;\r\n    transform: translateX(100%);\r\n    transition: all .3s\r\n}\r\n\r\n.is-new-user__content>* {\r\n    opacity: 0;\r\n    visibility: hidden;\r\n    pointer-events: none;\r\n    transition: all .3s\r\n}\r\n\r\n.is-new-user__title {\r\n    color: #2f5acf;\r\n    font-weight: 700;\r\n    text-align: center\r\n}\r\n\r\n.is-new-user__description {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center\r\n}\r\n\r\n.is-new-user__text {\r\n    font-size: 16px;\r\n    font-weight: 700;\r\n    margin: 0\r\n}\r\n\r\n.is-new-user__sale-number {\r\n    font-size: 50px;\r\n    color: red;\r\n    font-weight: 700\r\n}\r\n\r\n.is-new-user__info {\r\n    margin: 0\r\n}\r\n\r\n.is-new-user__field {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    padding-top: 10px\r\n}\r\n\r\n.is-new-user__control {\r\n    height: 35px;\r\n    border: 0;\r\n    background-color: #fff;\r\n    border-top-left-radius: 10px;\r\n    border-bottom-left-radius: 10px;\r\n    padding-left: 1rem\r\n}\r\n\r\n.is-new-user__button {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    width: 35px;\r\n    height: 35px;\r\n    background-color: #2f5acf;\r\n    border: 0;\r\n    color: #fff;\r\n    padding: .5rem;\r\n    border-top-right-radius: 5px;\r\n    border-bottom-right-radius: 5px;\r\n    cursor: pointer\r\n}\r\n\r\n.is-new-user__button:hover {\r\n    background-color: #000\r\n}\r\n\r\n.is-new-user__button svg path {\r\n    stroke: currentColor\r\n}\r\n\r\n.is-new-user__caption {\r\n    text-align: center\r\n}\r\n\r\n.is-new-user__toggle {\r\n    position: absolute;\r\n    top: 0;\r\n    right: 0;\r\n    width: 170px;\r\n    text-align: center;\r\n    color: #fff;\r\n    font-size: 20px;\r\n    font-weight: 700;\r\n    padding: 10px 20px;\r\n    display: block;\r\n    border-top-left-radius: 5px;\r\n    border-top-right-radius: 5px;\r\n    background-color: #ff3102;\r\n    transform: rotate(-90deg);\r\n    transform-origin: bottom right\r\n}\r\n\r\n.is-new-user__toggle:hover {\r\n    background-color: #000\r\n}\r\n\r\n.is-new-user__toggle>* {\r\n    display: inline-block;\r\n    transition: all .3s\r\n}\r\n\r\n.is-new-user__close {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    position: absolute;\r\n    left: 0;\r\n    top: 0;\r\n    width: 40px;\r\n    height: 40px;\r\n    padding: 13px\r\n}\r\n\r\n.is-new-user__close svg {\r\n    width: 100%;\r\n    height: 100%;\r\n    color: #000\r\n}\r\n\r\n.is-new-user__wrapper {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    flex-flow: column;\r\n    padding-top: 1rem;\r\n    padding-left: .5rem;\r\n    padding-right: .5rem\r\n}\r\n\r\n.is-new-user__helptext {\r\n    margin: 0;\r\n    color: #ff3102;\r\n    font-size: .8rem;\r\n    font-style: italic\r\n}\r\n\r\n.is-new-user__text2 {\r\n    font-style: italic;\r\n    font-size: .875rem;\r\n    color: #565656\r\n}\r\n\r\n.is-new-user__text2 ul {\r\n    padding: 0 0 0 1rem;\r\n    margin: 0\r\n}\r\n\r\n.is-new-user__black {\r\n    color: #000;\r\n    font-size: 20px\r\n}\r\n\r\n.is-new-user__black span {\r\n    color: red\r\n}\r\n\r\n.is-new-user__coupon {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    width: 100%;\r\n    border-radius: .3rem;\r\n    overflow: hidden\r\n}\r\n\r\n.is-new-user__coupon span {\r\n    height: 32px;\r\n    background: #fff;\r\n    display: flex;\r\n    align-items: center;\r\n    padding-left: 1rem;\r\n    padding-right: 1rem;\r\n    flex: 1\r\n}\r\n\r\n.is-new-user__coupon a {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    background: #2f5acf;\r\n    color: #fff;\r\n    height: 32px;\r\n    font-weight: 700;\r\n    padding: 0 1rem;\r\n    cursor: pointer\r\n}\r\n\r\n.is-new-user.active-popup .is-new-user__toggle {\r\n    opacity: 0\r\n}\r\n\r\n.is-new-user.active-popup .is-new-user__content {\r\n    transform: translateX(0);\r\n    box-shadow: 0 0 10px 0 rgba(0, 0, 0, .3333333333333333)\r\n}\r\n\r\n.is-new-user.active-popup .is-new-user__content>* {\r\n    opacity: 1;\r\n    transition-delay: .3s;\r\n    visibility: visible;\r\n    pointer-events: visible\r\n}\r\n\r\n.is-new-user.active-loading .is-new-user__content>* {\r\n    opacity: 0 !important;\r\n    transition-delay: 0s\r\n}\r\n\r\n@-webkit-keyframes isLoading {\r\n    0% {\r\n        transform: rotate(0deg)\r\n    }\r\n\r\n    to {\r\n        transform: rotate(1turn)\r\n    }\r\n}\r\n\r\n@keyframes isLoading {\r\n    0% {\r\n        transform: rotate(0deg)\r\n    }\r\n\r\n    to {\r\n        transform: rotate(1turn)\r\n    }\r\n}\r\n\r\n.is-new-user.active-loading .is-new-user__content:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: calc(50% - 12px);\r\n    left: calc(50% - 12px);\r\n    width: 24px;\r\n    height: 24px;\r\n    border: 3px solid #000;\r\n    border-top-color: transparent;\r\n    border-radius: 100px;\r\n    -webkit-animation: isLoading 1s linear infinite;\r\n    animation: isLoading 1s linear infinite\r\n}\r\n\r\n.popup-lixi {\r\n    position: relative;\r\n    background-color: #ededed;\r\n    border: 3px solid red;\r\n    border-radius: 1rem;\r\n    height: 300px;\r\n    width: 475px;\r\n    max-width: 100vw;\r\n    padding: 15px\r\n}\r\n\r\n.popup-lixi img {\r\n    position: absolute;\r\n    bottom: 0;\r\n    right: 0;\r\n    pointer-events: none\r\n}\r\n\r\n.popup-lixi__confirm,\r\n.popup-lixi__success {\r\n    display: flex;\r\n    align-items: flex-start;\r\n    flex-flow: column;\r\n    justify-content: flex-end;\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    padding: 15px\r\n}\r\n\r\n.popup-lixi__success {\r\n    background-image: url(https://mcdn.coolmate.me/image/January2023/mceclip1_12.png);\r\n    background-size: contain;\r\n    background-position: 50%;\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: hidden\r\n}\r\n\r\n.popup-lixi__success.is-active {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible\r\n}\r\n\r\n.popup-lixi__success img {\r\n    width: 50%;\r\n    bottom: 100%;\r\n    right: 15px;\r\n    transform: translate3d(0, 60%, 0)\r\n}\r\n\r\n.popup-lixi__success .is-new-user__field {\r\n    max-width: 75%;\r\n    font-weight: 700;\r\n    font-size: 24px;\r\n    line-height: 1.25rem;\r\n    color: #000\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .popup-lixi__success .is-new-user__field {\r\n        max-width: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .popup-lixi__success .is-new-user__field {\r\n        max-width: 100%\r\n    }\r\n}\r\n\r\n.popup-lixi__success .is-new-user__control {\r\n    display: flex;\r\n    align-items: center\r\n}\r\n\r\n.popup-lixi__success .is-new-user__button {\r\n    width: auto !important;\r\n    font-size: 18px;\r\n    white-space: nowrap\r\n}\r\n\r\n.popup-lixi__success.gift img {\r\n    bottom: 50%;\r\n    transform: translate3d(10%, 50%, 0);\r\n    width: 40%\r\n}\r\n\r\n.popup-lixi__success.gift .popup-lixi__title {\r\n    max-width: 60%\r\n}\r\n\r\n.popup-lixi__title {\r\n    display: block;\r\n    font-style: normal;\r\n    font-weight: 700;\r\n    font-size: 26px;\r\n    line-height: 1.25em;\r\n    color: #ef0000;\r\n    margin-bottom: 30px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .popup-lixi__title {\r\n        font-size: 18px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .popup-lixi__title {\r\n        font-size: 18px\r\n    }\r\n}\r\n\r\n.popup-lixi__title span {\r\n    display: block;\r\n    font-weight: 400;\r\n    font-size: 16px;\r\n    line-height: 1.25rem;\r\n    color: #000\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .popup-lixi__title span {\r\n        font-size: 14px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .popup-lixi__title span {\r\n        font-size: 14px\r\n    }\r\n}\r\n\r\n.popup-lixi__heading {\r\n    font-size: 50px;\r\n    font-weight: 700;\r\n    color: #ef0000;\r\n    line-height: 1.25em;\r\n    flex: 1;\r\n    display: flex;\r\n    align-items: center;\r\n    position: relative;\r\n    z-index: 1;\r\n    pointer-events: none\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .popup-lixi__heading {\r\n        font-size: 28px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .popup-lixi__heading {\r\n        font-size: 28px\r\n    }\r\n}\r\n\r\n.popup-lixi .is-new-user__form {\r\n    position: relative;\r\n    z-index: 1\r\n}\r\n\r\n.popup-lixi .is-new-user__field {\r\n    border-radius: 100px;\r\n    overflow: hidden;\r\n    padding-top: 0;\r\n    border: 2px solid #ffa808\r\n}\r\n\r\n.popup-lixi .is-new-user__control {\r\n    border-radius: 0;\r\n    border-right: 2px solid #ffa808\r\n}\r\n\r\n.popup-lixi .is-new-user__button {\r\n    border-radius: 0;\r\n    background-color: #ef0000;\r\n    width: 50px\r\n}\r\n\r\n.site-header {\r\n    position: fixed;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: auto;\r\n    z-index: 10;\r\n    transition: all .3s\r\n}\r\n\r\n.site-header:hover .topbar {\r\n    background-color: #d9d9d9;\r\n    color: #000\r\n}\r\n\r\n.site-header:hover .header {\r\n    background-color: #f9f86c\r\n}\r\n\r\n.site-header.is-scroll-top {\r\n    transform: translateY(-100%)\r\n}\r\n\r\n.site-header.is-scroll-top.cm24 {\r\n    transform: translateY(-48px)\r\n}\r\n\r\n.site-header.is-scroll-top.cm24.has-top-bar {\r\n    transform: translateY(-78px)\r\n}\r\n\r\n.topbar {\r\n    display: block;\r\n    background: #f9f86c;\r\n    font-style: normal;\r\n    font-weight: 500;\r\n    font-size: 13px;\r\n    line-height: 16px;\r\n    text-align: center;\r\n    letter-spacing: .03em;\r\n    padding-top: 7px;\r\n    padding-bottom: 7px;\r\n    transition: all .3s\r\n}\r\n\r\n.topbar,\r\n.topbar:hover {\r\n    color: #000\r\n}\r\n\r\n.topbar.topbar-cm24 {\r\n    background: #8fe3cf\r\n}\r\n\r\n.header {\r\n    background-color: #fff;\r\n    border-bottom: 1px solid #d9d9d9;\r\n    transition: all .3s;\r\n    position: relative\r\n}\r\n\r\n.header__inner {\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: center;\r\n    width: 100%;\r\n    padding-left: 30px;\r\n    padding-right: 30px\r\n}\r\n\r\n@media(min-width:769px) and (max-width:991px) {\r\n    .header__inner {\r\n        padding-left: 15px;\r\n        padding-right: 15px\r\n    }\r\n}\r\n\r\n@media(min-width:992px) and (max-width:1200px) {\r\n    .header__inner {\r\n        padding-left: 15px;\r\n        padding-right: 15px\r\n    }\r\n}\r\n\r\n@media(min-width:1440px) {\r\n    .header__inner {\r\n        padding-left: 64px;\r\n        padding-right: 64px\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header__inner {\r\n        height: 50px;\r\n        padding-left: 15px;\r\n        padding-right: 15px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header__inner {\r\n        height: 50px;\r\n        padding-left: 15px;\r\n        padding-right: 15px\r\n    }\r\n}\r\n\r\n.header__logo {\r\n    height: 36px\r\n}\r\n\r\n.header__logo img {\r\n    width: auto;\r\n    height: 100%\r\n}\r\n\r\n.header__actions {\r\n    display: flex;\r\n    align-items: center\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header__actions {\r\n        flex: 1;\r\n        justify-content: flex-end\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header__actions {\r\n        flex: 1;\r\n        justify-content: flex-end\r\n    }\r\n}\r\n\r\n.header__actions>:not(:first-child) {\r\n    margin-left: 20px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header__menu {\r\n        position: absolute;\r\n        top: 50px;\r\n        right: 0;\r\n        min-height: 500px;\r\n        height: calc(100% - 300px);\r\n        width: 100%;\r\n        background-color: #fff;\r\n        border-top: 1px solid #d9d9d9;\r\n        transition: all .3s;\r\n        overflow-y: auto;\r\n        overflow-x: hidden;\r\n        -webkit-overflow-scrolling: touch;\r\n        -webkit-user-select: none;\r\n        -moz-user-select: none;\r\n        -ms-user-select: none;\r\n        user-select: none;\r\n        opacity: 0;\r\n        pointer-events: none;\r\n        visibility: hidden\r\n    }\r\n\r\n    .header__menu::-webkit-scrollbar {\r\n        width: 0;\r\n        height: 0\r\n    }\r\n\r\n    .header__menu::-webkit-scrollbar-thumb,\r\n    .header__menu::-webkit-scrollbar-track {\r\n        background: transparent\r\n    }\r\n\r\n    .header__menu::-webkit-scrollbar-thumb:hover {\r\n        background: transparent\r\n    }\r\n\r\n    .header__menu-mobile {\r\n        position: absolute;\r\n        top: 50px;\r\n        right: 0;\r\n        min-height: 500px;\r\n        height: calc(100% - 300px);\r\n        width: 100%;\r\n        background-color: #fff;\r\n        border-top: 1px solid #d9d9d9;\r\n        transition: all .3s;\r\n        overflow-y: auto;\r\n        overflow-x: hidden;\r\n        -webkit-overflow-scrolling: touch;\r\n        -webkit-user-select: none;\r\n        -moz-user-select: none;\r\n        -ms-user-select: none;\r\n        user-select: none;\r\n        opacity: 0;\r\n        /* pointer-events: none; */\r\n        visibility: hidden\r\n    }\r\n\r\n    .header__menu-mobile::-webkit-scrollbar {\r\n        width: 0;\r\n        height: 0\r\n    }\r\n\r\n    .header__menu-mobile::-webkit-scrollbar-thumb,\r\n    .header__menu-mobile::-webkit-scrollbar-track {\r\n        background: transparent\r\n    }\r\n\r\n    .header__menu-mobile::-webkit-scrollbar-thumb:hover {\r\n        background: transparent\r\n    }\r\n}\r\n\r\n@media(max-width:991px) and (max-height:600px) {\r\n    .header__menu {\r\n        min-height: inherit;\r\n        height: calc(100vh - 100px)\r\n    }\r\n    .header__menu-mobile {\r\n        min-height: inherit;\r\n        height: calc(100vh - 100px)\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header__menu.is-active {\r\n        opacity: 1;\r\n        pointer-events: visible;\r\n        visibility: visible\r\n    }\r\n\r\n    .header__menu:after {\r\n        content: \"\";\r\n        display: block;\r\n        width: 100%;\r\n        height: 100px\r\n    }\r\n    .header__menu-mobile.is-active {\r\n        opacity: 1;\r\n        pointer-events: visible;\r\n        visibility: visible\r\n    }\r\n\r\n    .header__menu-mobile:after {\r\n        content: \"\";\r\n        display: block;\r\n        width: 100%;\r\n        height: 100px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header__menu {\r\n        position: absolute;\r\n        top: 50px;\r\n        right: 0;\r\n        min-height: 500px;\r\n        height: calc(100% - 300px);\r\n        width: 100%;\r\n        background-color: #fff;\r\n        border-top: 1px solid #d9d9d9;\r\n        transition: all .3s;\r\n        overflow-y: auto;\r\n        overflow-x: hidden;\r\n        -webkit-overflow-scrolling: touch;\r\n        -webkit-user-select: none;\r\n        -moz-user-select: none;\r\n        -ms-user-select: none;\r\n        user-select: none;\r\n        opacity: 0;\r\n        pointer-events: none;\r\n        visibility: hidden\r\n    }\r\n\r\n    .on-mobile .header__menu::-webkit-scrollbar {\r\n        width: 0;\r\n        height: 0\r\n    }\r\n\r\n    .on-mobile .header__menu::-webkit-scrollbar-thumb,\r\n    .on-mobile .header__menu::-webkit-scrollbar-track {\r\n        background: transparent\r\n    }\r\n\r\n    .on-mobile .header__menu::-webkit-scrollbar-thumb:hover {\r\n        background: transparent\r\n    }\r\n    .on-mobile .header__menu-mobile {\r\n        position: absolute;\r\n        top: 50px;\r\n        right: 0;\r\n        min-height: 500px;\r\n        height: calc(100% - 300px);\r\n        width: 100%;\r\n        background-color: #fff;\r\n        border-top: 1px solid #d9d9d9;\r\n        transition: all .3s;\r\n        overflow-y: auto;\r\n        overflow-x: hidden;\r\n        -webkit-overflow-scrolling: touch;\r\n        -webkit-user-select: none;\r\n        -moz-user-select: none;\r\n        -ms-user-select: none;\r\n        user-select: none;\r\n        opacity: 0;\r\n        pointer-events: none;\r\n        visibility: hidden\r\n    }\r\n\r\n    .on-mobile .header__menu-mobile::-webkit-scrollbar {\r\n        width: 0;\r\n        height: 0\r\n    }\r\n\r\n    .on-mobile .header__menu-mobile::-webkit-scrollbar-thumb,\r\n    .on-mobile .header__menu-mobile::-webkit-scrollbar-track {\r\n        background: transparent\r\n    }\r\n\r\n    .on-mobile .header__menu-mobile::-webkit-scrollbar-thumb:hover {\r\n        background: transparent\r\n    }\r\n}\r\n\r\n@media(min-width:991px) and (max-height:600px) {\r\n    .on-mobile .header__menu {\r\n        min-height: inherit;\r\n        height: calc(100vh - 100px)\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header__menu.is-active {\r\n        opacity: 1;\r\n        pointer-events: visible;\r\n        visibility: visible\r\n    }\r\n\r\n    .on-mobile .header__menu:after {\r\n        content: \"\";\r\n        display: block;\r\n        width: 100%;\r\n        height: 100px\r\n    }\r\n    .on-mobile .header__menu-mobile.is-active {\r\n        opacity: 1;\r\n        pointer-events: visible;\r\n        visibility: visible\r\n    }\r\n\r\n    .on-mobile .header__menu-mobile:after {\r\n        content: \"\";\r\n        display: block;\r\n        width: 100%;\r\n        height: 100px\r\n    }\r\n}\r\n\r\n.header__toggle {\r\n    display: none\r\n}\r\n\r\n.header__toggle>div {\r\n    width: 50px;\r\n    height: 50px;\r\n    margin-left: -15px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header__toggle {\r\n        display: flex;\r\n        justify-content: flex-start;\r\n        flex: 1\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header__toggle {\r\n        display: flex;\r\n        justify-content: flex-start;\r\n        flex: 1\r\n    }\r\n}\r\n\r\n.header-actions__button {\r\n    position: relative;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    width: 20px;\r\n    height: 20px\r\n}\r\n\r\n.header-actions__button .counts {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    border-radius: 100px;\r\n    position: absolute;\r\n    right: -5px;\r\n    top: 0;\r\n    width: 13px;\r\n    height: 13px;\r\n    background-color: #2f5acf;\r\n    color: #fff;\r\n    font-size: 10px;\r\n    font-weight: 700;\r\n    pointer-events: none\r\n}\r\n\r\n.header-actions__button:hover .header-actions__menu {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible\r\n}\r\n\r\n.header-actions__menu {\r\n    position: absolute;\r\n    top: 100%;\r\n    right: 0;\r\n    padding-top: 20px;\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: hidden;\r\n    transition: all .3s\r\n}\r\n\r\n.header-actions__inner {\r\n    background-color: #fff;\r\n    border-radius: 16px;\r\n    box-shadow: 0 0 10px 0 rgba(0, 0, 0, .06666666666666667);\r\n    border: 1px solid #d9d9d9\r\n}\r\n\r\n.mega-menu,\r\n.sub-menu {\r\n    position: absolute;\r\n    top: 100%;\r\n    left: 0;\r\n    width: 100%;\r\n    transition: all .2s;\r\n    z-index: 10;\r\n    cursor: inherit;\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: hidden\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .header__menu.is-active .nav__item.is-active .mega-menu,\r\n    .header__menu.is-active .nav__item.is-active .sub-menu {\r\n        transform: translateZ(0)\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .header__menu.is-active .nav__item.is-active .mega-menu,\r\n    .on-mobile .header__menu.is-active .nav__item.is-active .sub-menu {\r\n        transform: translateZ(0)\r\n    }\r\n}\r\n\r\n@media(min-width:768px) {\r\n\r\n    .nav__item:hover .mega-menu,\r\n    .nav__item:hover .sub-menu {\r\n        opacity: 1;\r\n        pointer-events: visible;\r\n        visibility: visible\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .mega-menu--product .mega-menu__title {\r\n        text-transform: uppercase\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .mega-menu--product .mega-menu__title {\r\n        text-transform: uppercase\r\n    }\r\n}\r\n\r\n.mega-menu-collection-all {\r\n    position: absolute;\r\n    bottom: 30px;\r\n    right: -120px\r\n}\r\n\r\n.mega-menu-collection-all a {\r\n    padding: 0 65px;\r\n    background-color: #2a4362;\r\n    border: none;\r\n    border-radius: 5px\r\n}\r\n\r\n.mega-menu-collection-all a:hover {\r\n    color: #000;\r\n    background-color: #d9d9d9;\r\n    border: none\r\n}\r\n\r\n.mega-menu-collection-description {\r\n    color: #2a4362;\r\n    font-size: 13px;\r\n    max-width: 336px\r\n}\r\n\r\n.mega-menu-collection-description p {\r\n    font-weight: 400;\r\n    line-height: 16px;\r\n    margin-top: 0\r\n}\r\n\r\n.mega-menu:after,\r\n.sub-menu:after {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100vh;\r\n    background: rgba(77, 77, 77, .69);\r\n    pointer-events: none\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .mega-menu:after,\r\n    .sub-menu:after {\r\n        display: none\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .mega-menu:after,\r\n    .on-mobile .sub-menu:after {\r\n        display: none\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .mega-menu,\r\n    .sub-menu {\r\n        background-color: #fff;\r\n        top: 0;\r\n        left: 0;\r\n        width: 100%;\r\n        height: 100%;\r\n        padding-top: 50px;\r\n        padding-bottom: 3px;\r\n        opacity: 1;\r\n        pointer-events: visible;\r\n        visibility: visible;\r\n        transform: translate3d(100%, 0, 0)\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .mega-menu,\r\n    .on-mobile .sub-menu {\r\n        background-color: #fff;\r\n        top: 0;\r\n        left: 0;\r\n        width: 100%;\r\n        height: 100%;\r\n        padding-top: 50px;\r\n        padding-bottom: 3px;\r\n        opacity: 1;\r\n        pointer-events: visible;\r\n        visibility: visible;\r\n        transform: translate3d(100%, 0, 0)\r\n    }\r\n}\r\n\r\n.mega-menu__close,\r\n.sub-menu__close {\r\n    display: none\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .mega-menu__close,\r\n    .sub-menu__close {\r\n        display: flex;\r\n        align-items: center;\r\n        position: absolute;\r\n        top: 0;\r\n        left: 0;\r\n        font-size: 15px;\r\n        width: 100%;\r\n        height: 50px;\r\n        padding-left: 30px;\r\n        background-image: url(/images/arrow-left.svg?2ef30de45318ec71014d32f089fbdbdd);\r\n        background-repeat: no-repeat;\r\n        background-position: 15px;\r\n        background-size: 6px;\r\n        background-color: #fff;\r\n        z-index: 1\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .mega-menu__close,\r\n    .on-mobile .sub-menu__close {\r\n        display: flex;\r\n        align-items: center;\r\n        position: absolute;\r\n        top: 0;\r\n        left: 0;\r\n        font-size: 15px;\r\n        width: 100%;\r\n        height: 50px;\r\n        padding-left: 30px;\r\n        background-image: url(/images/arrow-left.svg?2ef30de45318ec71014d32f089fbdbdd);\r\n        background-repeat: no-repeat;\r\n        background-position: 15px;\r\n        background-size: 6px;\r\n        background-color: #fff;\r\n        z-index: 1\r\n    }\r\n}\r\n\r\n.mega-menu__wrapper,\r\n.sub-menu__wrapper {\r\n    position: relative;\r\n    padding-top: 16px;\r\n    padding-bottom: 24px;\r\n    min-height: 300px;\r\n    background-color: #fff;\r\n    z-index: 1\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .mega-menu__wrapper,\r\n    .sub-menu__wrapper {\r\n        height: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .mega-menu__wrapper,\r\n    .on-mobile .sub-menu__wrapper {\r\n        height: 100%\r\n    }\r\n}\r\n\r\n.mega-menu__inner,\r\n.sub-menu__inner {\r\n    display: flex;\r\n    max-width: 870px;\r\n    width: 100%;\r\n    margin: 0 auto\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .mega-menu__inner,\r\n    .sub-menu__inner {\r\n        flex-flow: column;\r\n        max-height: 100%;\r\n        overflow-y: auto;\r\n        overflow-x: hidden;\r\n        -webkit-overflow-scrolling: touch\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .mega-menu__inner,\r\n    .on-mobile .sub-menu__inner {\r\n        flex-flow: column;\r\n        max-height: 100%;\r\n        overflow-y: auto;\r\n        overflow-x: hidden;\r\n        -webkit-overflow-scrolling: touch\r\n    }\r\n}\r\n\r\n.mega-menu__item,\r\n.sub-menu__item {\r\n    flex: 1;\r\n    padding: 0 15px;\r\n    font-weight: 500;\r\n    font-size: 13px;\r\n    line-height: 200%;\r\n    letter-spacing: .03em;\r\n    color: #000\r\n}\r\n\r\n.mega-menu__item ul,\r\n.sub-menu__item ul {\r\n    padding: 0;\r\n    margin: 0\r\n}\r\n\r\n.mega-menu__item ul+ul,\r\n.sub-menu__item ul+ul {\r\n    padding-top: 3px;\r\n    margin-top: 3px;\r\n    position: relative\r\n}\r\n\r\n.mega-menu__item ul+ul:before,\r\n.sub-menu__item ul+ul:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 35px;\r\n    height: 1px;\r\n    background-color: #e9e9e9\r\n}\r\n\r\n.mega-menu__item ul li,\r\n.sub-menu__item ul li {\r\n    list-style: none;\r\n    margin: 0\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .mega-menu__item ul li a,\r\n    .sub-menu__item ul li a {\r\n        display: flex;\r\n        align-items: center\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .mega-menu__item ul li a,\r\n    .on-mobile .sub-menu__item ul li a {\r\n        display: flex;\r\n        align-items: center\r\n    }\r\n}\r\n\r\n.mega-menu__item ul li a:hover,\r\n.sub-menu__item ul li a:hover {\r\n    color: #2f5acf\r\n}\r\n\r\n@media(max-width:991px) {\r\n\r\n    .mega-menu__item,\r\n    .sub-menu__item {\r\n        color: #666;\r\n        font-weight: 400;\r\n        font-size: 15px\r\n    }\r\n\r\n    .mega-menu__item ul,\r\n    .sub-menu__item ul {\r\n        display: none\r\n    }\r\n\r\n    .mega-menu__item ul:last-of-type,\r\n    .sub-menu__item ul:last-of-type {\r\n        padding-bottom: 15px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n\r\n    .on-mobile .mega-menu__item,\r\n    .on-mobile .sub-menu__item {\r\n        color: #666;\r\n        font-weight: 400;\r\n        font-size: 15px\r\n    }\r\n\r\n    .on-mobile .mega-menu__item ul,\r\n    .on-mobile .sub-menu__item ul {\r\n        display: none\r\n    }\r\n\r\n    .on-mobile .mega-menu__item ul:last-of-type,\r\n    .on-mobile .sub-menu__item ul:last-of-type {\r\n        padding-bottom: 15px\r\n    }\r\n}\r\n\r\n.mega-menu__title {\r\n    display: block;\r\n    color: #8e8e8e;\r\n    margin-bottom: 20px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .mega-menu__title {\r\n        position: relative;\r\n        color: #000;\r\n        margin-bottom: 10px\r\n    }\r\n\r\n    .mega-menu__title:after,\r\n    .mega-menu__title:before {\r\n        content: \"\";\r\n        position: absolute;\r\n        top: calc(50% - 1px);\r\n        right: 0;\r\n        height: 2px;\r\n        width: 10px;\r\n        background-color: #000;\r\n        border-radius: 100px;\r\n        transition: all .3s\r\n    }\r\n\r\n    .mega-menu__title:after {\r\n        transform: rotate(90deg)\r\n    }\r\n\r\n    .mega-menu__title.is-active:after {\r\n        transform: rotate(0deg)\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .mega-menu__title {\r\n        position: relative;\r\n        color: #000;\r\n        margin-bottom: 10px\r\n    }\r\n\r\n    .on-mobile .mega-menu__title:after,\r\n    .on-mobile .mega-menu__title:before {\r\n        content: \"\";\r\n        position: absolute;\r\n        top: calc(50% - 1px);\r\n        right: 0;\r\n        height: 2px;\r\n        width: 10px;\r\n        background-color: #000;\r\n        border-radius: 100px;\r\n        transition: all .3s\r\n    }\r\n\r\n    .on-mobile .mega-menu__title:after {\r\n        transform: rotate(90deg)\r\n    }\r\n\r\n    .on-mobile .mega-menu__title.is-active:after {\r\n        transform: rotate(0deg)\r\n    }\r\n}\r\n\r\n.mega-menu__titles {\r\n    display: block;\r\n    color: #8e8e8e;\r\n    margin-bottom: 20px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .mega-menu__titles {\r\n        position: relative;\r\n        color: #000;\r\n        margin-bottom: 10px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .mega-menu__titles {\r\n        position: relative;\r\n        color: #000;\r\n        margin-bottom: 10px\r\n    }\r\n}\r\n\r\n.nav {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    margin: 0;\r\n    padding: 0\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .nav {\r\n        flex-flow: column;\r\n        justify-content: flex-start;\r\n        align-items: flex-start;\r\n        padding-left: 15px;\r\n        padding-right: 15px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .nav {\r\n        flex-flow: column;\r\n        justify-content: flex-start;\r\n        align-items: flex-start;\r\n        padding-left: 15px;\r\n        padding-right: 15px\r\n    }\r\n}\r\n\r\n.nav__item {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    list-style: none;\r\n    padding: 0 30px;\r\n    height: 50px\r\n}\r\n\r\n@media(min-width:769px) and (max-width:991px) {\r\n    .nav__item {\r\n        padding: 0 10px\r\n    }\r\n}\r\n\r\n@media(min-width:992px) and (max-width:1200px) {\r\n    .nav__item {\r\n        padding: 0 15px\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .nav__item {\r\n        height: 34px;\r\n        width: 100%;\r\n        padding: 0 5px;\r\n        justify-content: flex-start;\r\n        border-top: 1px solid #d9d9d9\r\n    }\r\n\r\n    .nav__item.has-child>a:before {\r\n        content: \"\";\r\n        position: absolute;\r\n        top: calc(50% - 6px);\r\n        right: 0;\r\n        width: 12px;\r\n        height: 12px;\r\n        background-image: url(/images/arrow-down.svg?a19aea680c08573712a5aca33fcaed3c);\r\n        background-repeat: no-repeat;\r\n        background-size: contain;\r\n        transform: rotate(-90deg)\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .nav__item {\r\n        height: 34px;\r\n        width: 100%;\r\n        padding: 0 5px;\r\n        justify-content: flex-start;\r\n        border-top: 1px solid #d9d9d9\r\n    }\r\n\r\n    .on-mobile .nav__item.has-child>a:before {\r\n        content: \"\";\r\n        position: absolute;\r\n        top: calc(50% - 6px);\r\n        right: 0;\r\n        width: 12px;\r\n        height: 12px;\r\n        background-image: url(/images/arrow-down.svg?a19aea680c08573712a5aca33fcaed3c);\r\n        background-repeat: no-repeat;\r\n        background-size: contain;\r\n        transform: rotate(-90deg)\r\n    }\r\n}\r\n\r\n.nav__item__highlight {\r\n    color: #2f5acf\r\n}\r\n\r\n.nav__item>a {\r\n    font-weight: 500;\r\n    font-size: 13px;\r\n    line-height: 16px;\r\n    text-align: center;\r\n    letter-spacing: .03em;\r\n    text-transform: capitalize;\r\n    padding: 0;\r\n    white-space: nowrap\r\n}\r\n\r\n.nav__item>a:hover {\r\n    color: #8e8e8e\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .nav__item>a {\r\n        font-size: 14px;\r\n        font-weight: 400;\r\n        display: flex;\r\n        align-items: center;\r\n        width: 100%;\r\n        height: 100%;\r\n        text-align: left;\r\n        position: relative\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .nav__item>a {\r\n        font-size: 14px;\r\n        font-weight: 400;\r\n        display: flex;\r\n        align-items: center;\r\n        width: 100%;\r\n        height: 100%;\r\n        text-align: left;\r\n        position: relative\r\n    }\r\n}\r\n\r\n.nav__item.is-active>a,\r\n.nav__item:hover>a {\r\n    color: #8e8e8e\r\n}\r\n\r\n.nav-tab {\r\n    padding-left: 15px;\r\n    padding-right: 15px\r\n}\r\n\r\n.nav-tab__head {\r\n    display: flex;\r\n    align-items: center;\r\n    overflow-y: hidden;\r\n    overflow-x: auto;\r\n    -webkit-overflow-scrolling: touch;\r\n    -webkit-user-select: none;\r\n    -moz-user-select: none;\r\n    -ms-user-select: none;\r\n    user-select: none;\r\n    border-bottom: 1px solid #d9d9d9\r\n}\r\n\r\n.nav-tab__head::-webkit-scrollbar {\r\n    width: 0;\r\n    height: 0\r\n}\r\n\r\n.nav-tab__head::-webkit-scrollbar-track {\r\n    box-shadow: inset 0 0 5px transparent\r\n}\r\n\r\n.nav-tab__head::-webkit-scrollbar-thumb {\r\n    background: transparent;\r\n    border-radius: 10px\r\n}\r\n\r\n.nav-tab__head::-webkit-scrollbar-thumb:hover {\r\n    background: transparent\r\n}\r\n\r\n.nav-tab__head:after {\r\n    content: \"\";\r\n    display: block;\r\n    width: 50px;\r\n    height: 100%\r\n}\r\n\r\n.nav-tab__title {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    height: 35px;\r\n    padding-left: 5px;\r\n    padding-right: 5px;\r\n    white-space: nowrap;\r\n    position: relative;\r\n    margin-right: 25px;\r\n    font-weight: 700\r\n}\r\n\r\n.nav-tab__title:before {\r\n    width: 0;\r\n    height: 3px\r\n}\r\n\r\n.nav-tab__title:after,\r\n.nav-tab__title:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    bottom: 0;\r\n    left: 0;\r\n    background-color: #000\r\n}\r\n\r\n.nav-tab__title:after {\r\n    width: 100%;\r\n    height: 0;\r\n    transition: all .3s\r\n}\r\n\r\n.nav-tab__title.right-animation:before {\r\n    right: auto;\r\n    left: 0;\r\n    transform: translateX(-30px);\r\n    transition: width .1s linear, transform .05s linear;\r\n    transition-delay: .05s, 0s\r\n}\r\n\r\n.nav-tab__title.right-animation:after {\r\n    transition: height 0s\r\n}\r\n\r\n.nav-tab__title.left-animation:before {\r\n    left: auto;\r\n    right: 0;\r\n    transform: translateX(30px);\r\n    transition: width .1s linear, transform .05s linear;\r\n    transition-delay: .05s, 0s\r\n}\r\n\r\n.nav-tab__title.left-animation:after {\r\n    transition: height 0s\r\n}\r\n\r\n.nav-tab__title.is-current:before {\r\n    width: 100%;\r\n    transition: width .1s linear;\r\n    transition-delay: .05s\r\n}\r\n\r\n.nav-tab__title.is-current:after {\r\n    height: 3px\r\n}\r\n\r\n.nav-tab__title.is-current.right:before {\r\n    right: 0;\r\n    left: auto\r\n}\r\n\r\n.nav-tab__title.is-current.left:after,\r\n.nav-tab__title.is-current.right:after {\r\n    display: none\r\n}\r\n\r\n.nav-tab__menu {\r\n    list-style: none;\r\n    margin: 0;\r\n    padding: 0 5px 10px\r\n}\r\n\r\n.nav-tab__menu li {\r\n    margin: 0\r\n}\r\n\r\n.nav-tab__menu li>a {\r\n    display: block;\r\n    width: 100%;\r\n    line-height: 24px\r\n}\r\n\r\n.nav-tab__content {\r\n    padding-top: 10px\r\n}\r\n\r\n.nav-tab__label {\r\n    display: flex;\r\n    align-items: center;\r\n    position: relative;\r\n    padding: 0 5px 5px\r\n}\r\n\r\n.nav-tab__label:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    bottom: 0;\r\n    left: 0;\r\n    height: 1px;\r\n    width: 70px;\r\n    background-color: #d9d9d9\r\n}\r\n\r\n.nav-tab__sub {\r\n    display: block;\r\n    font-size: 80%;\r\n    margin-top: -4px;\r\n    font-weight: 400;\r\n    width: 100%;\r\n    margin-bottom: 5px\r\n}\r\n\r\n.nav-tab__heading {\r\n    display: flex;\r\n    align-items: center;\r\n    gap: 0 10px\r\n}\r\n\r\n@media(min-width:768px) {\r\n    .sub-menu {\r\n        box-shadow: 0 0 5px 0 rgba(0, 0, 0, .13333333333333333)\r\n    }\r\n}\r\n\r\n.sub-menu a:hover {\r\n    color: #2f5acf\r\n}\r\n\r\n.sub-menu:after {\r\n    display: none\r\n}\r\n\r\n.sub-menu__wrapper {\r\n    min-height: -webkit-fit-content;\r\n    min-height: -moz-fit-content;\r\n    min-height: fit-content\r\n}\r\n\r\n.sub-menu__item {\r\n    margin-bottom: 10px;\r\n    color: #000\r\n}\r\n\r\n.menu-tag {\r\n    display: inline-block;\r\n    font-style: normal;\r\n    font-weight: 500;\r\n    font-size: 10px;\r\n    text-align: center;\r\n    color: #000;\r\n    line-height: 17px;\r\n    padding: 0 7px;\r\n    border-radius: 5px;\r\n    margin-left: 5px\r\n}\r\n\r\n.menu-tag--hot {\r\n    background: #f9f86c\r\n}\r\n\r\n.menu-tag--sale {\r\n    background: #ff2459;\r\n    color: #fff\r\n}\r\n\r\n.menu-tag--new {\r\n    background: #2f5acf;\r\n    color: #fff\r\n}\r\n\r\n.menu-tag--premium {\r\n    background: #000;\r\n    color: #fff\r\n}\r\n\r\n.header-search {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: hidden;\r\n    background-color: #fff\r\n}\r\n\r\n.header-search>form {\r\n    width: 100%\r\n}\r\n\r\n.header-search__wrapper {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    width: 100%;\r\n    max-width: 532px;\r\n    margin: 0 auto;\r\n    transition: all .3s;\r\n    padding-left: 16px;\r\n    padding-right: 16px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header-search__wrapper {\r\n        position: relative;\r\n        width: 100%;\r\n        padding-left: 15px;\r\n        padding-right: 15px;\r\n        margin-top: 17px;\r\n        margin-bottom: 17px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header-search__wrapper {\r\n        position: relative;\r\n        width: 100%;\r\n        padding-left: 15px;\r\n        padding-right: 15px;\r\n        margin-top: 17px;\r\n        margin-bottom: 17px\r\n    }\r\n}\r\n\r\n.header-search__field {\r\n    flex: 1;\r\n    max-width: 100%;\r\n    transition: all .3s\r\n}\r\n\r\n.header-search__filter {\r\n    margin-right: -16px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header-search__filter {\r\n        position: absolute;\r\n        left: 23px;\r\n        top: 50%;\r\n        transform: translate3d(0, -50%, 0)\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header-search__filter {\r\n        position: absolute;\r\n        left: 23px;\r\n        top: 50%;\r\n        transform: translate3d(0, -50%, 0)\r\n    }\r\n}\r\n\r\n.header-search__close {\r\n    display: block;\r\n    position: absolute;\r\n    top: 50%;\r\n    right: 0;\r\n    width: 30px;\r\n    height: 30px;\r\n    cursor: pointer;\r\n    transform: translate3d(-50%, -50%, 0);\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: hidden\r\n}\r\n\r\n.header-search__close:after,\r\n.header-search__close:before {\r\n    content: \"\";\r\n    display: block;\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    width: 14px;\r\n    height: 2px;\r\n    background-color: #000;\r\n    transform: translate3d(-50%, -50%, 0);\r\n    transition: all .3s;\r\n    border-radius: 100px\r\n}\r\n\r\n.header-search__close:after {\r\n    top: calc(50% - 1px);\r\n    left: calc(50% - 7px);\r\n    transform: translateZ(0) rotate(45deg)\r\n}\r\n\r\n.header-search__close:before {\r\n    top: calc(50% - 1px);\r\n    left: calc(50% - 7px);\r\n    transform: translateZ(0) rotate(-45deg)\r\n}\r\n\r\n.header-search__close.is-active {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible\r\n}\r\n\r\n.header-search__control {\r\n    border: 0;\r\n    background-color: transparent;\r\n    box-shadow: none;\r\n    height: 50px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header-search__control {\r\n        width: 100%;\r\n        padding-left: 30px;\r\n        border: 1px solid #d9d9d9;\r\n        height: 30px;\r\n        border-radius: 12px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header-search__control {\r\n        width: 100%;\r\n        padding-left: 30px;\r\n        border: 1px solid #d9d9d9;\r\n        height: 30px;\r\n        border-radius: 12px\r\n    }\r\n}\r\n\r\n.header-search__submit {\r\n    border: 0;\r\n    background-color: #fff;\r\n    cursor: pointer;\r\n    width: 50px;\r\n    height: 50px;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    padding: 15px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header-search__submit {\r\n        width: 17px;\r\n        height: 17px;\r\n        padding: 0\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header-search__submit {\r\n        width: 17px;\r\n        height: 17px;\r\n        padding: 0\r\n    }\r\n}\r\n\r\n.header-search__submit img {\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: contain;\r\n    object-fit: contain\r\n}\r\n\r\n.header-search.is-active {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible\r\n}\r\n\r\n.header-account {\r\n    padding: 15px 15px 10px\r\n}\r\n\r\n.header-account-menu .header-account {\r\n    padding: 0\r\n}\r\n\r\n.header-account ul li {\r\n    white-space: nowrap\r\n}\r\n\r\n.header-account ul li+li {\r\n    margin-top: 5px\r\n}\r\n\r\n.header-account__item {\r\n    display: flex;\r\n    align-items: center;\r\n    min-height: 30px;\r\n    font-size: 13px;\r\n    line-height: 16px;\r\n    letter-spacing: .03em\r\n}\r\n\r\n.header-account__icon {\r\n    position: relative;\r\n    display: inline-block;\r\n    width: 18px;\r\n    height: 20px;\r\n    margin-right: 8px\r\n}\r\n\r\n.header-account__icon img {\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: contain;\r\n    object-fit: contain;\r\n    -o-object-position: center;\r\n    object-position: center\r\n}\r\n\r\n.header-account__sub-icon {\r\n    position: absolute;\r\n    top: -8px;\r\n    right: -6px;\r\n    width: 10px;\r\n    height: 10px\r\n}\r\n\r\n.spotlight-search {\r\n    position: absolute;\r\n    top: 100%;\r\n    left: 50%;\r\n    width: 100%;\r\n    max-width: 500px;\r\n    background-color: #fff;\r\n    border: 1px solid #d9d9d9;\r\n    box-shadow: 0 0 10px 0 rgba(0, 0, 0, .06666666666666667);\r\n    border-radius: 15px;\r\n    padding: 15px 10px;\r\n    margin-top: 10px;\r\n    transform: translate3d(-50%, 0, 0);\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: hidden;\r\n    z-index: 1\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .spotlight-search {\r\n        top: 64px;\r\n        left: 0;\r\n        height: calc(100% - 64px);\r\n        width: 100%;\r\n        transform: translateZ(0);\r\n        border-radius: 0;\r\n        border: 0;\r\n        margin-top: 0;\r\n        transition: all .3s;\r\n        box-shadow: none;\r\n        overflow-y: auto;\r\n        overflow-x: hidden;\r\n        -webkit-overflow-scrolling: touch;\r\n        opacity: 0;\r\n        pointer-events: none;\r\n        visibility: hidden\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .spotlight-search {\r\n        top: 64px;\r\n        left: 0;\r\n        height: calc(100% - 64px);\r\n        width: 100%;\r\n        transform: translateZ(0);\r\n        border-radius: 0;\r\n        border: 0;\r\n        margin-top: 0;\r\n        transition: all .3s;\r\n        box-shadow: none;\r\n        overflow-y: auto;\r\n        overflow-x: hidden;\r\n        -webkit-overflow-scrolling: touch;\r\n        opacity: 0;\r\n        pointer-events: none;\r\n        visibility: hidden\r\n    }\r\n}\r\n\r\n.spotlight-search.is-active {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible\r\n}\r\n\r\n.spotlight-search .view-more {\r\n    display: block;\r\n    width: 100%;\r\n    text-align: center;\r\n    margin-top: 10px;\r\n    text-transform: uppercase;\r\n    font-weight: 700;\r\n    letter-spacing: .1em;\r\n    font-size: 10px\r\n}\r\n\r\n.spotlight-search__content {\r\n    padding-bottom: 15px;\r\n    border-bottom: 1px solid #d9d9d9;\r\n    overflow-y: auto;\r\n    overflow-x: hidden;\r\n    max-height: calc(100vh - 500px)\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .spotlight-search__content {\r\n        max-height: 0;\r\n        height: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .spotlight-search__content {\r\n        max-height: 0;\r\n        height: 100%\r\n    }\r\n}\r\n\r\n.spotlight-search__wrapper .loading {\r\n    display: block;\r\n    width: 30px;\r\n    height: 30px;\r\n    margin: 0 auto;\r\n    -o-object-fit: cover;\r\n    object-fit: cover\r\n}\r\n\r\n.header-search-mobile {\r\n    display: none\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .header-search-mobile {\r\n        display: block\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .header-search-mobile {\r\n        display: block\r\n    }\r\n}\r\n\r\n.product-search {\r\n    display: flex;\r\n    align-items: center\r\n}\r\n\r\n.product-search+.product-search {\r\n    margin-top: 15px\r\n}\r\n\r\n.product-search__thumbnail {\r\n    width: 35px;\r\n    border-radius: 5px;\r\n    overflow: hidden;\r\n    position: relative\r\n}\r\n\r\n.product-search__thumbnail:before {\r\n    content: \"\";\r\n    display: block;\r\n    padding-top: 100%;\r\n    height: 0;\r\n    width: 100%\r\n}\r\n\r\n.product-search__thumbnail img {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: cover;\r\n    object-fit: cover\r\n}\r\n\r\n.product-search__content {\r\n    display: flex;\r\n    flex-flow: column;\r\n    padding-left: 15px;\r\n    font-size: 13px\r\n}\r\n\r\n.product-search__title {\r\n    font-size: 13px;\r\n    font-weight: 700;\r\n    margin-bottom: 0\r\n}\r\n\r\n.product-search__prices {\r\n    display: flex;\r\n    align-items: center;\r\n    font-weight: 400\r\n}\r\n\r\n.product-search__prices ins {\r\n    text-decoration: none;\r\n    margin-right: 5px\r\n}\r\n\r\n.product-search__prices del {\r\n    color: #c4c4c4;\r\n    margin-right: 10px\r\n}\r\n\r\n.product-search__prices del+ins {\r\n    color: #ff3102\r\n}\r\n\r\n.menu-toggle {\r\n    display: block;\r\n    position: relative;\r\n    width: 100%;\r\n    height: 100%;\r\n    cursor: pointer\r\n}\r\n\r\n.menu-toggle span {\r\n    display: block;\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    width: 16px;\r\n    height: 2px;\r\n    background-color: #000;\r\n    transform: translate3d(-50%, -50%, 0);\r\n    transition: all .3s\r\n}\r\n\r\n.menu-toggle span:first-of-type {\r\n    top: calc(50% - 5px)\r\n}\r\n\r\n.menu-toggle span:nth-of-type(3) {\r\n    top: calc(50% + 5px)\r\n}\r\n\r\n.menu-toggle.is-active span:first-of-type {\r\n    top: calc(50% - 1px);\r\n    left: calc(50% - 8px);\r\n    transform: translateZ(0) rotate(45deg)\r\n}\r\n\r\n.menu-toggle.is-active span:nth-of-type(2) {\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: hidden\r\n}\r\n\r\n.menu-toggle.is-active span:nth-of-type(3) {\r\n    top: calc(50% - 1px);\r\n    left: calc(50% - 8px);\r\n    transform: translateZ(0) rotate(-45deg)\r\n}\r\n\r\n.header-account-menu .account-sidebar {\r\n    border-right: 0;\r\n    padding: 0\r\n}\r\n\r\n.header-account-menu .title {\r\n    margin-top: 0;\r\n    flex-flow: column;\r\n    justify-content: flex-start;\r\n    align-items: flex-start\r\n}\r\n\r\n.header-account-menu .badge {\r\n    height: 20px;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center\r\n}\r\n\r\n.header-actions__inner {\r\n    color: #000\r\n}\r\n\r\n@media screen and (min-width:768px) {\r\n    /* header.site-header:hover .header-actions__button:nth-child(2)>a img:first-of-type {\r\n        display: none\r\n    } */\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .nav-tab__content .nav__item {\r\n        position: relative;\r\n        padding: 5px 0;\r\n        border-top: 0\r\n    }\r\n\r\n    .nav-tab__content .nav__item:after {\r\n        content: \"\";\r\n        position: absolute;\r\n        bottom: 0;\r\n        left: -5px;\r\n        height: 1px;\r\n        width: 70px;\r\n        background-color: #d9d9d9\r\n    }\r\n\r\n    .nav-tab__content .nav__item>a {\r\n        color: #000;\r\n        font-weight: 700\r\n    }\r\n\r\n    .nav-tab__content .nav__item:last-of-type:after {\r\n        display: none !important\r\n    }\r\n\r\n    .nav-tab__content .nav__item .nav-child-menu {\r\n        margin-top: 0 !important\r\n    }\r\n\r\n    .nav-tab__content .nav-tab__label {\r\n        border-bottom: 0\r\n    }\r\n\r\n    .nav__item>a {\r\n        font-weight: 700\r\n    }\r\n\r\n    ul.nav-child-menu>li>a {\r\n        display: flex;\r\n        align-items: center\r\n    }\r\n\r\n    ul.nav-child-menu>li>a>b {\r\n        width: 90%\r\n    }\r\n\r\n    ul.nav-child-menu .nav-tab__sub {\r\n        margin: 0\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .nav-tab__content .nav__item {\r\n        position: relative;\r\n        padding: 5px 0;\r\n        border-top: 0\r\n    }\r\n\r\n    .on-mobile .nav-tab__content .nav__item:after {\r\n        content: \"\";\r\n        position: absolute;\r\n        bottom: 0;\r\n        left: -5px;\r\n        height: 1px;\r\n        width: 70px;\r\n        background-color: #d9d9d9\r\n    }\r\n\r\n    .on-mobile .nav-tab__content .nav__item>a {\r\n        color: #000;\r\n        font-weight: 700\r\n    }\r\n\r\n    .on-mobile .nav-tab__content .nav__item:last-of-type:after {\r\n        display: none !important\r\n    }\r\n\r\n    .on-mobile .nav-tab__content .nav__item .nav-child-menu {\r\n        margin-top: 0 !important\r\n    }\r\n\r\n    .on-mobile .nav-tab__content .nav-tab__label {\r\n        border-bottom: 0\r\n    }\r\n\r\n    .on-mobile .nav__item>a {\r\n        font-weight: 700\r\n    }\r\n\r\n    .on-mobile ul.nav-child-menu>li>a {\r\n        display: flex;\r\n        align-items: center\r\n    }\r\n\r\n    .on-mobile ul.nav-child-menu>li>a>b {\r\n        width: 90%\r\n    }\r\n\r\n    .on-mobile ul.nav-child-menu .nav-tab__sub {\r\n        margin: 0\r\n    }\r\n}\r\n\r\n.site-footer {\r\n    background-color: #000;\r\n    color: #fff;\r\n    padding: 30px 0;\r\n    font-size: 13px;\r\n    line-height: 160%;\r\n    color: #d9d9d9;\r\n    margin-top: 30px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .site-footer {\r\n        margin-top: 5px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .site-footer {\r\n        margin-top: 5px\r\n    }\r\n}\r\n\r\n.site-footer__inner {\r\n    display: flex;\r\n    padding-bottom: 35px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .site-footer__inner {\r\n        flex-wrap: wrap\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .site-footer__inner {\r\n        flex-wrap: wrap\r\n    }\r\n}\r\n\r\n.site-footer__menu {\r\n    flex: 1;\r\n    padding-right: 130px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .site-footer__menu {\r\n        width: 100%;\r\n        padding-right: 0;\r\n        margin-bottom: 15px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .site-footer__menu {\r\n        width: 100%;\r\n        padding-right: 0;\r\n        margin-bottom: 15px\r\n    }\r\n}\r\n\r\n.site-footer__sidebar {\r\n    width: 30%;\r\n    max-width: 260px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .site-footer__sidebar {\r\n        width: 100%;\r\n        max-width: 100%;\r\n        margin-bottom: 25px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .site-footer__sidebar {\r\n        width: 100%;\r\n        max-width: 100%;\r\n        margin-bottom: 25px\r\n    }\r\n}\r\n\r\n.site-footer__title {\r\n    font-weight: 600;\r\n    font-size: 21px;\r\n    line-height: 27px;\r\n    color: #fff;\r\n    margin-bottom: 6px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .site-footer__title {\r\n        font-weight: 400\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .site-footer__title {\r\n        font-weight: 400\r\n    }\r\n}\r\n\r\n.site-footer__description {\r\n    width: 100%;\r\n    margin-top: 6px;\r\n    margin-bottom: 33px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .site-footer__description {\r\n        margin-bottom: 10px;\r\n        margin-top: 10px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .site-footer__description {\r\n        margin-bottom: 10px;\r\n        margin-top: 10px\r\n    }\r\n}\r\n\r\n.site-footer__btn {\r\n    display: inline-flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    height: 43px;\r\n    background: #2f5acf;\r\n    border-radius: 16px;\r\n    padding: 0 30px;\r\n    font-size: 14px;\r\n    font-weight: 500;\r\n    letter-spacing: .03em;\r\n    margin-bottom: 25px;\r\n    border: 0\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .site-footer__btn {\r\n        height: 30px;\r\n        font-size: 12px;\r\n        border-radius: 12px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .site-footer__btn {\r\n        height: 30px;\r\n        font-size: 12px;\r\n        border-radius: 12px\r\n    }\r\n}\r\n\r\n.site-footer__btn:hover {\r\n    color: #000;\r\n    background-color: #fff\r\n}\r\n\r\n.footer-contact .site-footer__btn {\r\n    flex: 1;\r\n    margin-bottom: 0\r\n}\r\n\r\n.site-footer__after {\r\n    display: flex;\r\n    align-items: center;\r\n    border-top: 1px solid #d9d9d9;\r\n    padding-top: 16px\r\n}\r\n\r\n.footer-menu {\r\n    display: flex;\r\n    justify-content: space-between\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .footer-menu {\r\n        flex-wrap: wrap\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .footer-menu {\r\n        flex-wrap: wrap\r\n    }\r\n}\r\n\r\n.footer-menu ul {\r\n    margin: 0;\r\n    padding: 0\r\n}\r\n\r\n.footer-menu ul li {\r\n    list-style: none\r\n}\r\n\r\n.footer-menu ul li+li {\r\n    margin-top: 10px\r\n}\r\n\r\n.footer-menu ul li a:hover {\r\n    color: #f9f86c\r\n}\r\n\r\n.footer-menu ul+.footer-menu__title {\r\n    margin-top: 30px\r\n}\r\n\r\n.footer-menu__item {\r\n    flex: 1;\r\n    font-size: 13px;\r\n    line-height: 200%;\r\n    color: #d9d9d9;\r\n    max-width: 160px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .footer-menu__item {\r\n        flex: inherit;\r\n        width: 100%;\r\n        max-width: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .footer-menu__item {\r\n        flex: inherit;\r\n        width: 100%;\r\n        max-width: 100%\r\n    }\r\n}\r\n\r\n.footer-menu__title {\r\n    position: relative;\r\n    color: #fff;\r\n    font-weight: 600;\r\n    font-size: 13px;\r\n    line-height: 200%;\r\n    margin-bottom: 15px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .footer-menu__title {\r\n        margin-bottom: 10px\r\n    }\r\n\r\n    .footer-menu__title:after,\r\n    .footer-menu__title:before {\r\n        content: \"\";\r\n        position: absolute;\r\n        top: 50%;\r\n        right: 0;\r\n        width: 12px;\r\n        height: 2px;\r\n        border-radius: 10px;\r\n        background-color: #fff;\r\n        margin-top: -1px\r\n    }\r\n\r\n    .footer-menu__title:after {\r\n        transform: rotate(90deg);\r\n        transform-origin: center center;\r\n        transition: all .3s\r\n    }\r\n\r\n    .footer-menu__title.is-active:after {\r\n        transform: rotate(0deg)\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .footer-menu__title {\r\n        margin-bottom: 10px\r\n    }\r\n\r\n    .on-mobile .footer-menu__title:after,\r\n    .on-mobile .footer-menu__title:before {\r\n        content: \"\";\r\n        position: absolute;\r\n        top: 50%;\r\n        right: 0;\r\n        width: 12px;\r\n        height: 2px;\r\n        border-radius: 10px;\r\n        background-color: #fff;\r\n        margin-top: -1px\r\n    }\r\n\r\n    .on-mobile .footer-menu__title:after {\r\n        transform: rotate(90deg);\r\n        transform-origin: center center;\r\n        transition: all .3s\r\n    }\r\n\r\n    .on-mobile .footer-menu__title.is-active:after {\r\n        transform: rotate(0deg)\r\n    }\r\n}\r\n\r\n.footer-menu__desciption {\r\n    margin-top: 6px;\r\n    margin-bottom: 6px\r\n}\r\n\r\n.footer-menu__desciption+.footer-menu__desciption {\r\n    margin-top: 30px\r\n}\r\n\r\n.footer-menu__content {\r\n    display: none\r\n}\r\n\r\n.footer-menu__content ul li a {\r\n    display: block;\r\n    width: 100%\r\n}\r\n\r\n.footer-info {\r\n    display: flex;\r\n    justify-content: flex-start;\r\n    align-items: center;\r\n    font-weight: 500;\r\n    font-size: 13px;\r\n    line-height: 160%;\r\n    letter-spacing: .03em;\r\n    color: #fff;\r\n    margin-bottom: 12px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .footer-info {\r\n        font-size: 10px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .footer-info {\r\n        font-size: 10px\r\n    }\r\n}\r\n\r\n.footer-info__icon {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    width: 30px;\r\n    height: 30px;\r\n    margin-right: 15px\r\n}\r\n\r\n.footer-info__icon img {\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: contain;\r\n    object-fit: contain\r\n}\r\n\r\n.footer-info__desciption {\r\n    margin: 0\r\n}\r\n\r\n.footer-social {\r\n    display: flex;\r\n    margin-top: 25px\r\n}\r\n\r\n.footer-contact .footer-social {\r\n    margin-top: 0;\r\n    padding-left: 20px\r\n}\r\n\r\n.footer-social__item {\r\n    flex: 1;\r\n    display: flex;\r\n    align-items: center;\r\n    width: 17%;\r\n    height: 30px\r\n}\r\n\r\n.footer-social__item+.footer-social__item {\r\n    margin-left: 15px\r\n}\r\n\r\n.footer-social__item img {\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: contain;\r\n    object-fit: contain;\r\n    -o-object-position: left;\r\n    object-position: left\r\n}\r\n\r\n.copyright {\r\n    flex: 1\r\n}\r\n\r\n.copyright__title {\r\n    margin-bottom: 12px\r\n}\r\n\r\n.copyright__description,\r\n.copyright__title {\r\n    font-size: 11px;\r\n    line-height: 14px;\r\n    letter-spacing: .03em;\r\n    color: #fff\r\n}\r\n\r\n.copyright__description {\r\n    margin: 0\r\n}\r\n\r\n.copyright__logo img {\r\n    height: 40px;\r\n    margin-left: 15px\r\n}\r\n\r\n.footer-infomations {\r\n    display: flex;\r\n    border-bottom: 1px solid #fff;\r\n    margin-bottom: 15px;\r\n    justify-content: space-between\r\n}\r\n\r\n.footer-contact {\r\n    display: flex;\r\n    align-items: center\r\n}\r\n\r\n\r\n\r\n\r\n.product-grid {\r\n    position: relative;\r\n    padding-bottom: 12px\r\n}\r\n\r\n.product-grid>* {\r\n    transition: all .3s\r\n}\r\n\r\n.product-grid.is-loading:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    width: 40px;\r\n    height: 40px;\r\n    border: 4px solid #ff3102;\r\n    border-bottom-color: transparent;\r\n    border-radius: 100px;\r\n    z-index: 1;\r\n    margin: -84px 0 0 -24px;\r\n    -webkit-animation: loading 2s linear infinite;\r\n    animation: loading 2s linear infinite\r\n}\r\n\r\n.product-grid.is-loading>* {\r\n    opacity: .5;\r\n    pointer-events: none\r\n}\r\n\r\n.product-grid__thumbnail {\r\n    position: relative;\r\n    margin-bottom: 15px;\r\n    border-radius: 20px;\r\n    overflow: hidden\r\n}\r\n\r\n.product-grid__thumbnail .hover {\r\n    display: none\r\n}\r\n\r\n.product-grid__thumbnail:hover .hover {\r\n    display: block\r\n}\r\n\r\n.product-grid__thumbnail:hover .product-grid__select {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible;\r\n    transform: translateZ(0)\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__thumbnail {\r\n        border-radius: 16px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__thumbnail {\r\n        border-radius: 16px\r\n    }\r\n}\r\n\r\n.product-grid__image {\r\n    position: relative\r\n}\r\n\r\n.product-grid__image:before {\r\n    content: \"\";\r\n    display: block;\r\n    padding-top: 133.77926421%;\r\n    height: 0;\r\n    width: 100%\r\n}\r\n\r\n.product-grid__image img {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: cover;\r\n    object-fit: cover;\r\n    -o-object-position: top;\r\n    object-position: top\r\n}\r\n\r\n.product-grid__tags {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    position: absolute;\r\n    top: 6px;\r\n    right: 10px;\r\n    font-size: 10px;\r\n    height: 20px;\r\n    padding: 0 10px;\r\n    border-radius: 5px;\r\n    font-weight: 500;\r\n    color: #000;\r\n    background-color: #f9f86c;\r\n    text-transform: capitalize\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__tags {\r\n        height: 14px;\r\n        font-size: 8px;\r\n        top: 5px;\r\n        right: 7px;\r\n        padding: 0 7px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__tags {\r\n        height: 14px;\r\n        font-size: 8px;\r\n        top: 5px;\r\n        right: 7px;\r\n        padding: 0 7px\r\n    }\r\n}\r\n\r\n.product-grid__tags--sale {\r\n    color: #fff;\r\n    background-color: #ff2459\r\n}\r\n\r\n.product-grid__tags--preorder {\r\n    background-color: #d11313;\r\n    color: #fff\r\n}\r\n\r\n.product-grid__tags--bestseller,\r\n.product-grid__tags--limited,\r\n.product-grid__tags--new {\r\n    color: #fff;\r\n    background-color: #2f5acf\r\n}\r\n\r\n.product-grid__tags--premium {\r\n    color: #fff;\r\n    background-color: #000\r\n}\r\n\r\n.product-grid__title {\r\n    font-size: 14px;\r\n    line-height: 1.2em;\r\n    font-weight: 500;\r\n    margin-bottom: 3px\r\n}\r\n\r\n.product-grid__title:hover {\r\n    color: #231f20\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__title {\r\n        font-size: 12px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__title {\r\n        font-size: 12px\r\n    }\r\n}\r\n\r\n.product-grid__select {\r\n    position: absolute;\r\n    bottom: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    padding: 15px 12px;\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: visible;\r\n    transform: translate3d(0, 20px, 0);\r\n    transition: all .3s\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__select {\r\n        display: none\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__select {\r\n        display: none\r\n    }\r\n}\r\n\r\n.product-grid__select .option-select {\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    margin-left: -4px;\r\n    margin-right: -4px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__select .option-select {\r\n        margin-left: -3px;\r\n        margin-right: -3px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__select .option-select {\r\n        margin-left: -3px;\r\n        margin-right: -3px\r\n    }\r\n}\r\n\r\n.product-grid__select .option-select__item {\r\n    padding: 4px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__select .option-select__item {\r\n        padding: 3px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__select .option-select__item {\r\n        padding: 3px\r\n    }\r\n}\r\n\r\n.product-grid__select .option-select__item .checkmark {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    width: 48px;\r\n    height: 43px;\r\n    border-radius: 16px;\r\n    background-color: #fff;\r\n    font-weight: 500;\r\n    font-size: 14px;\r\n    color: #000;\r\n    white-space: nowrap;\r\n    overflow: hidden;\r\n    text-overflow: ellipsis;\r\n    cursor: pointer;\r\n    -webkit-user-select: none;\r\n    -moz-user-select: none;\r\n    -ms-user-select: none;\r\n    user-select: none;\r\n    transition: all .3s\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__select .option-select__item .checkmark {\r\n        font-size: 12px;\r\n        width: 35px;\r\n        height: 20px;\r\n        border-radius: 8px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__select .option-select__item .checkmark {\r\n        font-size: 12px;\r\n        width: 35px;\r\n        height: 20px;\r\n        border-radius: 8px\r\n    }\r\n}\r\n\r\n.product-grid__select .option-select__item .checkmark:hover {\r\n    background-color: #000;\r\n    color: #fff\r\n}\r\n\r\n.product-grid__select .option-select__item input {\r\n    display: none\r\n}\r\n\r\n.product-grid__hint {\r\n    display: inline-flex;\r\n    flex-flow: column\r\n}\r\n\r\n.product-grid__hint>* {\r\n    display: inline-block;\r\n    border: 1px solid #2f5acf;\r\n    box-sizing: border-box;\r\n    border-radius: 8px;\r\n    padding: 4px 14px;\r\n    margin-top: 10px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__hint>* {\r\n        font-size: 11px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__hint>* {\r\n        font-size: 11px\r\n    }\r\n}\r\n\r\n.product-grid__hint>*+* {\r\n    margin-top: 4px\r\n}\r\n\r\n.product-grid__reviews {\r\n    position: absolute;\r\n    top: 8px;\r\n    left: 10px\r\n}\r\n\r\n.product-grid__reviews .product-snippet-shortvideo {\r\n    width: 21px;\r\n    height: 21px;\r\n    margin-right: 5px;\r\n    margin-left: 3px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__reviews .product-snippet-shortvideo {\r\n        width: 16px;\r\n        height: 16px;\r\n        margin-right: 3px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__reviews .product-snippet-shortvideo {\r\n        width: 16px;\r\n        height: 16px;\r\n        margin-right: 3px\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__reviews {\r\n        top: 5px;\r\n        left: 10px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__reviews {\r\n        top: 5px;\r\n        left: 10px\r\n    }\r\n}\r\n\r\n.product-grid__button {\r\n    position: absolute;\r\n    bottom: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    padding: 15px;\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: visible;\r\n    transform: translate3d(0, 20px, 0);\r\n    transition: all .3s\r\n}\r\n\r\n.product-grid__button .btn {\r\n    width: 100%;\r\n    background-color: #fff;\r\n    color: #000;\r\n    border: 0\r\n}\r\n\r\n.product-grid__thumbnail:hover .product-grid__button {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible;\r\n    transform: translateZ(0)\r\n}\r\n\r\n.product-grid__preorder {\r\n    position: absolute;\r\n    top: 7px;\r\n    left: 12px;\r\n    font-size: 10px;\r\n    color: #000;\r\n    text-transform: capitalize\r\n}\r\n\r\n.product-grid__preorder .t-hide {\r\n    display: none\r\n}\r\n\r\n.product-grid__note {\r\n    display: block;\r\n    font-size: 12px;\r\n    line-height: 1.5em;\r\n    color: #2f5acf;\r\n    font-style: italic;\r\n    letter-spacing: .03em;\r\n    margin-top: 5px\r\n}\r\n\r\n.product-grid__note .t-hide {\r\n    display: none\r\n}\r\n\r\n.product-grid__tag-label {\r\n    position: absolute;\r\n    bottom: 2%;\r\n    right: 5%;\r\n    color: #2f5acf;\r\n    font-size: 18px;\r\n    font-weight: 700\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-grid__tag-label {\r\n        font-size: 14px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-grid__tag-label {\r\n        font-size: 14px\r\n    }\r\n}\r\n\r\n.product-grid__coming-soon {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    background-color: rgba(0, 0, 0, .4666666666666667);\r\n    pointer-events: none\r\n}\r\n\r\n.product-grid__coming-soon:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    height: 70px;\r\n    width: 100%;\r\n    background-image: url(https://mcdn.coolmate.me/image/July2022/mceclip0_93.png);\r\n    background-repeat: no-repeat;\r\n    background-size: contain;\r\n    background-position: 50%;\r\n    transform: translate3d(-50%, -50%, 0)\r\n}\r\n\r\n.product-prices {\r\n    display: flex;\r\n    justify-content: flex-end;\r\n    flex-flow: row-reverse;\r\n    font-size: 14px;\r\n    font-weight: 400\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .product-prices {\r\n        font-size: 12px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .product-prices {\r\n        font-size: 12px\r\n    }\r\n}\r\n\r\n.product-prices ins {\r\n    text-decoration: none\r\n}\r\n\r\n.product-prices del {\r\n    color: #c4c4c4\r\n}\r\n\r\n.product-prices del+ins {\r\n    color: #ff3102;\r\n    margin-right: 14px\r\n}\r\n\r\n.reviews-rating {\r\n    display: flex;\r\n    align-items: center;\r\n    margin-left: -3px;\r\n    margin-right: -3px\r\n}\r\n\r\n.reviews-rating__star {\r\n    display: block;\r\n    width: 12px;\r\n    height: 12px;\r\n    margin: 0 3px 1px;\r\n    /* background-image: url(/images/star-new.svg?08a379c24952a980d5430515abb8be4e); */\r\n    background-repeat: no-repeat;\r\n    background-position: 50%;\r\n    background-size: contain\r\n}\r\n\r\n.product-grid__thumbnail .reviews-rating__star {\r\n    width: 12px;\r\n    height: 10px\r\n}\r\n\r\n.reviews-rating__star.is-active,\r\n.reviews-rating__star.is-full {\r\n    background-image: url(/images/star.svg?9032b9976af477fff0e8b7f2de9556d2)\r\n}\r\n\r\n.reviews-rating__star.is-half {\r\n    background-image: url(/images/star-half.svg?49d34f539fc6b810eb802513d962ab77)\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .reviews-rating__star {\r\n        width: 8px;\r\n        height: 8px;\r\n        margin: 0 2px\r\n    }\r\n\r\n    .product-grid__thumbnail .reviews-rating__star {\r\n        width: 6px;\r\n        margin: 0 1px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .reviews-rating__star {\r\n        width: 8px;\r\n        height: 8px;\r\n        margin: 0 2px\r\n    }\r\n\r\n    .product-grid__thumbnail .on-mobile .reviews-rating__star {\r\n        width: 6px;\r\n        margin: 0 1px\r\n    }\r\n}\r\n\r\n.reviews-rating__number {\r\n    font-style: normal;\r\n    font-weight: 500;\r\n    font-size: 14px;\r\n    line-height: 1em;\r\n    letter-spacing: .03em;\r\n    color: #2f5acf\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .reviews-rating__number {\r\n        font-size: 12px\r\n    }\r\n\r\n    .product-grid__thumbnail .reviews-rating__number {\r\n        font-size: 8px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .reviews-rating__number {\r\n        font-size: 12px\r\n    }\r\n\r\n    .product-grid__thumbnail .on-mobile .reviews-rating__number {\r\n        font-size: 8px\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .reviews-rating__count-avg {\r\n        font-size: 10px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .reviews-rating__count-avg {\r\n        font-size: 10px\r\n    }\r\n}\r\n\r\n.options-color {\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    margin-left: -2px;\r\n    margin-right: -2px;\r\n    margin-bottom: 10px\r\n}\r\n\r\n.option-color__item {\r\n    position: relative;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    padding: 3px;\r\n    cursor: pointer\r\n}\r\n\r\n.option-color__item .checkmark {\r\n    display: block;\r\n    width: 35px;\r\n    height: 20px;\r\n    border-radius: 10px;\r\n    /* background-repeat: no-repeat;\r\n    background-size: 250%;\r\n    background-position: 50% */\r\n    background-color: #000;\r\n    opacity: 0.5;\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .option-color__item .checkmark {\r\n        border-radius: 8px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .option-color__item .checkmark {\r\n        border-radius: 8px\r\n    }\r\n}\r\n\r\n.option-color__item.is-current:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    border: 1px solid #000;\r\n    border-radius: 16px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .option-color__item.is-current:before {\r\n        border-radius: 10px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .option-color__item.is-current:before {\r\n        border-radius: 10px\r\n    }\r\n}\r\n\r\n.collection-grid {\r\n    display: block;\r\n    position: relative\r\n}\r\n\r\n.collection-grid__thumbnail {\r\n    position: relative;\r\n    border-radius: 20px;\r\n    overflow: hidden\r\n}\r\n\r\n.collection-grid__thumbnail:before {\r\n    content: \"\";\r\n    display: block;\r\n    padding-top: 133.33333333%;\r\n    height: 0;\r\n    width: 100%\r\n}\r\n\r\n.collection-grid__thumbnail img {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: cover;\r\n    object-fit: cover\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .collection-grid__thumbnail {\r\n        border-radius: 16px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .collection-grid__thumbnail {\r\n        border-radius: 16px\r\n    }\r\n}\r\n\r\n.collection-grid__thumbnail img {\r\n    transition: all .3s\r\n}\r\n\r\n.collection-grid:hover .collection-grid__thumbnail img {\r\n    transform: scale(1.2)\r\n}\r\n\r\n.collection-grid__title {\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    width: calc(100% - 32px);\r\n    transform: translate3d(-50%, -50%, 0);\r\n    border: 2px solid #fff;\r\n    background-color: #fff;\r\n    color: #000;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    height: 40px;\r\n    border-radius: 16px;\r\n    transition: all .3s\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .collection-grid__title {\r\n        font-size: 12px;\r\n        height: 30px;\r\n        border: 1px solid #d9d9d9;\r\n        background-color: #fff;\r\n        color: #000\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .collection-grid__title {\r\n        font-size: 12px;\r\n        height: 30px;\r\n        border: 1px solid #d9d9d9;\r\n        background-color: #fff;\r\n        color: #000\r\n    }\r\n}\r\n\r\n.collection-grid:hover .collection-grid__title:hover {\r\n    background-color: #fff;\r\n    color: #000;\r\n    border: 2px solid #fff\r\n}\r\n\r\n.countdown {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center\r\n}\r\n\r\n.countdown__item {\r\n    text-align: center;\r\n    padding: 4px\r\n}\r\n\r\n.countdown__number {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    width: 50px;\r\n    height: 50px;\r\n    background-color: #000;\r\n    border-radius: 5px;\r\n    color: #fff;\r\n    text-align: center\r\n}\r\n\r\n.countdown__number>span {\r\n    display: block;\r\n    font-size: 26px;\r\n    line-height: 1em;\r\n    width: 100%;\r\n    text-align: center;\r\n    letter-spacing: .1em;\r\n    padding-left: .1em\r\n}\r\n\r\n.countdown__label {\r\n    font-size: 12px\r\n}\r\n\r\n.about-card {\r\n    display: flex;\r\n    background-color: #f9f86c;\r\n    border-radius: 50px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .about-card {\r\n        border-radius: 30px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .about-card {\r\n        border-radius: 30px\r\n    }\r\n}\r\n\r\n.about-card--black {\r\n    background-color: #000;\r\n    color: #fff\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .about-card--column {\r\n        flex-flow: column\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .about-card--column {\r\n        flex-flow: column\r\n    }\r\n}\r\n\r\n.about-card__content {\r\n    display: flex;\r\n    flex-flow: column;\r\n    justify-content: space-between;\r\n    flex: 1;\r\n    padding: 70px 40px 80px 60px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .about-card__content {\r\n        padding: 16px;\r\n        width: 42%;\r\n        flex: auto\r\n    }\r\n\r\n    .about-card--column .about-card__content {\r\n        width: 100%;\r\n        padding-bottom: 10px\r\n    }\r\n\r\n    .about-card--column .about-card__content br {\r\n        display: none\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .about-card__content {\r\n        padding: 16px;\r\n        width: 42%;\r\n        flex: auto\r\n    }\r\n\r\n    .about-card--column .on-mobile .about-card__content {\r\n        width: 100%;\r\n        padding-bottom: 10px\r\n    }\r\n\r\n    .about-card--column .on-mobile .about-card__content br {\r\n        display: none\r\n    }\r\n}\r\n\r\n.about-card__heading {\r\n    font-weight: 400;\r\n    font-size: 58px;\r\n    line-height: 1.15em\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .about-card__heading {\r\n        font-size: 21px\r\n    }\r\n\r\n    .about-card--column .about-card__heading {\r\n        margin-bottom: 0\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .about-card__heading {\r\n        font-size: 21px\r\n    }\r\n\r\n    .about-card--column .on-mobile .about-card__heading {\r\n        margin-bottom: 0\r\n    }\r\n}\r\n\r\n.about-card--black .about-card__heading {\r\n    color: #fff\r\n}\r\n\r\n.about-card__image {\r\n    border-radius: 50px;\r\n    overflow: hidden;\r\n    max-width: 720px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .about-card__image {\r\n        position: relative;\r\n        border-radius: 30px;\r\n        width: 58%\r\n    }\r\n\r\n    .about-card__image img {\r\n        position: absolute;\r\n        top: 0;\r\n        left: 0;\r\n        width: 100%;\r\n        height: 100%;\r\n        -o-object-fit: cover;\r\n        object-fit: cover\r\n    }\r\n\r\n    .about-card--column .about-card__image {\r\n        padding-top: 81.51260504%;\r\n        height: 0;\r\n        width: 100%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .about-card__image {\r\n        position: relative;\r\n        border-radius: 30px;\r\n        width: 58%\r\n    }\r\n\r\n    .on-mobile .about-card__image img {\r\n        position: absolute;\r\n        top: 0;\r\n        left: 0;\r\n        width: 100%;\r\n        height: 100%;\r\n        -o-object-fit: cover;\r\n        object-fit: cover\r\n    }\r\n\r\n    .about-card--column .on-mobile .about-card__image {\r\n        padding-top: 81.51260504%;\r\n        height: 0;\r\n        width: 100%\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .about-card__description {\r\n        font-size: 12px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .about-card__description {\r\n        font-size: 12px\r\n    }\r\n}\r\n\r\n.coupon-card {\r\n    position: relative;\r\n    display: flex;\r\n    flex-flow: column;\r\n    text-align: center;\r\n    background-image: url(\"https://mcdn.coolmate.me/uploads/December2021/Group_1_(1).png\");\r\n    background-size: contain;\r\n    background-position: 50%;\r\n    background-repeat: no-repeat;\r\n    max-width: 270px;\r\n    width: 100%;\r\n    margin: 0 auto\r\n}\r\n\r\n.coupon-card:before {\r\n    content: \"\";\r\n    display: block;\r\n    width: 100%;\r\n    padding-top: 52.47524752%\r\n}\r\n\r\n.coupon-card__code {\r\n    top: 0;\r\n    font-size: 34px;\r\n    color: #fff\r\n}\r\n\r\n.coupon-card__code,\r\n.coupon-card__description {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    position: absolute;\r\n    left: 0;\r\n    height: 50%;\r\n    width: 100%;\r\n    line-height: 115.6%;\r\n    text-align: center;\r\n    letter-spacing: .03em\r\n}\r\n\r\n.coupon-card__description {\r\n    top: 50%;\r\n    font-weight: 400;\r\n    font-size: 16px;\r\n    color: #000\r\n}\r\n\r\n.coupon-card-newversion {\r\n    position: relative;\r\n    background-image: url(https://mcdn.coolmate.me/image/August2022/mceclip1_15.png);\r\n    background-size: contain;\r\n    background-position: 50%;\r\n    background-repeat: no-repeat;\r\n    max-width: 380px;\r\n    height: 130px;\r\n    margin: 0 auto;\r\n    filter: drop-shadow(2px 5px 4px #0003)\r\n}\r\n\r\n.coupon-card-newversion,\r\n.coupon-card-newversion__code {\r\n    display: flex;\r\n    text-align: center;\r\n    justify-content: center;\r\n    width: 100%\r\n}\r\n\r\n.coupon-card-newversion__code {\r\n    align-items: center;\r\n    flex-flow: column;\r\n    letter-spacing: .03em;\r\n    font-size: 12px;\r\n    flex: 0 0 32%\r\n}\r\n\r\n.coupon-card-newversion__code-text {\r\n    font-weight: 600;\r\n    font-size: 14px;\r\n    color: #2f5acf\r\n}\r\n\r\n.coupon-card-newversion__code .savecode-btn {\r\n    padding: 5px 14px;\r\n    background: #fcfb4c;\r\n    border-radius: 3px;\r\n    border: none;\r\n    margin-bottom: 5px;\r\n    font-weight: 600\r\n}\r\n\r\n.coupon-card-newversion__description {\r\n    display: flex;\r\n    justify-content: center;\r\n    flex-flow: column;\r\n    font-size: 13px;\r\n    text-align: left;\r\n    letter-spacing: .03em;\r\n    color: #000;\r\n    padding: 0 3% 0 9%;\r\n    flex: 0 0 68%\r\n}\r\n\r\n.coupon-card-newversion__description-content {\r\n    margin-bottom: 3px\r\n}\r\n\r\n.coupon-card-newversion__description-content span {\r\n    font-size: 16px;\r\n    font-weight: 500\r\n}\r\n\r\n.coupon-card-newversion__description .used-coupon-info {\r\n    color: #7f7f7f;\r\n    margin-top: 3px\r\n}\r\n\r\n.coupon-card-newversion__description meter {\r\n    width: auto\r\n}\r\n\r\n.coupon-card-newversion__description meter::-webkit-meter-optimum-value {\r\n    background: #2f5acf;\r\n    background-size: 100% 100%;\r\n    border-radius: 5px\r\n}\r\n\r\n.coupon-card-newversion__description meter::-webkit-meter-bar {\r\n    height: 5px;\r\n    max-width: 100%\r\n}\r\n\r\n.coupon-card-newversion__line-dash {\r\n    border: .5px dashed #949494;\r\n    --dash-size: 1em\r\n}\r\n\r\n.mini-coupon {\r\n    position: relative\r\n}\r\n\r\n.mini-coupon__title {\r\n    position: relative;\r\n    display: flex;\r\n    text-align: center;\r\n    justify-content: center;\r\n    background-image: url(https://mcdn.coolmate.me/image/December2022/mceclip0.png);\r\n    background-size: contain;\r\n    background-position: 50%;\r\n    background-repeat: no-repeat;\r\n    white-space: nowrap;\r\n    width: -webkit-fit-content;\r\n    width: -moz-fit-content;\r\n    width: fit-content;\r\n    padding: 10px 8px 10px 18px;\r\n    margin: 0 auto;\r\n    z-index: 1;\r\n    color: #fff;\r\n    width: 90px\r\n}\r\n\r\n@media(max-width:768px) {\r\n    .mini-coupon__title {\r\n        font-size: 12px;\r\n        width: 70px\r\n    }\r\n}\r\n\r\n.mini-coupon__tooltip {\r\n    visibility: hidden;\r\n    white-space: wrap;\r\n    background-color: #fff;\r\n    border: 1px solid #d9d9d9;\r\n    color: #000;\r\n    font-size: 12px;\r\n    text-align: center;\r\n    padding: 5px;\r\n    position: absolute;\r\n    top: 40px;\r\n    left: -40px;\r\n    z-index: 2;\r\n    box-shadow: 0 4px 5px rgba(54, 54, 54, .4);\r\n    border-radius: 8px;\r\n    min-width: -webkit-max-content;\r\n    min-width: -moz-max-content;\r\n    min-width: max-content\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .mini-coupon__tooltip {\r\n        display: none\r\n    }\r\n}\r\n\r\n.mini-coupon .mini-coupon__title:hover~.mini-coupon__tooltip {\r\n    visibility: visible\r\n}\r\n\r\n.mini-coupon__code {\r\n    font-weight: 700;\r\n    font-size: 18px\r\n}\r\n\r\n.mini-coupon__used {\r\n    font-size: 12px\r\n}\r\n\r\n.mini-coupon__description {\r\n    font-style: italic;\r\n    font-size: 14px;\r\n    color: #6d6d6d\r\n}\r\n\r\n@media(max-width:568px) {\r\n    .multiple-coupon-cards .coupon-card-newversion {\r\n        background-image: url(https://mcdn.coolmate.me/image/August2022/mceclip0_54.png);\r\n        flex-flow: column;\r\n        height: 140px\r\n    }\r\n}\r\n\r\n@media(max-width:568px) {\r\n    .multiple-coupon-cards .coupon-card-newversion__code {\r\n        flex: none;\r\n        flex-flow: row;\r\n        gap: 0 5px;\r\n        text-align: left;\r\n        margin: 0 auto;\r\n        justify-content: unset;\r\n        padding-left: 15px;\r\n        padding-bottom: 10px\r\n    }\r\n}\r\n\r\n@media(max-width:568px) {\r\n    .multiple-coupon-cards .coupon-card-newversion__code-text {\r\n        font-size: 8px\r\n    }\r\n}\r\n\r\n@media(max-width:568px) {\r\n    .multiple-coupon-cards .coupon-card-newversion__code .savecode-btn {\r\n        margin-bottom: 0;\r\n        padding: 5px;\r\n        font-size: 8px\r\n    }\r\n}\r\n\r\n@media(max-width:568px) {\r\n    .multiple-coupon-cards .coupon-card-newversion__description {\r\n        flex: 1;\r\n        font-size: 10px\r\n    }\r\n}\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n.homepage-banner {\r\n    position: relative;\r\n    z-index: 1;\r\n}\r\n\r\n.banner-slide>div:not(:first-of-type) {\r\n    display: none\r\n}\r\n\r\n.banner-slide__item {\r\n    position: relative;\r\n    z-index: 1;\r\n}\r\n\r\n.banner-slide__item:before {\r\n    content: \"\";\r\n    display: block;\r\n    padding-top: calc(100vh - 170px);\r\n    height: 0;\r\n    width: 100%\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .banner-slide__item:before {\r\n        padding-top: 177.06666667%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .banner-slide__item:before {\r\n        padding-top: 177.06666667%\r\n    }\r\n}\r\n\r\n.banner-slide__item img {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: cover;\r\n    object-fit: cover\r\n}\r\n\r\n.banner-slide__item:after {\r\n    content: \"\";\r\n    position: absolute;\r\n    bottom: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 25%;\r\n    background-image: linear-gradient(transparent, rgba(0, 0, 0, .4666666666666667));\r\n    pointer-events: none\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .banner-slide__item:after {\r\n        height: 35%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .banner-slide__item:after {\r\n        height: 35%\r\n    }\r\n}\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n.banner-slide__content {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .banner-slide__content {\r\n        align-items: flex-start;\r\n        padding-top: 30px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .banner-slide__content {\r\n        align-items: flex-start;\r\n        padding-top: 30px\r\n    }\r\n}\r\n\r\n.banner-slide__wrapper {\r\n    padding-bottom: 50px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .banner-slide__wrapper {\r\n        height: 440px;\r\n        display: flex;\r\n        flex-flow: column;\r\n        text-align: center !important\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .banner-slide__wrapper {\r\n        height: 440px;\r\n        display: flex;\r\n        flex-flow: column;\r\n        text-align: center !important\r\n    }\r\n}\r\n\r\n.banner-slide__wrapper.hero-slide-info__right {\r\n    text-align: right\r\n}\r\n\r\n.banner-slide__wrapper.hero-slide-info__center {\r\n    text-align: center\r\n}\r\n\r\n.banner-slide__wrapper.hero-slide-info__left {\r\n    text-align: left\r\n}\r\n\r\n.banner-slide__heading {\r\n    font-size: 58px;\r\n    color: #fff;\r\n    margin: 0 0 16px;\r\n    letter-spacing: .03em;\r\n    line-height: 1.25em\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .banner-slide__heading {\r\n        font-size: 36px;\r\n        margin-bottom: 5px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .banner-slide__heading {\r\n        font-size: 36px;\r\n        margin-bottom: 5px\r\n    }\r\n}\r\n\r\n@media(min-width:768px) {\r\n    .banner-slide__heading .desk--hidden {\r\n        display: none\r\n    }\r\n}\r\n\r\n.banner-slide__descriptions {\r\n    font-weight: 400;\r\n    font-size: 16px;\r\n    line-height: 1.5em;\r\n    letter-spacing: .03em;\r\n    color: #fff;\r\n    margin: 0 0 65px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .banner-slide__descriptions {\r\n        flex: 1;\r\n        font-size: 14px;\r\n        margin: 0 0 16px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .banner-slide__descriptions {\r\n        flex: 1;\r\n        font-size: 14px;\r\n        margin: 0 0 16px\r\n    }\r\n}\r\n\r\n.banner-slide__button .btn {\r\n    background: #fff;\r\n    border-radius: 16px;\r\n    min-width: 150px;\r\n    color: #000;\r\n    border-color: #fff\r\n}\r\n\r\n.banner-slide__button .btn:hover {\r\n    border-color: #d9d9d9;\r\n    background-color: #d9d9d9\r\n}\r\n\r\n.banner-policy {\r\n    position: absolute;\r\n    bottom: 32px;\r\n    left: 50%;\r\n    width: 100%;\r\n    max-width: 1280px;\r\n    padding: 0 32px;\r\n    transform: translate3d(-50%, 0, 0)\r\n}\r\n\r\n.banner-policy__wrapper {\r\n    display: flex;\r\n    margin-left: -15px;\r\n    margin-right: -15px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .banner-policy__wrapper {\r\n        flex-flow: column\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .banner-policy__wrapper {\r\n        flex-flow: column\r\n    }\r\n}\r\n\r\n.banner-policy__item {\r\n    position: relative;\r\n    flex: 1;\r\n    margin: 0 15px;\r\n    height: 100%;\r\n    border-radius: 16px;\r\n    color: #000;\r\n    text-align: center;\r\n    font-size: 13px;\r\n    font-weight: 500;\r\n    line-height: 1.15em;\r\n    transition: all .3s;\r\n    overflow: hidden;\r\n    padding: 5px 15px;\r\n    border: 1px solid #fff;\r\n    color: #fff\r\n}\r\n\r\n.banner-policy__item.is-blur {\r\n    line-height: 1.25em;\r\n    padding: 10px 15px;\r\n    color: #000;\r\n    border: 0\r\n}\r\n\r\n.banner-policy__item.is-blur:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    background-color: hsla(0, 0%, 100%, .7);\r\n    -webkit-backdrop-filter: blur(3px);\r\n    backdrop-filter: blur(3px);\r\n    z-index: -1\r\n}\r\n\r\n.banner-policy__item:hover {\r\n    background-color: #fff;\r\n    color: #231f20\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .banner-policy__item+.banner-policy__item {\r\n        margin-top: 16px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .banner-policy__item+.on-mobile .banner-policy__item {\r\n        margin-top: 16px\r\n    }\r\n}\r\n\r\n.homepage-products {\r\n    padding-top: 25px;\r\n    padding-bottom: 15px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-products {\r\n        padding-top: 16px;\r\n        min-height: 440px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-products {\r\n        padding-top: 16px;\r\n        min-height: 440px\r\n    }\r\n}\r\n\r\n.homepage-products--deal {\r\n    background-color: #f9f86c;\r\n    padding-top: 1rem;\r\n    padding-bottom: 1rem\r\n}\r\n\r\n.site-heading {\r\n    font-weight: 500\r\n}\r\n\r\n.home-flashsale {\r\n    padding-top: 20px\r\n}\r\n\r\n.home-tab__header {\r\n    display: flex;\r\n    justify-content: center;\r\n    margin-top: 22px;\r\n    margin-bottom: 8px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .home-tab__header {\r\n        display: -webkit-box;\r\n        justify-content: flex-start;\r\n        flex-flow: row;\r\n        overflow-y: hidden;\r\n        overflow-x: auto;\r\n        margin-top: 10px;\r\n        padding-left: 9px;\r\n        padding-right: 9px;\r\n        font-size: 12px;\r\n        margin-left: -16px;\r\n        margin-right: -16px;\r\n        -webkit-overflow-scrolling: touch\r\n    }\r\n\r\n    .home-tab__header:after,\r\n    .home-tab__header:before {\r\n        content: \"\";\r\n        display: inline-block;\r\n        width: 16px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .home-tab__header {\r\n        display: -webkit-box;\r\n        justify-content: flex-start;\r\n        flex-flow: row;\r\n        overflow-y: hidden;\r\n        overflow-x: auto;\r\n        margin-top: 10px;\r\n        padding-left: 9px;\r\n        padding-right: 9px;\r\n        font-size: 12px;\r\n        margin-left: -16px;\r\n        margin-right: -16px;\r\n        -webkit-overflow-scrolling: touch\r\n    }\r\n\r\n    .on-mobile .home-tab__header:after,\r\n    .on-mobile .home-tab__header:before {\r\n        content: \"\";\r\n        display: inline-block;\r\n        width: 16px\r\n    }\r\n}\r\n\r\n.home-tab__item {\r\n    position: relative;\r\n    width: 150px;\r\n    padding-bottom: 15px;\r\n    text-align: center;\r\n    color: #8e8e8e;\r\n    letter-spacing: .03em;\r\n    font-size: 14px;\r\n    line-height: 18px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .home-tab__item {\r\n        display: block;\r\n        width: auto;\r\n        padding-left: 15px;\r\n        padding-right: 15px;\r\n        white-space: nowrap\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .home-tab__item {\r\n        display: block;\r\n        width: auto;\r\n        padding-left: 15px;\r\n        padding-right: 15px;\r\n        white-space: nowrap\r\n    }\r\n}\r\n\r\n.home-tab__item:before {\r\n    left: 0;\r\n    width: 100%;\r\n    background-color: #d9d9dd\r\n}\r\n\r\n.home-tab__item:after,\r\n.home-tab__item:before {\r\n    content: \"\";\r\n    position: absolute;\r\n    bottom: 0;\r\n    height: 2px;\r\n    transition: all .3s\r\n}\r\n\r\n.home-tab__item:after {\r\n    right: 0;\r\n    left: auto;\r\n    width: 0;\r\n    background-color: #000\r\n}\r\n\r\n.home-tab__item:first-of-type {\r\n    text-align: left\r\n}\r\n\r\n.home-tab__item:last-of-type {\r\n    text-align: right\r\n}\r\n\r\n.home-tab__item.is-active {\r\n    color: #231f20\r\n}\r\n\r\n.home-tab__item.is-active:after {\r\n    left: 0;\r\n    right: auto;\r\n    width: 100%\r\n}\r\n\r\n.home-tab__item.is-active+.home-tab__item:after {\r\n    left: 0\r\n}\r\n\r\n.home-tab__item:hover {\r\n    color: #231f20\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .home-tab__content .grid {\r\n        display: -webkit-box;\r\n        flex-flow: row;\r\n        overflow-y: hidden;\r\n        overflow-x: auto;\r\n        -webkit-overflow-scrolling: touch\r\n    }\r\n\r\n    .home-tab__content .grid:after {\r\n        content: \"\";\r\n        display: block;\r\n        width: 9px\r\n    }\r\n\r\n    .home-tab__content .grid__column {\r\n        width: 190px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .home-tab__content .grid {\r\n        display: -webkit-box;\r\n        flex-flow: row;\r\n        overflow-y: hidden;\r\n        overflow-x: auto;\r\n        -webkit-overflow-scrolling: touch\r\n    }\r\n\r\n    .on-mobile .home-tab__content .grid:after {\r\n        content: \"\";\r\n        display: block;\r\n        width: 9px\r\n    }\r\n\r\n    .on-mobile .home-tab__content .grid__column {\r\n        width: 190px\r\n    }\r\n}\r\n\r\n\r\n.homepage-excool {\r\n    margin-top: 20px;\r\n    margin-bottom: 25px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-excool {\r\n        margin-top: 16px;\r\n        margin-bottom: 16px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-excool {\r\n        margin-top: 16px;\r\n        margin-bottom: 16px\r\n    }\r\n}\r\n\r\n.homepage-collections {\r\n    margin-top: 30px;\r\n    margin-bottom: 30px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-collections {\r\n        margin-top: 20px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-collections {\r\n        margin-top: 20px\r\n    }\r\n}\r\n\r\n.coolclub-abouts__wrapper {\r\n    position: relative\r\n}\r\n\r\n.coolclub-abouts__scroll {\r\n    display: none;\r\n    justify-content: center;\r\n    align-items: center;\r\n    position: absolute;\r\n    top: 50%;\r\n    right: 0;\r\n    width: 35px;\r\n    height: 35px;\r\n    border-radius: 100px;\r\n    background-color: #fff;\r\n    border: 1px solid #d9d9d9;\r\n    transform: translateY(-50%)\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .coolclub-abouts__scroll {\r\n        display: flex\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .coolclub-abouts__scroll {\r\n        display: flex\r\n    }\r\n}\r\n\r\n.coolclub-abouts__scroll img {\r\n    width: 8px\r\n}\r\n\r\n.coolclub-abouts__heading {\r\n    font-size: 108px;\r\n    line-height: 1.15em;\r\n    text-align: center\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .coolclub-abouts__heading {\r\n        font-size: 32px;\r\n        margin-bottom: 25px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .coolclub-abouts__heading {\r\n        font-size: 32px;\r\n        margin-bottom: 25px\r\n    }\r\n}\r\n\r\n.coolclub-abouts__button {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center\r\n}\r\n\r\n.coolclub-abouts__content {\r\n    display: flex;\r\n    align-items: flex-end;\r\n    padding-bottom: 50px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .coolclub-abouts__content {\r\n        display: -webkit-box;\r\n        position: relative;\r\n        flex-flow: row;\r\n        overflow-y: hidden;\r\n        overflow-x: auto;\r\n        -webkit-overflow-scrolling: touch;\r\n        margin-right: 0;\r\n        padding-bottom: 25px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .coolclub-abouts__content {\r\n        display: -webkit-box;\r\n        position: relative;\r\n        flex-flow: row;\r\n        overflow-y: hidden;\r\n        overflow-x: auto;\r\n        -webkit-overflow-scrolling: touch;\r\n        margin-right: 0;\r\n        padding-bottom: 25px\r\n    }\r\n}\r\n\r\n.coolclub-abouts__box {\r\n    display: flex;\r\n    justify-content: center;\r\n    flex: 1;\r\n    opacity: 0\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .coolclub-abouts__box {\r\n        flex: inherit;\r\n        width: 50%\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .coolclub-abouts__box {\r\n        flex: inherit;\r\n        width: 50%\r\n    }\r\n}\r\n\r\n.coolclub-abouts__box:first-of-type {\r\n    transform: translate3d(300%, 0, 0) scale(1);\r\n    transition: all 1.5s\r\n}\r\n\r\n.coolclub-abouts__box:nth-of-type(2) {\r\n    transform: translate3d(200%, 0, 0) scale(1);\r\n    transition: all 1s\r\n}\r\n\r\n.coolclub-abouts__box:nth-of-type(3) {\r\n    transform: translate3d(100%, 0, 0) scale(1);\r\n    transition: all .5s\r\n}\r\n\r\n.coolclub-abouts__box:nth-of-type(4),\r\n.coolclub-abouts__box:nth-of-type(5) {\r\n    transform: translate3d(100%, 0, 0) scale(1);\r\n    transition: all .3s\r\n}\r\n\r\n.animations-active .coolclub-abouts__box {\r\n    opacity: 1\r\n}\r\n\r\n.animations-active .coolclub-abouts__box:first-of-type {\r\n    transform: translateZ(0) scale(1)\r\n}\r\n\r\n.animations-active .coolclub-abouts__box:nth-of-type(2) {\r\n    transform: translateZ(0) scale(1);\r\n    transition-delay: .5s\r\n}\r\n\r\n.animations-active .coolclub-abouts__box:nth-of-type(3) {\r\n    transform: translateZ(0) scale(1);\r\n    transition-delay: 1s\r\n}\r\n\r\n.animations-active .coolclub-abouts__box:nth-of-type(4) {\r\n    transform: translateZ(0) scale(1);\r\n    transition-delay: 1.2s\r\n}\r\n\r\n.animations-active .coolclub-abouts__box:nth-of-type(5) {\r\n    transform: translateZ(0) scale(1);\r\n    transition-delay: 1.4s\r\n}\r\n\r\n.coolclub-abouts__box img {\r\n    -o-object-fit: contain;\r\n    object-fit: contain\r\n}\r\n\r\n@-webkit-keyframes caption-left-to-right {\r\n    0% {\r\n        transform: translate3d(100%, 0, 0)\r\n    }\r\n\r\n    to {\r\n        transform: translate3d(-100%, 0, 0)\r\n    }\r\n}\r\n\r\n@keyframes caption-left-to-right {\r\n    0% {\r\n        transform: translate3d(100%, 0, 0)\r\n    }\r\n\r\n    to {\r\n        transform: translate3d(-100%, 0, 0)\r\n    }\r\n}\r\n\r\n.homepage-more__captions {\r\n    display: flex;\r\n    align-items: center;\r\n    position: relative;\r\n    background-color: #000;\r\n    border-radius: 24px;\r\n    color: #fff;\r\n    font-size: 24px;\r\n    height: 65px;\r\n    margin-bottom: 8px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-more__captions {\r\n        font-size: 13px;\r\n        height: 40px;\r\n        border-radius: 12px;\r\n        margin-bottom: 5px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-more__captions {\r\n        font-size: 13px;\r\n        height: 40px;\r\n        border-radius: 12px;\r\n        margin-bottom: 5px\r\n    }\r\n}\r\n\r\n.homepage-more__description {\r\n    line-height: 30px;\r\n    letter-spacing: .03em;\r\n    white-space: nowrap;\r\n    padding: 0 18px;\r\n    -webkit-animation: caption-left-to-right 15s linear infinite;\r\n    animation: caption-left-to-right 15s linear infinite\r\n}\r\n\r\n.homepage-more__button {\r\n    display: inline-flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    position: absolute;\r\n    right: 0;\r\n    top: 0;\r\n    height: 100%;\r\n    background-color: #2f5acf;\r\n    border-radius: 24px;\r\n    padding: 0 35px;\r\n    font-weight: 400\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-more__button {\r\n        border-radius: 12px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-more__button {\r\n        border-radius: 12px\r\n    }\r\n}\r\n\r\n.homepage-about {\r\n    margin-bottom: 15px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-about {\r\n        margin-bottom: 9px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-about {\r\n        margin-bottom: 9px\r\n    }\r\n}\r\n\r\n.infomation-card {\r\n    border-radius: 20px;\r\n    overflow: hidden\r\n}\r\n\r\n.infomation-card,\r\n.infomation-card__thumbnail {\r\n    position: relative\r\n}\r\n\r\n.infomation-card__thumbnail:before {\r\n    content: \"\";\r\n    display: block;\r\n    padding-top: 39.93506494%;\r\n    height: 0;\r\n    width: 100%\r\n}\r\n\r\n.infomation-card__thumbnail img {\r\n    position: absolute;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    -o-object-fit: cover;\r\n    object-fit: cover\r\n}\r\n\r\n.infomation-card__title {\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 0;\r\n    margin-bottom: 0;\r\n    transform: translate3d(0, -50%, 0);\r\n    font-size: 24px;\r\n    letter-spacing: .03em;\r\n    color: #fff;\r\n    text-align: center;\r\n    font-weight: 400;\r\n    width: 100%\r\n}\r\n\r\n.homepage-demin {\r\n    margin-bottom: 20px;\r\n    padding-top: 20px\r\n}\r\n\r\n.homepage-demin .about-card {\r\n    background-image: url(https://mcdn.coolmate.me/image/April2022/mceclip1_68.jpg);\r\n    background-repeat: no-repeat;\r\n    background-size: cover;\r\n    color: #fff;\r\n    padding: 15px\r\n}\r\n\r\n.homepage-demin .about-card__heading {\r\n    color: #fff\r\n}\r\n\r\n.homepage-demin .about-card__image {\r\n    background-color: #fff;\r\n    border-radius: 50px;\r\n    position: relative\r\n}\r\n\r\n.homepage-demin .about-card__image img {\r\n    width: 100%;\r\n    height: 553px\r\n}\r\n\r\n.homepage-sale {\r\n    background-image: linear-gradient(90deg, #ec1e25, #ff7ba4);\r\n    margin-top: 30px;\r\n    text-align: center;\r\n    padding-top: 1.5rem;\r\n    padding-bottom: 1.5rem\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-sale {\r\n        margin-top: 0\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-sale {\r\n        margin-top: 0\r\n    }\r\n}\r\n\r\n.homepage-sale__btn {\r\n    display: inline-flex;\r\n    justify-items: center;\r\n    align-items: center;\r\n    background-color: #fff;\r\n    border-radius: 100px;\r\n    height: 35px;\r\n    padding: 0 4rem;\r\n    color: #ec1e25;\r\n    font-size: 20px;\r\n    font-weight: 700;\r\n    text-transform: uppercase;\r\n    text-align: center;\r\n    margin: 0 auto 20px\r\n}\r\n\r\n.homepage-sale__btn:hover {\r\n    background-color: #2f5acf;\r\n    color: #fff\r\n}\r\n\r\n.homepage-sale__description {\r\n    text-align: center;\r\n    font-size: 20px;\r\n    text-transform: uppercase;\r\n    font-style: italic;\r\n    color: #fff;\r\n    margin: 0\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-sale__description {\r\n        font-size: 17px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-sale__description {\r\n        font-size: 17px\r\n    }\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-sale-card {\r\n        padding-bottom: 10px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-sale-card {\r\n        padding-bottom: 10px\r\n    }\r\n}\r\n\r\n.countdown-section {\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    flex-flow: column;\r\n    min-height: 200px;\r\n    border-radius: 10px;\r\n    padding-bottom: 4rem;\r\n    padding-top: 0\r\n}\r\n\r\n.countdown-section__heading {\r\n    font-size: 28px;\r\n    font-weight: 400;\r\n    text-align: center\r\n}\r\n\r\n@media screen and (max-width:700px) {\r\n    .countdown-section__heading {\r\n        font-size: 30px;\r\n        line-height: 1.25\r\n    }\r\n}\r\n\r\n.countdown-section__content .countdown__item {\r\n    position: relative\r\n}\r\n\r\n.countdown-section__content .countdown__number {\r\n    width: auto;\r\n    height: auto;\r\n    background-color: transparent\r\n}\r\n\r\n.countdown-section__content .countdown__number span {\r\n    display: flex\r\n}\r\n\r\n.countdown-section__content .countdown__number span span {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    line-height: 1;\r\n    width: 60px;\r\n    height: 60px;\r\n    background-color: #fff;\r\n    border-radius: 9px;\r\n    box-shadow: inset 0 0 15px rgba(0, 0, 0, .13333333333333333);\r\n    font-size: 40px;\r\n    color: #ff3102;\r\n    margin: 0 5px;\r\n    font-weight: 700\r\n}\r\n\r\n@media screen and (max-width:700px) {\r\n    .countdown-section__content .countdown__number span span {\r\n        font-size: 30px;\r\n        height: 50px;\r\n        width: 35px;\r\n        border-radius: 5px\r\n    }\r\n}\r\n\r\n.countdown-section__content .countdown__dots {\r\n    font-size: 50px;\r\n    line-height: 22px;\r\n    transform: translateY(-25%)\r\n}\r\n\r\n@media screen and (max-width:700px) {\r\n    .countdown-section__content .countdown__dots {\r\n        font-size: 30px;\r\n        line-height: 30px;\r\n        transform: translateY(-15%)\r\n    }\r\n}\r\n\r\n.countdown-section__content .countdown__label {\r\n    position: absolute;\r\n    top: 100%;\r\n    left: 50%;\r\n    transform: translateX(-50%);\r\n    font-size: 16px\r\n}\r\n\r\n@media screen and (max-width:700px) {\r\n    .countdown-section__content .countdown__label {\r\n        font-size: 11px\r\n    }\r\n}\r\n\r\n.homepage-bannerreview,\r\n.homepage-bannerreview img {\r\n    border-radius: 24px\r\n}\r\n\r\n\r\n\r\n\r\n\r\n\r\n.homepage-search {\r\n    border-bottom: 1px solid #d9d9d9\r\n}\r\n\r\n.homepage-search__wrapper {\r\n    margin: 0 auto;\r\n    max-width: 700px;\r\n    padding-top: 20px;\r\n    padding-bottom: 20px\r\n}\r\n\r\n.homepage-search__heading {\r\n    text-align: center;\r\n    font-weight: 700;\r\n    color: #2f5acf;\r\n    font-size: 28px;\r\n    margin-bottom: 14px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-search__heading {\r\n        font-size: 24px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-search__heading {\r\n        font-size: 24px\r\n    }\r\n}\r\n\r\n.homepage-search__description {\r\n    text-align: center;\r\n    margin-bottom: 5px;\r\n    margin-top: 5px;\r\n    margin-right: 10px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-search__description {\r\n        font-size: 12px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-search__description {\r\n        font-size: 12px\r\n    }\r\n}\r\n\r\n.homepage-search__inner {\r\n    position: relative\r\n}\r\n\r\n.homepage-search__control {\r\n    border: 1px solid #2f5acf;\r\n    width: 100%;\r\n    height: 50px;\r\n    border-radius: 1rem;\r\n    padding-left: 1rem;\r\n    padding-right: 1rem;\r\n    font-size: 16px\r\n}\r\n\r\n@media(max-width:991px) {\r\n    .homepage-search__control {\r\n        font-size: 14px;\r\n        height: 45px\r\n    }\r\n}\r\n\r\n@media(min-width:991px) {\r\n    .on-mobile .homepage-search__control {\r\n        font-size: 14px;\r\n        height: 45px\r\n    }\r\n}\r\n\r\n.homepage-search__control:focus {\r\n    outline-color: #2f5acf\r\n}\r\n\r\n.homepage-search__control::-moz-placeholder {\r\n    color: rgba(0, 0, 0, .3333333333333333)\r\n}\r\n\r\n.homepage-search__control:-ms-input-placeholder {\r\n    color: rgba(0, 0, 0, .3333333333333333)\r\n}\r\n\r\n.homepage-search__control::placeholder {\r\n    color: rgba(0, 0, 0, .3333333333333333)\r\n}\r\n\r\n.homepage-search__spotlight {\r\n    position: absolute;\r\n    background-color: #fff;\r\n    box-shadow: 0 0 10px 0 #d9d9d9;\r\n    padding: 1rem;\r\n    border-radius: .5rem;\r\n    width: 100%;\r\n    max-width: 500px;\r\n    left: 50%;\r\n    top: 100%;\r\n    transform: translate3d(-50%, 0, 0);\r\n    z-index: 9;\r\n    margin-top: 10px;\r\n    transition: all .3s;\r\n    opacity: 0;\r\n    pointer-events: none;\r\n    visibility: hidden;\r\n    display: none\r\n}\r\n\r\n.homepage-search__spotlight .loading {\r\n    display: block;\r\n    width: 30px;\r\n    height: 30px;\r\n    margin: 0 auto\r\n}\r\n\r\n.homepage-search__spotlight.is-active {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible;\r\n    display: block\r\n}\r\n\r\n.homepage-search__spotlight .product-search__thumbnail {\r\n    width: 50px\r\n}\r\n\r\n.homepage-search__spotlight-content.is-active {\r\n    opacity: 1;\r\n    pointer-events: visible;\r\n    visibility: visible\r\n}\r\n\r\n.homepage-search__spotlight-content.is-active~.homepage-search__more {\r\n    display: block\r\n}\r\n\r\n.homepage-search__more {\r\n    text-align: center;\r\n    text-decoration: underline;\r\n    color: #2f5acf;\r\n    cursor: pointer;\r\n    margin-top: 10px;\r\n    display: none\r\n}\r\n\r\n.homepage-search__content {\r\n    margin-top: 15px\r\n}\r\n\r\n.homepage-search__buttons,\r\n.homepage-search__content {\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    flex-wrap: wrap\r\n}\r\n\r\n.homepage-search__buttons {\r\n    gap: 6px\r\n}\r\n\r\n.homepage-search__button {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    height: 30px;\r\n    padding: 0 10px;\r\n    border-radius: 5px;\r\n    border: 1px solid #d9d9d9;\r\n    white-space: nowrap\r\n}", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_id_d6bae970_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_id_d6bae970_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_id_d6bae970_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_style_index_0_id_31cefecd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_style_index_0_id_31cefecd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_style_index_0_id_31cefecd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/frontend/components/Index.vue":
/*!****************************************************!*\
  !*** ./resources/js/frontend/components/Index.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Index_vue_vue_type_template_id_d6bae970_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Index.vue?vue&type=template&id=d6bae970&scoped=true& */ "./resources/js/frontend/components/Index.vue?vue&type=template&id=d6bae970&scoped=true&");
/* harmony import */ var _Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Index.vue?vue&type=script&lang=js& */ "./resources/js/frontend/components/Index.vue?vue&type=script&lang=js&");
/* harmony import */ var _Index_vue_vue_type_style_index_0_id_d6bae970_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css& */ "./resources/js/frontend/components/Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Index_vue_vue_type_template_id_d6bae970_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _Index_vue_vue_type_template_id_d6bae970_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "d6bae970",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/frontend/components/Index.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/frontend/components/layouts/Footer.vue":
/*!*************************************************************!*\
  !*** ./resources/js/frontend/components/layouts/Footer.vue ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Footer_vue_vue_type_template_id_109c9adb_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Footer.vue?vue&type=template&id=109c9adb&scoped=true& */ "./resources/js/frontend/components/layouts/Footer.vue?vue&type=template&id=109c9adb&scoped=true&");
/* harmony import */ var _Footer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Footer.vue?vue&type=script&lang=js& */ "./resources/js/frontend/components/layouts/Footer.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Footer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Footer_vue_vue_type_template_id_109c9adb_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _Footer_vue_vue_type_template_id_109c9adb_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "109c9adb",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/frontend/components/layouts/Footer.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/frontend/components/layouts/Header.vue":
/*!*************************************************************!*\
  !*** ./resources/js/frontend/components/layouts/Header.vue ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Header_vue_vue_type_template_id_31cefecd_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Header.vue?vue&type=template&id=31cefecd&scoped=true& */ "./resources/js/frontend/components/layouts/Header.vue?vue&type=template&id=31cefecd&scoped=true&");
/* harmony import */ var _Header_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Header.vue?vue&type=script&lang=js& */ "./resources/js/frontend/components/layouts/Header.vue?vue&type=script&lang=js&");
/* harmony import */ var _Header_vue_vue_type_style_index_0_id_31cefecd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css& */ "./resources/js/frontend/components/layouts/Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Header_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Header_vue_vue_type_template_id_31cefecd_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _Header_vue_vue_type_template_id_31cefecd_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "31cefecd",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/frontend/components/layouts/Header.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/frontend/components/Index.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/frontend/components/Index.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Index.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/frontend/components/layouts/Footer.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/frontend/components/layouts/Footer.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Footer.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Footer.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/frontend/components/layouts/Header.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/frontend/components/layouts/Header.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Header.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5.use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/frontend/components/Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/frontend/components/Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css& ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_id_d6bae970_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=style&index=0&id=d6bae970&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/frontend/components/layouts/Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css&":
/*!**********************************************************************************************************************!*\
  !*** ./resources/js/frontend/components/layouts/Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css& ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_style_index_0_id_31cefecd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9.use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9.use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=style&index=0&id=31cefecd&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/frontend/components/Index.vue?vue&type=template&id=d6bae970&scoped=true&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/frontend/components/Index.vue?vue&type=template&id=d6bae970&scoped=true& ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_d6bae970_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_d6bae970_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_d6bae970_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Index.vue?vue&type=template&id=d6bae970&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=template&id=d6bae970&scoped=true&");


/***/ }),

/***/ "./resources/js/frontend/components/layouts/Footer.vue?vue&type=template&id=109c9adb&scoped=true&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/frontend/components/layouts/Footer.vue?vue&type=template&id=109c9adb&scoped=true& ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_template_id_109c9adb_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_template_id_109c9adb_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_template_id_109c9adb_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Footer.vue?vue&type=template&id=109c9adb&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Footer.vue?vue&type=template&id=109c9adb&scoped=true&");


/***/ }),

/***/ "./resources/js/frontend/components/layouts/Header.vue?vue&type=template&id=31cefecd&scoped=true&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/frontend/components/layouts/Header.vue?vue&type=template&id=31cefecd&scoped=true& ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_template_id_31cefecd_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_template_id_31cefecd_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Header_vue_vue_type_template_id_31cefecd_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Header.vue?vue&type=template&id=31cefecd&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=template&id=31cefecd&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=template&id=d6bae970&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/Index.vue?vue&type=template&id=d6bae970&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("app-header"),
      _vm._v(" "),
      _c(
        "main",
        {
          staticClass: "site-homepage",
          staticStyle: { "padding-top": "50px" },
        },
        [
          _c(
            "transition",
            { attrs: { name: "slide-fade" } },
            [_c("router-view")],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c("app-footer"),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Footer.vue?vue&type=template&id=109c9adb&scoped=true&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Footer.vue?vue&type=template&id=109c9adb&scoped=true& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm._m(0)
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("footer", { staticClass: "site-footer mobile--hidden" }, [
      _c("div", { staticClass: "container" }, [
        _c("div", { staticClass: "site-footer__inner" }, [
          _c("div", { staticClass: "site-footer__menu" }, [
            _c("div", { staticClass: "footer-menu" }, [
              _c("div", { staticClass: "footer-menu__item" }, [
                _c("h4", { staticClass: "footer-menu__title" }, [
                  _vm._v("Khám phá COOLMATE"),
                ]),
                _vm._v(" "),
                _c("ul", [
                  _c("li", [
                    _c("a", { attrs: { href: "/collection/ao-polo-nam" } }, [
                      _vm._v("Áo Polo"),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      { attrs: { href: "/collection/ao-thun-nam-gioi" } },
                      [_vm._v("Áo T-shirt")]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "/collection/ao-so-mi-nam" } }, [
                      _vm._v("Áo Sơ mi"),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "/collection/quan-short-nam" } }, [
                      _vm._v("Quần"),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "/collection/quan-lot-nam" } }, [
                      _vm._v("Quần Lót"),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "/collection/tat-nam" } }, [
                      _vm._v("Tất (Vớ)"),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "/collection/mu-luoi-trai" } }, [
                      _vm._v("Mũ (Nón)"),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "/collection/phu-kien" } }, [
                      _vm._v("Phụ Kiện Khác"),
                    ]),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "footer-menu__item" }, [
                _c("h4", { staticClass: "footer-menu__title" }, [
                  _vm._v("Dịch vụ khách hàng"),
                ]),
                _vm._v(" "),
                _c("ul", [
                  _c("li", [
                    _c("a", { attrs: { href: "/page/faqs" } }, [
                      _vm._v("Hỏi đáp - FAQs"),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      { attrs: { href: "/page/dich-vu-60-ngay-doi-tra" } },
                      [_vm._v("Chính sách đổi trả 60 ngày")]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "/page/lien-he-voi-coolmate" } }, [
                      _vm._v("Liên hệ"),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/coolclub-chuong-trinh-khach-hang-than-thiet-cua-coolmate",
                        },
                      },
                      [
                        _vm._v(
                          "Thành\n                                    viên Coolclub"
                        ),
                      ]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/11-dich-vu-tai-coolmate-co-the-ban-chua-biet",
                        },
                      },
                      [
                        _vm._v(
                          "Khách hàng hài\n                                    lòng 100%"
                        ),
                      ]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/chuong-trinh-va-chinh-sach-khuyen-mai-tai-coolmate",
                        },
                      },
                      [
                        _vm._v(
                          "Chính\n                                    sách khuyến mãi"
                        ),
                      ]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      { attrs: { href: "/page/dich-vu-giao-hang-coolmate" } },
                      [_vm._v("Chính sách giao hàng")]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/chinh-sach-bao-mat-thong-tin-ca-nhan",
                        },
                      },
                      [_vm._v("Chính sách bảo mật")]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("h4", { staticClass: "footer-menu__title" }, [
                  _vm._v("Kiến thức mặc đẹp"),
                ]),
                _vm._v(" "),
                _c("ul", [
                  _c("li", [
                    _c("a", { attrs: { href: "/size-chart" } }, [
                      _vm._v("Hướng dẫn chọn size"),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c("a", { attrs: { href: "/blog" } }, [_vm._v("Blog")]),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "https://www.facebook.com/groups/2103080403316797",
                          target: "_blank",
                        },
                      },
                      [_vm._v("Group mặc đẹp sống chất")]
                    ),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "footer-menu__item" }, [
                _c("h4", { staticClass: "footer-menu__title" }, [
                  _vm._v("Tài liệu - Tuyển dụng"),
                ]),
                _vm._v(" "),
                _c("ul", [
                  _c("li", [
                    _c(
                      "a",
                      { attrs: { href: "/lp/coolmate-101?itm_source=footer" } },
                      [_vm._v("Tuyển dụng")]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "http://online.gov.vn/(X(1)S(sgmttobbtsiaq3l5itoicxhw))/Home/WebDetails/53184?AspxAutoDetectCookieSupport=1",
                          target: "_blank",
                        },
                      },
                      [_vm._v("Đăng ký bản quyền")]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("h4", { staticClass: "footer-menu__title" }, [
                  _vm._v("Về COOLMATE"),
                ]),
                _vm._v(" "),
                _c("ul", [
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/coolmate-story?itm_source=footer",
                        },
                      },
                      [_vm._v(" Câu chuyện về Coolmate")]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/san-pham-coolmate-duoc-san-xuat-nhu-the-nao?itm_source=footer",
                        },
                      },
                      [_vm._v("Nhà\n                                    máy")]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/coolclub-chuong-trinh-khach-hang-than-thiet-cua-coolmate?itm_source=footer",
                        },
                      },
                      [_vm._v("CoolClub")]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/collection/care-and-share?itm_source=footer",
                        },
                      },
                      [_vm._v("Care & Share")]
                    ),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "footer-menu__item" }, [
                _c("h4", { staticClass: "footer-menu__title" }, [
                  _vm._v("Địa chỉ liên hệ"),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "footer-menu__desciption" }, [
                  _c("u", [_vm._v("HUB Hà Nội:")]),
                  _vm._v(
                    " Tầng 3-4, Tòa nhà BMM, KM2,\n                            Đường Phùng Hưng, Phường Phúc La, Quận Hà Đông, TP Hà Nội"
                  ),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "footer-menu__desciption" }, [
                  _c("u", [_vm._v("HUB Tp HCM:")]),
                  _vm._v(
                    " Lầu 1, Số 163 Trần Trọng Cung,\n                            Phường Tân Thuận Đông, Quận 7, Tp. Hồ Chí Minh"
                  ),
                ]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "site-footer__sidebar" }, [
            _c("h4", { staticClass: "site-footer__title" }, [
              _vm._v(
                "\n                    COOLMATE lắng nghe bạn!\n                "
              ),
            ]),
            _vm._v(" "),
            _c(
              "p",
              {
                staticClass: "site-footer__description",
                staticStyle: { "margin-bottom": "10px" },
              },
              [
                _vm._v(
                  "\n                    Chúng tôi luôn trân trọng và mong đợi nhận được mọi ý kiến đóng góp từ\n                    khách hàng để có thể nâng cấp trải nghiệm dịch vụ và sản phẩm tốt hơn nữa.\n                "
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "site-footer__btn",
                attrs: {
                  href: "https://form.typeform.com/to/lU2oprGc?typeform-medium=embed-snippet",
                  target: "_blank",
                },
              },
              [_vm._v("\n                    Gửi Ý Kiến\n                ")]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "footer-info" }, [
              _c("div", { staticClass: "footer-info__icon" }, [
                _c("img", {
                  attrs: {
                    src: "https://www.coolmate.me/images/footer/icon-hotline.svg",
                    alt: "Footer Icon Phone",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "footer-info__content" }, [
                _c("span", { staticClass: "footer-info__title" }, [
                  _vm._v(
                    "\n                            Hotline\n                        "
                  ),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "footer-info__desciption" }, [
                  _c("a", { attrs: { href: "tel: 1900272737" } }, [
                    _vm._v("1900.272737"),
                  ]),
                  _vm._v(" "),
                  _c("a", { attrs: { href: "tel: 02877772737" } }, [
                    _vm._v("(028.7777.2737)"),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "footer-info" }, [
              _c("div", { staticClass: "footer-info__icon" }, [
                _c("img", {
                  attrs: {
                    src: "https://www.coolmate.me/images/footer/icon-email.svg",
                    alt: "Footer Icon Email",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "footer-info__content" }, [
                _c("span", { staticClass: "footer-info__title" }, [
                  _vm._v(
                    "\n                            Email\n                        "
                  ),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "footer-info__desciption" }, [
                  _c(
                    "a",
                    {
                      attrs: {
                        href: "/cdn-cgi/l/email-protection#f1d1b29e9e9db1929e9e9d9c908594df9c94",
                      },
                    },
                    [
                      _c(
                        "span",
                        {
                          staticClass: "__cf_email__",
                          attrs: {
                            "data-cfemail":
                              "a2e1cdcdcee2c1cdcdcecfc3d6c78ccfc7",
                          },
                        },
                        [_vm._v("[email protected]")]
                      ),
                    ]
                  ),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "footer-social" }, [
              _c(
                "a",
                {
                  staticClass: "footer-social__item",
                  attrs: {
                    href: "https://www.facebook.com/coolmate.me",
                    target: "_blank",
                  },
                },
                [
                  _c("img", {
                    attrs: {
                      src: "https://www.coolmate.me/images/footer/icon-facebook.svg",
                      alt: "Footer Icon facebook",
                    },
                  }),
                ]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "footer-social__item",
                  attrs: {
                    href: "https://www.instagram.com/coolmate.me/",
                    target: "_blank",
                  },
                },
                [
                  _c("img", {
                    attrs: {
                      src: "https://www.coolmate.me/images/footer/icon-instar.svg",
                      alt: "Footer Icon instar",
                    },
                  }),
                ]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "footer-social__item",
                  attrs: {
                    href: "https://www.youtube.com/channel/UCWw8wLlodKBtEvVt1tTAsMA",
                    target: "_blank",
                  },
                },
                [
                  _c("img", {
                    attrs: {
                      src: "https://www.coolmate.me/images/footer/icon-youtube.svg",
                      alt: "Footer Icon youtube",
                    },
                  }),
                ]
              ),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "site-footer__after" }, [
          _c("div", { staticClass: "copyright" }, [
            _c("h5", { staticClass: "copyright__title" }, [
              _vm._v(
                "\n                    @ CÔNG TY TNHH .....\n                "
              ),
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "copyright__description" }, [
              _vm._v(
                "Mã số doanh nghiệp: 9999999999. Giấy chứng nhận đăng ký\n                    doanh nghiệp do Sở Kế hoạch và Đầu tư TP Hà Nội cấp lần đầu ngày 20/02/2019."
              ),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "site-footer__logo",
              staticStyle: { display: "flex" },
            },
            [
              _c(
                "a",
                {
                  staticStyle: { "margin-right": "10px" },
                  attrs: {
                    href: "https://tinnhiemmang.vn/danh-ba-tin-nhiem/coolmateme-1646213826",
                    title: "Chung nhan Tin Nhiem Mang",
                    target: "_blank",
                  },
                },
                [
                  _c("img", {
                    staticStyle: { "max-height": "40px" },
                    attrs: {
                      src: "https://media.coolmate.me/cdn-cgi/image/quality=80,format=auto/uploads/March2022/handle_cert.png",
                      alt: "Chung nhan Tin Nhiem Mang",
                    },
                  }),
                ]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "dmca-badge",
                  staticStyle: { "margin-right": "10px" },
                  attrs: {
                    href: "//www.dmca.com/Protection/Status.aspx?ID=c6fdbdee-127c-4cf1-923d-7efe75201df6",
                    title: "DMCA.com Protection Status",
                    target: "_blank",
                  },
                },
                [
                  _c("img", {
                    staticStyle: { "max-height": "40px" },
                    attrs: {
                      src: "https://media.coolmate.me/cdn-cgi/image/quality=80,format=auto/uploads/March2022/dmca_protected_15_120.png",
                      alt: "DMCA.com Protection Status",
                    },
                  }),
                ]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticStyle: { "margin-right": "10px" },
                  attrs: { href: "#" },
                },
                [
                  _c("img", {
                    attrs: {
                      src: "https://www.coolmate.me/images/footer/Coolmate-info.png",
                      alt: "Coolmate info",
                      width: "39",
                      height: "40",
                    },
                  }),
                ]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  attrs: {
                    href: "http://online.gov.vn/(X(1)S(3e0hkhscv5zs101mhuopx43a))/Home/WebDetails/53184?AspxAutoDetectCookieSupport=1",
                    target: "_blank",
                  },
                },
                [
                  _c("img", {
                    attrs: {
                      src: "https://www.coolmate.me/images/footer/logoSaleNoti.png",
                      alt: "Coolmate info",
                      width: "106",
                      height: "40",
                    },
                  }),
                ]
              ),
            ]
          ),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=template&id=31cefecd&scoped=true&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/frontend/components/layouts/Header.vue?vue&type=template&id=31cefecd&scoped=true& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("header", { staticClass: "site-header" }, [
    _c("div", { staticClass: "header" }, [
      _c("div", { staticClass: "header__inner" }, [
        _c("div", { staticClass: "header__toggle" }, [
          _c("div", {}, [
            _c(
              "a",
              {
                staticClass: "menu-toggle",
                attrs: { href: "#", "rel-script": "menu-toggle" },
                on: {
                  click: function ($event) {
                    _vm.showMenuMobile = !_vm.showMenuMobile
                  },
                },
              },
              [_c("span"), _vm._v(" "), _c("span"), _vm._v(" "), _c("span")]
            ),
          ]),
        ]),
        _vm._v(" "),
        _vm._m(0),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass: "header__menu-mobile",
            style: {
              display: _vm.showMenuMobile ? "none" : "block",
              visibility: _vm.showMenuMobile ? "unset" : "unset",
              opacity: _vm.showMenuMobile ? 1 : 1,
            },
            attrs: { "rel-script": "header-menu" },
          },
          [_vm._m(1)]
        ),
        _vm._v(" "),
        _vm._m(2),
        _vm._v(" "),
        _vm._m(3),
      ]),
    ]),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "header__logo",
        staticStyle: { display: "flex", "align-items": "center" },
      },
      [
        _c("a", { attrs: { href: "#" } }, [
          _c("img", {
            staticStyle: { height: "50px" },
            attrs: { src: "/img/logo.png", alt: "Logo Coolmate" },
          }),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "mobile--visible tablet--visible",
        staticStyle: { display: "none" },
      },
      [
        _c(
          "div",
          {
            staticClass: "header-search-mobile",
            attrs: { "rel-script": "header-search-content" },
          },
          [
            _c("form", { attrs: { action: "/collections", method: "GET" } }, [
              _c("div", { staticClass: "header-search__wrapper" }, [
                _c("label", { staticClass: "header-search__field" }, [
                  _c("input", {
                    staticClass: "header-search__control one-whole",
                    attrs: {
                      type: "text",
                      name: "keyword",
                      "rel-script": "spotlight-search-control",
                      placeholder: "Tìm kiếm sản phẩm...",
                      autocomplete: "off",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "header-search__filter" }, [
                  _c("button", { staticClass: "header-search__submit" }, [
                    _c("img", {
                      attrs: {
                        src: "https://www.coolmate.me/images/header/icon-search.svg",
                        alt: "Icon Search",
                      },
                    }),
                  ]),
                ]),
                _vm._v(" "),
                _c("a", {
                  staticClass: "header-search__close",
                  attrs: { href: "#", "rel-script": "spotlight-search-close" },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "spotlight-search" }, [
              _c(
                "div",
                {
                  staticClass: "spotlight-search__wrapper",
                  attrs: { "rel-script": "spotlight-search" },
                },
                [
                  _c("img", {
                    staticClass: "loading",
                    attrs: {
                      src: "https://www.coolmate.me/images/icons/loading.svg",
                    },
                  }),
                ]
              ),
            ]),
          ]
        ),
        _vm._v(" "),
        _c("div", { staticClass: "nav-tab" }, [
          _c("div", { staticClass: "nav-tab__head" }, [
            _c(
              "a",
              {
                staticClass: "nav-tab__title is-current",
                attrs: { href: "#san-pham", "rel-script": "nav-tab" },
              },
              [
                _vm._v(
                  "\n                                Thời trang\n                            "
                ),
              ]
            ),
          ]),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "nav-tab__content",
              attrs: { "data-nav-tab": "#san-pham" },
            },
            [
              _c(
                "div",
                {
                  staticClass: "nav-tab__label",
                  staticStyle: {
                    "flex-flow": "column",
                    "align-items": "flex-start",
                    "padding-bottom": "10px",
                  },
                },
                [
                  _c(
                    "a",
                    { attrs: { href: "/collections?itm_source=navbar" } },
                    [_c("b", [_vm._v("Tất cả sản phẩm")])]
                  ),
                ]
              ),
              _vm._v(" "),
              _c("ul", { staticClass: "nav-tab__menu" }, [
                _c("li", { staticClass: "nav__item" }, [
                  _c(
                    "a",
                    {
                      attrs: {
                        href: "/collection/care-and-share?itm_source=navbar",
                      },
                    },
                    [_c("b", [_vm._v("Care & Share")])]
                  ),
                ]),
                _vm._v(" "),
                _c(
                  "li",
                  {
                    staticClass: "nav__item nav__item--has-child",
                    attrs: { "rel-script": "mobile-menu-toggle" },
                  },
                  [
                    _c("a", { attrs: { href: "#" } }, [
                      _vm._v(
                        "\n                                        Áo nam\n                                    "
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "ul",
                      {
                        staticClass: "nav-child-menu",
                        staticStyle: { display: "none", "margin-top": "10px" },
                      },
                      [
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/ao-nam1?itm_source=navbar",
                              },
                            },
                            [_c("b", [_vm._v("Áo nam")])]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/ao-nam-dai-tay?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Áo dài tay\n                                            "
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/ao-thun-nam?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Áo T-shirt\n                                            "
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/ao-polo-nam?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Áo Polo\n                                            "
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/ao-so-mi-nam?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Áo Sơ Mi\n                                            "
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/ao-the-thao-nam?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Áo Thể thao\n                                            "
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/ao-khoac?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Áo khoác\n                                            "
                              ),
                            ]
                          ),
                        ]),
                      ]
                    ),
                  ]
                ),
                _vm._v(" "),
                _c(
                  "li",
                  {
                    staticClass: "nav__item nav__item--has-child",
                    attrs: { "rel-script": "mobile-menu-toggle" },
                  },
                  [
                    _c("a", { attrs: { href: "#" } }, [
                      _vm._v(
                        "\n                                        Quần nam\n                                    "
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "ul",
                      {
                        staticClass: "nav-child-menu",
                        staticStyle: { display: "none", "margin-top": "10px" },
                      },
                      [
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/quan-nam?itm_source=navbar",
                              },
                            },
                            [_c("b", [_vm._v("Quần nam")])]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/quan-lot-nam?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Quần Lót Nam\n                                            "
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/quan-short-nam?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Quần Shorts\n                                            "
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/quan-jeans-nam?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Quần Jeans\n                                            "
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/quan-dai-nam?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Quần Dài\n                                            "
                              ),
                            ]
                          ),
                        ]),
                      ]
                    ),
                  ]
                ),
                _vm._v(" "),
                _c(
                  "li",
                  {
                    staticClass: "nav__item nav__item--has-child",
                    attrs: { "rel-script": "mobile-menu-toggle" },
                  },
                  [
                    _c("a", { attrs: { href: "#" } }, [
                      _vm._v(
                        "\n                                        Phụ kiện\n                                    "
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "ul",
                      {
                        staticClass: "nav-child-menu",
                        staticStyle: { display: "none", "margin-top": "10px" },
                      },
                      [
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/mu-luoi-trai?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Mũ (Nón)\n                                            "
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/tat-nam?itm_source=navbar",
                              },
                            },
                            [
                              _vm._v(
                                "\n                                                Tất (Vớ)\n                                            "
                              ),
                            ]
                          ),
                        ]),
                      ]
                    ),
                  ]
                ),
                _vm._v(" "),
                _c(
                  "li",
                  {
                    staticClass: "nav__item nav__item--has-child",
                    attrs: { "rel-script": "mobile-menu-toggle" },
                  },
                  [
                    _c("a", { attrs: { href: "#" } }, [
                      _vm._v(
                        "\n                                        Bộ sưu tập\n                                    "
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "ul",
                      {
                        staticClass: "nav-child-menu",
                        staticStyle: { display: "none", "margin-top": "10px" },
                      },
                      [
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/vu-tru-ao-thun-marvel?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Vũ trụ áo Marvel ")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "Bước vào thế giới siêu anh\n                                                    hùng"
                                ),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", { staticClass: "nav-tab__item" }, [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/page/cleanvn?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Clean Vietnam")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "\n                                                    Sự kết hợp giữa Coolmate & Vietmax\n                                                "
                                ),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", { staticClass: "nav-tab__item" }, [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/coolmate-basics?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Coolmate Basics")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "\n                                                    Mua sắm tiết kiệm với giá tốt\n                                                "
                                ),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/san-pham-moi-ben-vung?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Sản phẩm bền vững")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "Sản phẩm thân thiện với môi\n                                                    trường"
                                ),
                              ]),
                            ]
                          ),
                        ]),
                      ]
                    ),
                  ]
                ),
                _vm._v(" "),
                _c(
                  "li",
                  {
                    staticClass: "nav__item nav__item--has-child",
                    attrs: { "rel-script": "mobile-menu-toggle" },
                  },
                  [
                    _c("a", { attrs: { href: "#" } }, [
                      _vm._v(
                        "\n                                        Nhu cầu\n                                    "
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "ul",
                      {
                        staticClass: "nav-child-menu",
                        staticStyle: { display: "none", "margin-top": "10px" },
                      },
                      [
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/bst-thu-dong1?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [
                                _vm._v("Đồ thu - đông "),
                                _c(
                                  "span",
                                  { staticClass: "menu-tag menu-tag--sale" },
                                  [_vm._v("SALE")]
                                ),
                              ]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v("Fall-Winter Collection"),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/do-mac-trong-va-mac-nha?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Mặc ở nhà & Mặc trong")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "\n                                                    Homewear & Underwear\n                                                "
                                ),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/do-casual?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Mặc hằng ngày")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "\n                                                    Casualwear\n                                                "
                                ),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/coolmate-activewear?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Đồ thể thao")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "\n                                                    Coolmate Active\n                                                "
                                ),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/phu-kien-nam?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Phụ kiện")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "\n                                                    Accessories\n                                                "
                                ),
                              ]),
                            ]
                          ),
                        ]),
                      ]
                    ),
                  ]
                ),
                _vm._v(" "),
                _c(
                  "li",
                  {
                    staticClass: "nav__item nav__item--has-child",
                    attrs: { "rel-script": "mobile-menu-toggle" },
                  },
                  [
                    _c("a", { attrs: { href: "#" } }, [
                      _vm._v(
                        "\n                                        Công nghệ\n                                    "
                      ),
                    ]),
                    _vm._v(" "),
                    _c(
                      "ul",
                      {
                        staticClass: "nav-child-menu",
                        staticStyle: { display: "none", "margin-top": "10px" },
                      },
                      [
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/lp/dong-san-pham-excool?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Excool")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "\n                                                    Công nghệ làm mát tối đa\n                                                "
                                ),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/page/cleandye#ldp-about?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Cleandye")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "10%\n                                                    Nhuộm không dùng nước\n                                                "
                                ),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/lp/dong-san-pham-heiq-viroblock?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("HeiQ Viroblock")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "\n                                                    Diệt 99.99% virus SARS-CoV2\n                                                "
                                ),
                              ]),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("li", [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "/collection/san-pham-anti-smell?itm_source=navbar",
                              },
                            },
                            [
                              _c("b", [_vm._v("Anti-Smell")]),
                              _vm._v(" "),
                              _c("span", { staticClass: "nav-tab__sub" }, [
                                _vm._v(
                                  "Công nghệ khử mùi từ Nhật\n                                                    Bản"
                                ),
                              ]),
                            ]
                          ),
                        ]),
                      ]
                    ),
                  ]
                ),
              ]),
            ]
          ),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "nav-tab__content",
              staticStyle: { display: "none" },
              attrs: { "data-nav-tab": "#bo-suu-tap" },
            },
            [
              _c("ul", { staticClass: "nav-tab__menu" }, [
                _c("li", [
                  _c("a", { attrs: { href: "/84rising?itm_source=navbar" } }, [
                    _c("b", [_vm._v("Tất cả")]),
                  ]),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    { attrs: { href: "/84rising?itm_source=navbar#T-shirt" } },
                    [_c("b", [_vm._v("Áo Oversize")]), _c("br")]
                  ),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    {
                      attrs: { href: "/84rising?itm_source=navbar#Sweatshirt" },
                    },
                    [_c("b", [_vm._v("Áo Nỉ")])]
                  ),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    { attrs: { href: "/84rising?itm_source=navbar#hoodie" } },
                    [_c("b", [_vm._v("Áo Hoodie")])]
                  ),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    {
                      attrs: {
                        href: "/84rising?itm_source=navbar#short-pants",
                      },
                    },
                    [_c("b", [_vm._v("Quần Short")])]
                  ),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    { attrs: { href: "/84rising?itm_source=navbar#Beanie" } },
                    [_c("b", [_vm._v("Mũ len Beanie Short")])]
                  ),
                ]),
              ]),
            ]
          ),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "nav-tab__content",
              staticStyle: { display: "none" },
              attrs: { "data-nav-tab": "#nhu-cau" },
            },
            [
              _c("ul", { staticClass: "nav-tab__menu" }, [
                _c("li", [
                  _c("a", { attrs: { href: "/84rising?itm_source=navbar" } }, [
                    _c("b", [_vm._v("Tất cả")]),
                  ]),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    { attrs: { href: "/84rising?itm_source=navbar#T-shirt" } },
                    [_c("b", [_vm._v("Áo Oversize")]), _c("br")]
                  ),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    {
                      attrs: { href: "/84rising?itm_source=navbar#Sweatshirt" },
                    },
                    [_c("b", [_vm._v("Áo Nỉ")])]
                  ),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    { attrs: { href: "/84rising?itm_source=navbar#hoodie" } },
                    [_c("b", [_vm._v("Áo Hoodie")])]
                  ),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    {
                      attrs: {
                        href: "/84rising?itm_source=navbar#short-pants",
                      },
                    },
                    [_c("b", [_vm._v("Quần Short")])]
                  ),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c(
                    "a",
                    { attrs: { href: "/84rising?itm_source=navbar#Beanie" } },
                    [_c("b", [_vm._v("Mũ len Beanie Short")])]
                  ),
                ]),
              ]),
            ]
          ),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "nav-tab__content",
              staticStyle: { display: "none" },
              attrs: { "data-nav-tab": "#cong-nghe" },
            },
            [
              _c("ul", { staticClass: "nav-tab__menu" }, [
                _c("li", { staticClass: "nav-tab__item" }, [
                  _c(
                    "a",
                    {
                      attrs: {
                        href: "/lp/dong-san-pham-excool?itm_source=navbar",
                      },
                    },
                    [
                      _c("b", [_vm._v("Excool")]),
                      _vm._v(" "),
                      _c("span", { staticClass: "nav-tab__sub" }, [
                        _vm._v(
                          "\n                                            Công nghệ làm mát tối đa\n                                        "
                        ),
                      ]),
                    ]
                  ),
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-tab__item" }, [
                  _c(
                    "a",
                    {
                      attrs: {
                        href: "/page/cleandye#ldp-about?itm_source=navbar",
                      },
                    },
                    [
                      _c("b", [_vm._v("Cleandye")]),
                      _vm._v(" "),
                      _c("span", { staticClass: "nav-tab__sub" }, [
                        _vm._v(
                          "10%\n                                            Nhuộm không dùng nước\n                                        "
                        ),
                      ]),
                    ]
                  ),
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-tab__item" }, [
                  _c(
                    "a",
                    {
                      attrs: {
                        href: "/lp/dong-san-pham-heiq-viroblock?itm_source=navbar",
                      },
                    },
                    [
                      _c("b", [_vm._v("HeiQ Viroblock")]),
                      _vm._v(" "),
                      _c("span", { staticClass: "nav-tab__sub" }, [
                        _vm._v(
                          "\n                                            Diệt 99.99% virus SARS-CoV2\n                                        "
                        ),
                      ]),
                    ]
                  ),
                ]),
                _vm._v(" "),
                _c("li", { staticClass: "nav-tab__item" }, [
                  _c(
                    "a",
                    {
                      attrs: {
                        href: "/collection/san-pham-anti-smell?itm_source=navbar",
                      },
                    },
                    [
                      _c("b", [_vm._v("Anti-Smell")]),
                      _vm._v(" "),
                      _c("span", { staticClass: "nav-tab__sub" }, [
                        _vm._v("Công nghệ khử mùi từ Nhật Bản"),
                      ]),
                    ]
                  ),
                ]),
              ]),
            ]
          ),
        ]),
        _vm._v(" "),
        _c("ul", { staticClass: "nav pdt--20" }, [
          _c("li", { staticClass: "nav__item" }, [
            _c(
              "a",
              {
                attrs: {
                  href: "/lp/coolxprint-mo-hinh-dat-san-xuat-theo-yeu-cau?itm_source=ab_xprint_x",
                },
              },
              [
                _vm._v(
                  "\n                                CoolXPrint - Thiết kế theo yêu cầu\n                            "
                ),
              ]
            ),
          ]),
          _vm._v(" "),
          _c("li", { staticClass: "nav__item" }, [
            _c("a", { attrs: { href: "/size-chart?itm_source=navbar" } }, [
              _vm._v(
                "\n                                Chọn Size\n                            "
              ),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "li",
            {
              staticClass: "nav__item nav__item--has-child",
              attrs: { "rel-script": "mobile-menu-toggle" },
            },
            [
              _c("a", { attrs: { href: "#" } }, [
                _vm._v(
                  "\n                                Về Coolmate\n                            "
                ),
              ]),
              _vm._v(" "),
              _c(
                "ul",
                {
                  staticClass: "nav-child-menu",
                  staticStyle: { display: "none", "margin-top": "10px" },
                },
                [
                  _c("li", [
                    _c(
                      "a",
                      { attrs: { href: "/lp/coolmate-101?itm_source=navbar" } },
                      [
                        _vm._v(
                          "\n                                        Coolmate 101 - Gia nhập coolmate\n                                    "
                        ),
                      ]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/11-dich-vu-tai-coolmate-co-the-ban-chua-biet?itm_source=navbar",
                        },
                      },
                      [
                        _vm._v(
                          "\n                                        Dịch vụ 100% hài lòng\n                                    "
                        ),
                      ]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/coolclub-chuong-trinh-khach-hang-than-thiet-cua-coolmate?itm_source=navbar",
                        },
                      },
                      [
                        _vm._v(
                          "\n                                        CoolClub - Khách hàng thân thiết\n                                    "
                        ),
                      ]
                    ),
                  ]),
                  _vm._v(" "),
                  _c("li", [
                    _c(
                      "a",
                      {
                        attrs: {
                          href: "/page/coolmate-story?itm_source=navbar",
                        },
                      },
                      [
                        _vm._v(
                          "\n                                        Câu chuyện Coolmate\n                                    "
                        ),
                      ]
                    ),
                  ]),
                ]
              ),
            ]
          ),
          _vm._v(" "),
          _c(
            "li",
            { staticClass: "nav__item", attrs: { "rel-script": "mega-menu" } },
            [
              _c("a", { attrs: { href: "/blog?itm_source=navbar" } }, [
                _vm._v(
                  "\n                                Blog\n                            "
                ),
              ]),
            ]
          ),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "header__menu",
        staticStyle: { display: "block" },
        attrs: { "rel-script": "header-menu" },
      },
      [
        _c("div", { staticClass: "mobile--hidden tablet--hidden" }, [
          _c("ul", { staticClass: "nav" }, [
            _c(
              "li",
              {
                staticClass: "nav__item has-child",
                attrs: { "rel-script": "mega-menu" },
              },
              [
                _c(
                  "a",
                  {
                    attrs: {
                      href: "/collections?itm_source=navbar",
                      "rel-script": "mega-menu-open",
                    },
                  },
                  [
                    _vm._v(
                      "\n                                Danh mục\n                            "
                    ),
                  ]
                ),
                _vm._v(" "),
                _c("div", { staticClass: "mega-menu mega-menu--product" }, [
                  _c(
                    "a",
                    {
                      staticClass: "mega-menu__close",
                      attrs: { href: "#", "rel-script": "mega-menu-close" },
                    },
                    [_vm._v("Sản\n                                    phẩm")]
                  ),
                  _vm._v(" "),
                  _c("div", { staticClass: "mega-menu__wrapper" }, [
                    _c(
                      "div",
                      {
                        staticClass: "mega-menu__inner",
                        staticStyle: { "max-width": "1000px" },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass: "mega-menu__item",
                            staticStyle: { flex: "0 0 33%" },
                            attrs: { "rel-script": "mega-menu-item" },
                          },
                          [
                            _c(
                              "a",
                              {
                                staticClass: "mega-menu__title",
                                attrs: {
                                  href: "#",
                                  "rel-script": "mega-menu-toggle",
                                },
                              },
                              [_vm._v("Danh mục")]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              { staticClass: "grid grid--two-columns" },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass: "grid__column",
                                    staticStyle: { "padding-top": "0" },
                                  },
                                  [
                                    _c(
                                      "ul",
                                      {
                                        attrs: {
                                          "rel-script": "mega-menu-active",
                                        },
                                      },
                                      [
                                        _c("li", [
                                          _c(
                                            "a",
                                            {
                                              attrs: {
                                                href: "/collection/ao-nam1?itm_source=navbar",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "\n                                                                Áo Nam\n                                                            "
                                              ),
                                            ]
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c(
                                          "li",
                                          { staticClass: "mega-menu_child" },
                                          [
                                            _c(
                                              "a",
                                              {
                                                attrs: {
                                                  href: "/collection/ao-nam-dai-tay?itm_source=navbar",
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                                Áo dài tay\n                                                            "
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "li",
                                          { staticClass: "mega-menu_child" },
                                          [
                                            _c(
                                              "a",
                                              {
                                                attrs: {
                                                  href: "/collection/ao-thun-nam?itm_source=navbar",
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                                Áo T-shirt\n                                                            "
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "li",
                                          { staticClass: "mega-menu_child" },
                                          [
                                            _c(
                                              "a",
                                              {
                                                attrs: {
                                                  href: "/collection/ao-polo-nam?itm_source=navbar",
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                                Áo Polo\n                                                            "
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "li",
                                          { staticClass: "mega-menu_child" },
                                          [
                                            _c(
                                              "a",
                                              {
                                                attrs: {
                                                  href: "/collection/ao-so-mi-nam?itm_source=navbar",
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                                Áo Sơ Mi\n                                                            "
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "li",
                                          { staticClass: "mega-menu_child" },
                                          [
                                            _c(
                                              "a",
                                              {
                                                attrs: {
                                                  href: "/collection/ao-the-thao-nam?itm_source=navbar",
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                                Áo Thể Thao\n                                                            "
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "li",
                                          { staticClass: "mega-menu_child" },
                                          [
                                            _c(
                                              "a",
                                              {
                                                attrs: {
                                                  href: "/collection/ao-khoac?itm_source=navbar",
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n                                                                Áo khoác\n                                                            "
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticClass: "nav__item has-child",
                attrs: { "rel-script": "mega-menu" },
              },
              [
                _c("a", { attrs: { href: "/84rising?itm_source=navbar" } }, [
                  _vm._v(
                    "\n                                Quần áo nam\n                            "
                  ),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticClass: "nav__item has-child",
                attrs: { "rel-script": "mega-menu" },
              },
              [
                _c(
                  "a",
                  {
                    staticStyle: { position: "relative" },
                    attrs: { href: "/cm24?itm_source=navbar" },
                  },
                  [
                    _vm._v(
                      "\n                                Sản phẩm bán chạy\n                                "
                    ),
                    _c("span", {
                      staticStyle: {
                        width: "5px",
                        height: "5px",
                        "border-radius": "100vmax",
                        "background-color": "#2F5ACF",
                        position: "absolute",
                        top: "0",
                        left: "100%",
                        "margin-left": "2px",
                      },
                    }),
                  ]
                ),
              ]
            ),
            _vm._v(" "),
            _c("li", { staticClass: "nav__item" }, [
              _c(
                "a",
                {
                  attrs: {
                    href: "/lp/coolxprint-mo-hinh-dat-san-xuat-theo-yeu-cau?itm_source=navbar",
                  },
                },
                [
                  _vm._v(
                    "\n                                Giới thiệu\n                            "
                  ),
                ]
              ),
            ]),
            _vm._v(" "),
            _c("li", { staticClass: "nav__item" }, [
              _c("a", { attrs: { href: "/blog?itm_source=navbar" } }, [
                _vm._v(
                  "\n                                Blog\n                            "
                ),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "li",
              {
                staticClass: "nav__item has-child",
                attrs: { "rel-script": "mega-menu" },
              },
              [
                _c(
                  "a",
                  {
                    attrs: {
                      href: "/page/coolmate-story?itm_source=navbar",
                      "rel-script": "mega-menu-open",
                    },
                  },
                  [
                    _vm._v(
                      "\n                                Liên hệ\n                            "
                    ),
                  ]
                ),
                _vm._v(" "),
                _c("div", { staticClass: "mega-menu" }, [
                  _c(
                    "a",
                    {
                      staticClass: "mega-menu__close",
                      attrs: { href: "#", "rel-script": "mega-menu-close" },
                    },
                    [_vm._v("Về\n                                    Coolmate")]
                  ),
                  _vm._v(" "),
                  _c("div", { staticClass: "mega-menu__wrapper" }, [
                    _c(
                      "div",
                      {
                        staticClass: "mega-menu__inner",
                        staticStyle: { "max-width": "1200px" },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass: "mega-menu__item",
                            attrs: { "rel-script": "mega-menu-item" },
                          },
                          [
                            _c(
                              "a",
                              {
                                staticClass: "mega-menu__titles",
                                attrs: {
                                  href: "#",
                                  "rel-script": "mega-menu-toggle",
                                },
                              },
                              [_vm._v("Coolmate")]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              { attrs: { "rel-script": "mega-menu-active" } },
                              [
                                _c("div", { staticClass: "grid" }, [
                                  _c(
                                    "a",
                                    {
                                      staticClass:
                                        "grid__column three-twelfths mobile--one-half",
                                      attrs: {
                                        href: "/lp/coolmate-101?itm_source=navbar",
                                      },
                                    },
                                    [
                                      _c(
                                        "div",
                                        {
                                          staticClass: "mega-menu__thumbnail",
                                          staticStyle: {
                                            "border-radius": "1.5em",
                                            overflow: "hidden",
                                          },
                                        },
                                        [
                                          _c("img", {
                                            attrs: {
                                              src: "https://www.coolmate.me/images/placeholder-image.png",
                                              "data-src":
                                                "https://mcdn.coolmate.me/image/August2022/mceclip0_97.jpg",
                                              alt: "Coolmate 101",
                                            },
                                          }),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        {
                                          staticStyle: {
                                            "line-height": "1.25em",
                                            "margin-top": "10px",
                                          },
                                        },
                                        [
                                          _c(
                                            "span",
                                            {
                                              staticStyle: {
                                                "font-size": "13px",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "Coolmate 101\n                                                            "
                                              ),
                                            ]
                                          ),
                                          _c("br"),
                                          _vm._v(" "),
                                          _c(
                                            "span",
                                            {
                                              staticStyle: {
                                                "font-size": "11px",
                                                "font-weight": "300",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "Tất\n                                                                cả những gì bạn muốn biết về\n                                                                Coolmate!"
                                              ),
                                              _c("br", {
                                                staticClass: "mobile--hidden",
                                              }),
                                              _vm._v(
                                                " và gia\n                                                                nhập Coolmate"
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "a",
                                    {
                                      staticClass:
                                        "grid__column three-twelfths mobile--one-half",
                                      attrs: {
                                        href: "/page/11-dich-vu-tai-coolmate-co-the-ban-chua-biet?itm_source=navbar",
                                      },
                                    },
                                    [
                                      _c(
                                        "div",
                                        {
                                          staticClass: "mega-menu__thumbnail",
                                          staticStyle: {
                                            "border-radius": "1.5em",
                                            overflow: "hidden",
                                          },
                                        },
                                        [
                                          _c("img", {
                                            attrs: {
                                              src: "https://www.coolmate.me/images/placeholder-image.png",
                                              "data-src":
                                                "https://mcdn.coolmate.me/image/August2022/mceclip1_92.jpg",
                                              alt: "Dịch vụ 100% hài lòng",
                                            },
                                          }),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        {
                                          staticStyle: {
                                            "line-height": "1.25em",
                                            "margin-top": "10px",
                                          },
                                        },
                                        [
                                          _c(
                                            "span",
                                            {
                                              staticStyle: {
                                                "font-size": "13px",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "Dịch vụ 100% hài\n                                                                lòng"
                                              ),
                                            ]
                                          ),
                                          _c("br"),
                                          _vm._v(" "),
                                          _c(
                                            "span",
                                            {
                                              staticStyle: {
                                                "font-size": "11px",
                                                "font-weight": "300",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "Bật\n                                                                mí 11 dịch vụ Coolmate cam\n                                                                kết với khách hàng"
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "a",
                                    {
                                      staticClass:
                                        "grid__column three-twelfths mobile--one-half",
                                      attrs: {
                                        href: "/page/coolclub-chuong-trinh-khach-hang-than-thiet-cua-coolmate?itm_source=navbar",
                                      },
                                    },
                                    [
                                      _c(
                                        "div",
                                        {
                                          staticClass: "mega-menu__thumbnail",
                                          staticStyle: {
                                            "border-radius": "1.5em",
                                            overflow: "hidden",
                                          },
                                        },
                                        [
                                          _c("img", {
                                            attrs: {
                                              src: "https://www.coolmate.me/images/placeholder-image.png",
                                              "data-src":
                                                "https://mcdn.coolmate.me/image/August2022/mceclip2_100.jpg",
                                              alt: "Coolclub - Khách hàng thân thiết",
                                            },
                                          }),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        {
                                          staticStyle: {
                                            "line-height": "1.25em",
                                            "margin-top": "10px",
                                          },
                                        },
                                        [
                                          _c(
                                            "span",
                                            {
                                              staticStyle: {
                                                "font-size": "13px",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "Coolclub - Khách\n                                                                hàng thân thiết"
                                              ),
                                            ]
                                          ),
                                          _c("br"),
                                          _vm._v(" "),
                                          _c(
                                            "span",
                                            {
                                              staticStyle: {
                                                "font-size": "11px",
                                                "font-weight": "300",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "Những\n                                                                ưu đãi hấp dẫn dành cho\n                                                                khách hàng thân thiết"
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "a",
                                    {
                                      staticClass:
                                        "grid__column three-twelfths mobile--one-half",
                                      attrs: {
                                        href: "/page/coolmate-story?itm_source=navbar",
                                      },
                                    },
                                    [
                                      _c(
                                        "div",
                                        {
                                          staticClass: "mega-menu__thumbnail",
                                          staticStyle: {
                                            "border-radius": "1.5em",
                                            overflow: "hidden",
                                          },
                                        },
                                        [
                                          _c("img", {
                                            attrs: {
                                              src: "https://www.coolmate.me/images/placeholder-image.png",
                                              "data-src":
                                                "https://mcdn.coolmate.me/image/August2022/mceclip3_34.jpg",
                                              alt: "Câu chuyện",
                                            },
                                          }),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        {
                                          staticStyle: {
                                            "line-height": "1.25em",
                                            "margin-top": "10px",
                                          },
                                        },
                                        [
                                          _c(
                                            "span",
                                            {
                                              staticStyle: {
                                                "font-size": "13px",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "Câu\n                                                                chuyện"
                                              ),
                                            ]
                                          ),
                                          _c("br"),
                                          _vm._v(" "),
                                          _c(
                                            "span",
                                            {
                                              staticStyle: {
                                                "font-size": "11px",
                                                "font-weight": "300",
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "Về\n                                                                Startup với mô hình Online\n                                                                D2C"
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]),
                ]),
              ]
            ),
          ]),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "header__actions" }, [
      _c("div", { staticClass: "header-actions__button mobile--hidden" }, [
        _c("a", { attrs: { href: "#", "rel-script": "header-search" } }, [
          _c("img", {
            attrs: {
              src: "https://www.coolmate.me/images/header/icon-search.svg",
              alt: "Icon Search",
            },
          }),
        ]),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "header-actions__button" }, [
        _c("a", { attrs: { href: "https://www.coolmate.me/cart" } }, [
          _c("img", {
            staticStyle: { "padding-bottom": "0px" },
            attrs: {
              src: "https://www.coolmate.me/images/header/icon-cart.svg",
              alt: "Icon mini cart",
            },
          }),
        ]),
        _vm._v(" "),
        _c("span", { staticClass: "counts" }, [_vm._v("2")]),
        _vm._v(" "),
        _c("div", { staticClass: "header-actions__menu" }, [
          _c("div", { staticClass: "header-actions__inner" }, [
            _c("div", { staticClass: "header-actions__menu" }, [
              _c("div", { staticClass: "header-actions__inner" }, [
                _c(
                  "div",
                  {
                    staticClass: "mini-cart mobile--hidden",
                    attrs: { "data-v-5062b04f": "" },
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "mini-cart__wrapper",
                        attrs: { "data-v-5062b04f": "" },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass: "mini-cart__header",
                            attrs: { "data-v-5062b04f": "" },
                          },
                          [
                            _c("span", { attrs: { "data-v-5062b04f": "" } }, [
                              _vm._v(
                                "\n                                                    2 sản phẩm\n                                                "
                              ),
                            ]),
                            _vm._v(" "),
                            _c(
                              "a",
                              {
                                attrs: { "data-v-5062b04f": "", href: "/cart" },
                              },
                              [
                                _vm._v(
                                  "\n                                                    Xem tất cả\n                                                "
                                ),
                              ]
                            ),
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            staticClass: "mini-cart__item",
                            attrs: { "data-v-5062b04f": "" },
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass: "mini-cart__item-thumbnail",
                                attrs: { "data-v-5062b04f": "" },
                              },
                              [
                                _c("img", {
                                  attrs: {
                                    "data-v-5062b04f": "",
                                    src: "https://media.coolmate.me/cdn-cgi/image/width=160,height=181,quality=80/image/August2022/Polo_v2_xanh_ngoc_1234.jpg",
                                    alt: "Áo Polo thể thao nam Recycle Active V2",
                                  },
                                }),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass: "mini-cart__item-content",
                                attrs: { "data-v-5062b04f": "" },
                              },
                              [
                                _c(
                                  "span",
                                  {
                                    staticClass: "mini-cart__remove",
                                    attrs: { "data-v-5062b04f": "" },
                                  },
                                  [_vm._v("✕")]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  {
                                    staticClass: "mini-cart__item-title",
                                    attrs: { "data-v-5062b04f": "" },
                                  },
                                  [
                                    _c(
                                      "a",
                                      {
                                        attrs: {
                                          "data-v-5062b04f": "",
                                          href: "/product/ao-polo-the-thao-nam-recycle-active-v2",
                                          target: "_blank",
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                                                            Áo Polo thể thao nam Recycle Active V2\n                                                        "
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  {
                                    staticClass: "mini-cart__item-variant-info",
                                    attrs: { "data-v-5062b04f": "" },
                                  },
                                  [
                                    _vm._v(
                                      "\n                                                        Xanh ngọc / S\n                                                    "
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { attrs: { "data-v-5062b04f": "" } },
                                  [
                                    _c(
                                      "span",
                                      {
                                        staticClass: "mini-cart__item-price",
                                        attrs: { "data-v-5062b04f": "" },
                                      },
                                      [
                                        _vm._v(
                                          "\n                                                            249.000đ\n                                                        "
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { attrs: { "data-v-5062b04f": "" } },
                                  [
                                    _c(
                                      "span",
                                      {
                                        staticClass: "mini-cart__item-quantity",
                                        attrs: { "data-v-5062b04f": "" },
                                      },
                                      [
                                        _vm._v(
                                          "\n                                                            x1\n                                                        "
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            staticClass: "mini-cart__item",
                            attrs: { "data-v-5062b04f": "" },
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass: "mini-cart__item-thumbnail",
                                attrs: { "data-v-5062b04f": "" },
                              },
                              [
                                _c("img", {
                                  attrs: {
                                    "data-v-5062b04f": "",
                                    src: "https://media.coolmate.me/cdn-cgi/image/width=160,height=181,quality=80/image/September2022/tee_recycle_v2_xanh_navy_4.jpg",
                                    alt: "Áo thun thể thao nam Recycle Active V2",
                                  },
                                }),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass: "mini-cart__item-content",
                                attrs: { "data-v-5062b04f": "" },
                              },
                              [
                                _c(
                                  "span",
                                  {
                                    staticClass: "mini-cart__remove",
                                    attrs: { "data-v-5062b04f": "" },
                                  },
                                  [_vm._v("✕")]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  {
                                    staticClass: "mini-cart__item-title",
                                    attrs: { "data-v-5062b04f": "" },
                                  },
                                  [
                                    _c(
                                      "a",
                                      {
                                        attrs: {
                                          "data-v-5062b04f": "",
                                          href: "/product/ao-thun-the-thao-nam-recycle-active-v2",
                                          target: "_blank",
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                                                            Áo thun thể thao nam Recycle Active V2\n                                                        "
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  {
                                    staticClass: "mini-cart__item-variant-info",
                                    attrs: { "data-v-5062b04f": "" },
                                  },
                                  [
                                    _vm._v(
                                      "\n                                                        Xanh Navy / XL\n                                                    "
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { attrs: { "data-v-5062b04f": "" } },
                                  [
                                    _c(
                                      "span",
                                      {
                                        staticClass: "mini-cart__item-price",
                                        attrs: { "data-v-5062b04f": "" },
                                      },
                                      [
                                        _vm._v(
                                          "\n                                                            159.000đ\n                                                        "
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { attrs: { "data-v-5062b04f": "" } },
                                  [
                                    _c(
                                      "span",
                                      {
                                        staticClass: "mini-cart__item-quantity",
                                        attrs: { "data-v-5062b04f": "" },
                                      },
                                      [
                                        _vm._v(
                                          "\n                                                            x1\n                                                        "
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]),
            ]),
          ]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ })

}]);